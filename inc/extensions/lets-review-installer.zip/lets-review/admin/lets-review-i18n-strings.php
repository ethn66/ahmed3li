<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 *
 * i18n Strings
 *
 * @since      1.0.0
 *
 * @package    Let's Review
 * @subpackage lets-review/admin
 */

$strings = 'tinyMCE.addI18n( "' . _WP_Editors::$mce_locale . '.letsReview", {
    insert: "' . esc_html__( 'Insert', 'lets-review' ) . '",
    close: "' . esc_html__( 'Close', 'lets-review' ) . '",
    caption: "Lets Review",
    mainTitle: "' . esc_attr__( 'Insert Lets Review Shortcode', 'lets-review' ) . '",
    existingreview: "' . esc_html__( 'Existing Review', 'lets-review' ) . '",
    affiliate: "' . esc_html__( 'Affiliate Button', 'lets-review' ) . '",
    uniquereview: "' . esc_html__( 'Unique Review', 'lets-review' ) . '",
    userrating: "' . esc_html__( 'Visitor Rating Box', 'lets-review' ) . '",
    list: "' . esc_html__( 'Comparison List', 'lets-review' ) . '",
    buttons: "' . esc_html__( 'Buttons', 'lets-review' ) . '"
} )';