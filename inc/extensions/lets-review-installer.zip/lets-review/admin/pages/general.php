<?php
/**
 * Extras Page
 *
 * @since    1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>	
<div class="tipi-block tipi-default">
	<h3><?php esc_html_e( 'General Options', 'lets-review' ); ?></h3>
	<br>
	<form action="options.php" method="post">
		<?php settings_fields( 'lets-review-settings-general' ); ?>
		<?php do_settings_sections( 'lets-review-general' ); ?>
		<?php submit_button( esc_html__( 'Save Changes', 'lets-review' ) ); ?>
		<?php wp_nonce_field( 'lets-review-general', 'lets-review-general-nonce' ); ?>
	</form>
</div>