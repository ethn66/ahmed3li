/*!
Plugin Name: Let's Review
Plugin URI: https://codecanyon.net/item/lets-review-wordpress-review-plugin-with-affiliate-options/15956777
Author: Codetipi
Author URI: https://codetipi.com
Description: The ultimate review plugin for WordPress
Version: 3.3.9
Text Domain: lets-review
License: http://codecanyon.net/licenses/regular_extended
License URI: http://codecanyon.net/licenses/regular_extended
Requires at least: 4.8
Tested up to: testedupto
Domain Path: /languages/
*/