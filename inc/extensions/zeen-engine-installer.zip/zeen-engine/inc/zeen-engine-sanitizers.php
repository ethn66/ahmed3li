<?php
/**
 *
 * Zeen Engine
 *
 * @since      1.0.0
 *
 * @package    Zeen Engine
 * @subpackage zeen-engine/inc
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

function zeen_engine_sanitize_wp_kses( $data ) {

	return wp_kses( $data, array(
		'a' => array(
			'href'  => array(),
			'class'  => array(),
			'style'    => array(),
			'id'  => array(),
			'target'  => array(),
			'title' => array(),
		),
		'span' => array(
			'class' => array(),
			'id'    => array(),
			'style'    => array(),
		),
		'p' => array(
			'class' => array(),
			'id'    => array(),
			'style'    => array(),
		),
		'h1' => array(
			'class' => array(),
			'id'    => array(),
			'style'    => array(),
		),
		'h2' => array(
			'class' => array(),
			'id'    => array(),
			'style'    => array(),
		),
		'h3' => array(
			'class' => array(),
			'id'    => array(),
			'style'    => array(),
		),
		'h4' => array(
			'class' => array(),
			'id'    => array(),
			'style'    => array(),
		),
		'h5' => array(
			'class' => array(),
			'id'    => array(),
			'style'    => array(),
		),
		'img' => array(
			'src'    => array(),
			'srcset' => array(),
			'alt'    => array(),
		),
		'div' => array(
			'class' => array(),
			'id'    => array(),
			'style'    => array(),
		),
		'i' => array(
			'class' => array(),
			'id'    => array(),
			'style'    => array(),
		),
		'u' => array(
			'class' => array(),
			'id'    => array(),
			'style'    => array(),
		),
		'br'     => array(),
		'em'     => array(),
		'strong' => array(),
		'italic' => array(),
		'iframe'  => array(
			'class' => array(),
			'id'    => array(),
			'src'    => array(),
			'width'    => array(),
			'height'    => array(),
		),
	));
}

function zeen_engine_sanitize_titles( $data ) {

	return wp_kses( $data, array(
		'span' => array(
			'class' => array(),
			'style' => array(),
		),
		'h1' => array(
			'class' => array(),
			'style' => array(),
		),
		'h2' => array(
			'class' => array(),
			'style' => array(),
		),
		'h3' => array(
			'class' => array(),
			'style' => array(),
		),
		'h4' => array(
			'class' => array(),
			'style' => array(),
		),
		'div' => array(
			'class' => array(),
			'style'    => array(),
		),
		'i' => array(
			'class' => array(),
			'style' => array(),
		),
		'u' => array(
			'style' => array(),
		),
		'a' => array(
			'href' => array(),
			'style' => array(),
			'target' => array(),
		),
		'br'     => array(),
		'strong' => array(),
	));

}

/**
 * Sanitizer Commas
 *
 * @since  1.0.0
 */
function zeen_engine_sanitize_num_commas( $data ) {

	$data = filter_var( $data, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION | FILTER_FLAG_ALLOW_THOUSAND );
	return $data;

}

/**
 * Sanitizer Array
 *
 * @since  1.0.0
 */
function zeen_engine_sanitize_array( $array ) {

	if ( ! is_array( $array ) ) {
		return array();
	}

	foreach ( $array as $key => $value ) {

		if ( is_array( $value ) ) {
			$array[ $key ] = zeen_engine_sanitize_array( $value );
		} else {
			$array[ $key ] = esc_attr( $value );
		}
	}

	return $array;
}

/**
 * Sanitizer Floats
 *
 * @since  1.0.0
 */
function zeen_engine_sanitizer_float( $data ) {
	return floatval( $data );
}

function zeen_engine_sanitizer_options( $data, $options ) {
	if ( in_array( $data, $options) ) {
		return $data;
	} else {
		return esc_attr( $data );
	}
}

function zeen_engine_sanitizer_measurement_type( $data ) {
	$output = '';
	if ( 'px' == $data ) {
		$output = 'px';
	} elseif ( '%' == $data ) {
		$output = '%';
	} elseif ( 'em' == $data ) {
		$output = 'em';
	} elseif ( 'rem' == $data ) {
		$output = 'rem';
	} else {
		$output = esc_attr( $data );
	}
	return $output;
}


function zeen_engine_sanitizer_border_type( $data ) {
	$output = '';
	if ( 'solid' == $data ) {
		$output = 'solid';
	} elseif ( 'dashed' == $data ) {
		$output = 'dashed';
	} elseif ( 'dotted' == $data ) {
		$output = 'dotted';
	} else {
		$output = esc_attr( $data );
	}
	return $output;
}
