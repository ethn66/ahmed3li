<?php
/**
 *
 * Zeen Engine internationalization
 *
 * @since      1.0.0
 *
 * @package    Zeen Engine
 * @subpackage zeen-engine/includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Zeen_Engine_I18n {

	/**
	 * Zeen Engine Translation
	 *
	 * @since    1.0.0
	 */
	public function zeen_engine_textdomain() {
		load_plugin_textdomain( 'zeen-engine', false, dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/' );
	}

}
