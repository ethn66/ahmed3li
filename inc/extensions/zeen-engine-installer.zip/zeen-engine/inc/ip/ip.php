<?php
function zeen_engine_block_assets() {
	wp_register_script(
		'zeen-engine-block-ip-editor',
		plugins_url( 'build/index.js', __FILE__ ),
		array( 'wp-blocks', 'wp-i18n', 'wp-element', 'wp-editor', 'wp-compose' ),
		'2.8.2'
	);
	wp_set_script_translations( 'zeen-engine-block-ip-editor', 'zeen-engine' );

	wp_register_style(
		'zeen-engine-block-ip-editor',
		plugins_url( 'build/index.css', __FILE__ ),
		array(),
		'2.8.2'
	);
}
add_action( 'enqueue_block_editor_assets', 'zeen_engine_block_assets' );

function zeen_engine_block() {
	register_block_type( 'zeen/block-inline-post', array(
		'editor_script' => 'zeen-engine-block-ip-editor',
		'editor_style'  => 'zeen-engine-block-ip-editor',
		'render_callback' => 'zeen_engine_render_inline',
		'attributes'      => array(
			'pid'             => array(
				'type' => 'string',
			),
			'title'             => array(
				'type' => 'string',
				'default' => esc_html__( 'See Also', 'zeen-engine' ),
			),

		),
	) );
}
add_action( 'init', 'zeen_engine_block' );

function zeen_engine_render_inline( $attr = '' ) {
	$pid = empty( $attr['pid'] ) ? '' : $attr['pid'];
	$title = empty( $attr['title'] ) ? '' : $attr['title'];
	if ( ! function_exists( 'zeen_post_inline' ) ) {
		return;
	}
	return zeen_post_inline( array( 'pid' => $pid, 'title' => $title ) );
}
