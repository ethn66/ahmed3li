<?php
/**
 * Zeen social icons
 *
 * @since 1.0.0
 *
 * @see WP_Widget
 */
class ZeenEngineSocialIcons extends WP_Widget {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'                   => 'zeen_social_icons',
			'description'                 => esc_html__( 'Promote your social pages with these icons.', 'zeen-engine' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'zeen_social_icons', esc_html__( 'Zeen: Social icons', 'zeen-engine' ), $widget_ops );

	}

	/**
	 * Outputs the content for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current widget instance.
	 */
	public function widget( $args, $instance ) {

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title                           = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		$theme                           = ! empty( $instance['theme'] ) ? $instance['theme'] : 'light';
		$size                            = ! empty( $instance['size'] ) ? $instance['size'] : 1;
		$center                          = ! isset( $instance['center'] ) || ! empty( $instance['center'] ) ? '0' : '1';
		$tooltip                         = ! empty( $instance['tooltip'] ) ? '1' : '0';
		$nofollow                        = ! empty( $instance['nofollow'] ) ? '1' : '0';
		$new_tab                         = ! empty( $instance['new_tab'] ) ? '1' : '0';
		$output                          = array();
		$output['tipi-i-facebook']       = ! empty( $instance['facebook'] ) ? array( 'Facebook', $instance['facebook'] ) : '';
		$output['tipi-i-twitter']        = ! empty( $instance['twitter'] ) ? array( 'Twitter', $instance['twitter'] ) : '';
		$output['tipi-i-instagram']      = ! empty( $instance['instagram'] ) ? array( 'Instagram', $instance['instagram'] ) : '';
		$output['tipi-i-youtube-play']   = ! empty( $instance['youtube'] ) ? array( 'YouTube', $instance['youtube'] ) : '';
		$output['tipi-i-pinterest']      = ! empty( $instance['pinterest'] ) ? array( 'Pinterest', $instance['pinterest'] ) : '';
		$output['tipi-i-vk']             = ! empty( $instance['vk'] ) ? array( 'VK', $instance['vk'] ) : '';
		$output['tipi-i-linkedin']       = ! empty( $instance['linkedin'] ) ? array( 'LinkedIn', $instance['linkedin'] ) : '';
		$output['tipi-i-rss']            = ! empty( $instance['rss'] ) ? array( 'RSS', $instance['rss'] ) : '';
		$output['tipi-i-vimeo']          = ! empty( $instance['vimeo'] ) ? array( 'Vimeo', $instance['vimeo'] ) : '';
		$output['tipi-i-soundcloud']     = ! empty( $instance['soundcloud'] ) ? array( 'Soundcloud', $instance['soundcloud'] ) : '';
		$output['tipi-i-dribbble']       = ! empty( $instance['dribbble'] ) ? array( 'Dribbble', $instance['dribbble'] ) : '';
		$output['tipi-i-tumblr']         = ! empty( $instance['tumblr'] ) ? array( 'Tumblr', $instance['tumblr'] ) : '';
		$output['tipi-i-snapchat-ghost'] = ! empty( $instance['snapchat'] ) ? array( 'Snapchat', $instance['snapchat'] ) : '';
		$output['tipi-i-spotify']        = ! empty( $instance['spotify'] ) ? array( 'Spotify', $instance['spotify'] ) : '';
		$output['tipi-i-medium']         = ! empty( $instance['medium'] ) ? array( 'Medium', $instance['medium'] ) : '';
		$output['tipi-i-unsplash']       = ! empty( $instance['unsplash'] ) ? array( 'Unsplash', $instance['unsplash'] ) : '';
		$output['tipi-i-mixcloud']       = ! empty( $instance['mixcloud'] ) ? array( 'Mixcloud', $instance['mixcloud'] ) : '';
		$output['tipi-i-bandcamp']       = ! empty( $instance['bandcamp'] ) ? array( 'Bandcamp', $instance['bandcamp'] ) : '';
		$output['tipi-i-goodreads']      = ! empty( $instance['goodreads'] ) ? array( 'Goodreads', $instance['goodreads'] ) : '';
		$output['tipi-i-itch']           = ! empty( $instance['itch'] ) ? array( 'Itch.io', $instance['itch'] ) : '';
		$output['tipi-i-producthunt']    = ! empty( $instance['producthunt'] ) ? array( 'Product Hunt', $instance['producthunt'] ) : '';
		$output['tipi-i-letterboxd']     = ! empty( $instance['letterboxd'] ) ? array( 'Letterboxd', $instance['letterboxd'] ) : '';

		echo ( $args['before_widget'] );
		if ( ! empty( $title ) ) {
			echo ( $args['before_title'] . $title . $args['after_title'] );
		}
		echo '<div class="social-widget-icons social-align-' . (int) $center . '">';
		echo '<ul>';
		foreach ( array_filter( $output ) as $network => $url ) {
			echo '<li>';
			?>
			<a href="<?php echo esc_url( $url[1] ); ?>" class="<?php echo esc_attr( $network ); ?> tipi-i-sz-<?php echo intval( $size ); ?> zeen-social-icons-<?php echo esc_attr( $theme ); if ( $tooltip == 1 ) { ?> tipi-tip tipi-tip-move<?php } ?>" data-title="<?php if ( $tooltip == 1 ) { echo esc_attr( $url[0] ); } ?>" rel="noopener<?php if ( ! empty( $nofollow ) ) { echo ' nofollow'; } ?>"<?php if ( ! empty( $new_tab ) ) { echo ' target="_blank"'; } ?>></a>
			<?php
			echo '</li>';
		}
		echo '</ul>';
		echo '</div>';
		echo ( $args['after_widget'] );

	}

	/**
	 * Handles updating settings for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                = $old_instance;
		$instance['title']       = sanitize_text_field( $new_instance['title'] );
		$instance['facebook']    = esc_url( $new_instance['facebook'] );
		$instance['twitter']     = esc_url( $new_instance['twitter'] );
		$instance['instagram']   = esc_url( $new_instance['instagram'] );
		$instance['youtube']     = esc_url( $new_instance['youtube'] );
		$instance['pinterest']   = esc_url( $new_instance['pinterest'] );
		$instance['vk']          = esc_url( $new_instance['vk'] );
		$instance['linkedin']    = esc_url( $new_instance['linkedin'] );
		$instance['rss']         = esc_url( $new_instance['rss'] );
		$instance['vimeo']       = esc_url( $new_instance['vimeo'] );
		$instance['soundcloud']  = esc_url( $new_instance['soundcloud'] );
		$instance['dribbble']    = esc_url( $new_instance['dribbble'] );
		$instance['tumblr']      = esc_url( $new_instance['tumblr'] );
		$instance['snapchat']    = esc_url( $new_instance['snapchat'] );
		$instance['spotify']     = esc_url( $new_instance['spotify'] );
		$instance['medium']      = esc_url( $new_instance['medium'] );
		$instance['unsplash']    = esc_url( $new_instance['unsplash'] );
		$instance['mixcloud']    = esc_url( $new_instance['mixcloud'] );
		$instance['goodreads']   = esc_url( $new_instance['goodreads'] );
		$instance['itch']        = esc_url( $new_instance['itch'] );
		$instance['producthunt'] = esc_url( $new_instance['producthunt'] );
		$instance['bandcamp']    = esc_url( $new_instance['bandcamp'] );
		$instance['tooltip']     = $new_instance['tooltip'] ? 1 : 0;
		$instance['center']      = $new_instance['center'] ? 1 : 0;
		$instance['nofollow']    = $new_instance['nofollow'] ? 1 : 0;
		$instance['new_tab']     = $new_instance['new_tab'] ? 1 : 0;
		$instance['size']        = $new_instance['size'] ? intval( $new_instance['size'] ) : 1;

		if ( in_array( $new_instance['theme'], array( 'dark', 'light' ) ) ) {
			$instance['theme'] = $new_instance['theme'];
		} else {
			$instance['theme'] = 'light';
		}

		return $instance;
	}

	/**
	 * Outputs the widget settings form.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args(
			(array) $instance,
			array(
				'title'       => '',
				'size'        => 1,
				'theme'       => 'dark',
				'facebook'    => '',
				'twitter'     => '',
				'instagram'   => '',
				'youtube'     => '',
				'pinterest'   => '',
				'vk'          => '',
				'linkedin'    => '',
				'rss'         => '',
				'vimeo'       => '',
				'soundcloud'  => '',
				'dribbble'    => '',
				'tumblr'      => '',
				'snapchat'    => '',
				'spotify'     => '',
				'medium'      => '',
				'unsplash'    => '',
				'bandcamp'    => '',
				'goodreads'   => '',
				'itch'        => '',
				'producthunt' => '',
				'letterboxd'  => '',
				'mixcloud'    => '',
				'tooltip'     => 1,
				'center'      => 1,
				'nofollow'    => 0,
				'new_tab'     => 0,
			)
		);
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'zeen-engine' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['title'] ); ?>" /></p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'theme' ) ); ?>"><?php esc_html_e( 'Color theme', 'zeen-engine' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'theme' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'theme' ) ); ?>" class="widefat">
				<option value="dark"<?php selected( $instance['theme'], 'dark' ); ?>><?php esc_html_e( 'Dark', 'zeen-engine' ); ?></option>
				<option value="light"<?php selected( $instance['theme'], 'light' ); ?>><?php esc_html_e( 'Light', 'zeen-engine' ); ?></option>
			</select>
		</p>
		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'size' ) ); ?>"><?php esc_html_e( 'Icons Size', 'zeen-engine' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'size' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'size' ) ); ?>" class="widefat">
				<option value="1"<?php selected( $instance['size'], '1' ); ?>><?php esc_html_e( 'Small', 'zeen-engine' ); ?></option>
				<option value="2"<?php selected( $instance['size'], '2' ); ?>><?php esc_html_e( 'Medium', 'zeen-engine' ); ?></option>
				<option value="3"<?php selected( $instance['size'], '3' ); ?>><?php esc_html_e( 'Large', 'zeen-engine' ); ?></option>
			</select>
		</p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>">Facebook</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'facebook' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'facebook' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['facebook'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>">Twitter</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'twitter' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'twitter' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['twitter'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'instagram' ) ); ?>">Instagram</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'instagram' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'instagram' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['instagram'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'youtube' ) ); ?>">YouTube</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'youtube' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'youtube' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['youtube'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'pinterest' ) ); ?>">Pinterest</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'pinterest' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'pinterest' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['pinterest'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'vk' ) ); ?>">VK</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'vk' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'vk' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['vk'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'linkedin' ) ); ?>">LinkedIn</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'linkedin' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'linkedin' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['linkedin'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>


		<p><label for="<?php echo esc_attr( $this->get_field_id( 'vimeo' ) ); ?>">Vimeo</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'vimeo' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'vimeo' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['vimeo'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'soundcloud' ) ); ?>">Soundcloud</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'soundcloud' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'soundcloud' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['soundcloud'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'dribbble' ) ); ?>">Dribbble</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'dribbble' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'dribbble' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['dribbble'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'tumblr' ) ); ?>">Tumblr</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'tumblr' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tumblr' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['tumblr'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'snapchat' ) ); ?>">Snapchat</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'snapchat' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'snapchat' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['snapchat'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'spotify' ) ); ?>">Spotify</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'spotify' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'spotify' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['spotify'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'medium' ) ); ?>">Medium</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'medium' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'medium' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['medium'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'unsplash' ) ); ?>">Unsplash</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'unsplash' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'unsplash' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['unsplash'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'mixcloud' ) ); ?>">Mixcloud</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'mixcloud' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'mixcloud' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['mixcloud'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'bandcamp' ) ); ?>">Bandcamp</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'bandcamp' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'bandcamp' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['bandcamp'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'goodreads' ) ); ?>">Goodreads</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'goodreads' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'goodreads' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['goodreads'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'itch' ) ); ?>">Itch.io</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'itch' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'itch' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['itch'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'producthunt' ) ); ?>">Product Hunt</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'producthunt' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'producthunt' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['producthunt'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'letterboxd' ) ); ?>">Letterboxd</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'letterboxd' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'letterboxd' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['letterboxd'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id( 'rss' ) ); ?>">RSS</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'rss' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'rss' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['rss'] ); ?>" /><br><small><?php esc_html_e( 'Enter complete url', 'zeen-engine' ); ?></small></p>
		<p>
			<input class="checkbox" type="checkbox"<?php checked( $instance['tooltip'] ); ?> id="<?php echo esc_attr( $this->get_field_id( 'tooltip' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tooltip' ) ); ?>" /> <label for="<?php echo esc_attr( $this->get_field_id( 'tooltip' ) ); ?>"><?php esc_html_e( 'Show tooltip', 'zeen-engine' ); ?></label>
			<br/>
			<input class="checkbox" type="checkbox"<?php checked( $instance['nofollow'] ); ?> id="<?php echo esc_attr( $this->get_field_id( 'nofollow' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'nofollow' ) ); ?>" /> <label for="<?php echo esc_attr( $this->get_field_id( 'nofollow' ) ); ?>"><?php esc_html_e( 'Make links nofollow', 'zeen-engine' ); ?></label>
			<br/>
			<input class="checkbox" type="checkbox"<?php checked( $instance['center'] ); ?> id="<?php echo esc_attr( $this->get_field_id( 'center' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'center' ) ); ?>" /> <label for="<?php echo esc_attr( $this->get_field_id( 'center' ) ); ?>"><?php esc_html_e( 'Align Center', 'zeen-engine' ); ?></label>
			<br/>
			<input class="checkbox" type="checkbox"<?php checked( $instance['new_tab'] ); ?> id="<?php echo esc_attr( $this->get_field_id( 'new_tab' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'new_tab' ) ); ?>" /> <label for="<?php echo esc_attr( $this->get_field_id( 'new_tab' ) ); ?>"><?php esc_html_e( 'Open in new tab', 'zeen-engine' ); ?></label>
		</p>
		<?php
	}
}
