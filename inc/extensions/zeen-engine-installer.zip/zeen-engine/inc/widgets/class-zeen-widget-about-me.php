<?php
/**
 * Zeen about me
 *
 * @since 1.0.0
 *
 * @see WP_Widget
 */
class ZeenAboutMe extends WP_Widget {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'                   => 'zeen_about_me',
			'description'                 => esc_html__( 'Add an about me widget with information about you or your site.', 'zeen-engine' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'zeen_about_me', esc_html__( 'Zeen: About Me', 'zeen-engine' ), $widget_ops );

	}

	/**
	 * Outputs the content for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current widget instance.
	 */
	public function widget( $args, $instance ) {

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title                = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		$url                  = ! empty( $instance['url'] ) ? $instance['url'] : '';
		$retina_url           = ! empty( $instance['retina_url'] ) ? $instance['retina_url'] : '';
		$signature_url        = ! empty( $instance['signature_url'] ) ? $instance['signature_url'] : '';
		$signature_retina_url = ! empty( $instance['signature_retina_url'] ) ? $instance['signature_retina_url'] : '';
		$link                 = ! empty( $instance['link'] ) ? $instance['link'] : '';
		$content              = ! empty( $instance['content'] ) ? $instance['content'] : '';
		$round_img            = ! empty( $instance['round_img'] ) ? '1' : '0';
		$output               = array();

		if ( empty( $url ) && empty( $retina_url ) ) {
			return;
		}
		echo $args['before_widget'];
		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}
		$classes = '';
		if ( ! empty( $round_img ) ) {
			$classes .= ' about_me__img--round';
		}
		?>
		<div class="zeen-about-me<?php echo esc_attr( $classes ); ?>">
			<?php if ( ! empty( $url ) ) { ?>
				<div class="about_me__img"><img src="<?php echo esc_url( $url ); ?>" srcset="
																<?php
																if ( $retina_url ) {
																	echo esc_url( $retina_url ) . ' 2x'; }
																?>
				" alt=""></div>
			<?php } ?>

			<?php if ( ! empty( $content ) ) { ?>
				<div class="about_me__content">
					<?php echo ( $content ); ?>
				</div>
			<?php } ?>
			<?php if ( ! empty( $signature_url ) ) { ?>
				<?php if ( ! empty( $link ) ) { ?>
					<a href="<?php echo esc_url( $link ); ?>">
					<?php
				}
				echo '<div class="about_me__signature"><img src="' . esc_url( $signature_url ) . '"';
				if ( $signature_retina_url ) {
					echo ' srcset="' . esc_url( $signature_retina_url ) . ' 2x"';
				}
				echo ' alt=""></div>';
				?>
				<?php if ( ! empty( $link ) ) { ?>
					</a>
				<?php } ?>
			<?php } ?>

		</div>

		<?php
		echo $args['after_widget'];

	}

	/**
	 * Handles updating settings for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                         = $old_instance;
		$instance['title']                = sanitize_text_field( $new_instance['title'] );
		$instance['url']                  = esc_url( $new_instance['url'] );
		$instance['retina_url']           = esc_url( $new_instance['retina_url'] );
		$instance['signature_url']        = esc_url( $new_instance['signature_url'] );
		$instance['signature_retina_url'] = esc_url( $new_instance['signature_retina_url'] );
		$instance['link']                 = esc_url( $new_instance['link'] );
		$instance['content']              = zeen_engine_sanitize_wp_kses( $new_instance['content'] );
		$instance['round_img']            = $new_instance['round_img'] ? 1 : 0;
		return $instance;
	}

	/**
	 * Outputs the widget settings form.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance            = wp_parse_args(
			(array) $instance,
			array(
				'title'                => '',
				'url'                  => '',
				'retina_url'           => '',
				'signature_url'        => '',
				'signature_retina_url' => '',
				'link'                 => '',
				'content'              => '',
				'round_img'            => '',
			)
		);
		$id_img              = 'zeen-engine-img-' . mt_rand( 1000, 99999 );
		$id_retina           = 'zeen-engine-retina-' . mt_rand( 1000, 99999 );
		$id_signature        = 'zeen-engine-signature-' . mt_rand( 1000, 99999 );
		$id_signature_retina = 'zeen-engine-signature-retina-' . mt_rand( 1000, 99999 );
		?>
		<p><label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php esc_html_e( 'Title', 'zeen-engine' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>" name="<?php echo $this->get_field_name( 'title' ); ?>" type="text" value="<?php echo esc_attr( sanitize_text_field( $instance['title'] ) ); ?>" /></p>

		<p id="<?php echo esc_attr( $id_img ); ?>" class="zeen-engine-image-wrap zeen-engine-image-wrap-widget">
			<label for="<?php echo esc_attr( $this->get_field_id( 'url' ) ); ?>">
				<?php esc_html_e( 'Main Image', 'zeen-engine' ); ?>
			</label>
			<span class="zeen-engine-control-only">
				<input id="<?php echo esc_attr( $this->get_field_id( 'url' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'url' ) ); ?>" type="text" value="<?php echo esc_url( $instance['url'] ); ?>" class="widefat zeen-engine-img-input zeen-engine-input-val">

				<a href="#" class="zeen-engine-upload" data-dest="<?php echo esc_attr( $id_img ); ?>" data-output="src" data-file-type="video" data-name="<?php echo esc_attr( $this->get_field_name( 'url' ) ); ?>"><?php esc_html_e( 'Upload', 'zeen-engine' ); ?></a>

			</span>
		</p>

		<p id="<?php echo esc_attr( $id_retina ); ?>" class="zeen-engine-image-wrap zeen-engine-image-wrap-widget">
			<label for="<?php echo esc_attr( $this->get_field_id( 'retina_url' ) ); ?>">
				<?php esc_html_e( 'Main Image (Retina)', 'zeen-engine' ); ?>
			</label>
			<span class="zeen-engine-control-only">
				<input id="<?php echo esc_attr( $this->get_field_id( 'retina_url' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'retina_url' ) ); ?>" type="text" value="<?php echo esc_url( $instance['retina_url'] ); ?>" class="widefat zeen-engine-img-input zeen-engine-input-val">

				<a href="#" class="zeen-engine-upload" data-dest="<?php echo esc_attr( $id_retina ); ?>" data-output="src" data-file-type="video" data-name="<?php echo esc_attr( $this->get_field_name( 'retina_url' ) ); ?>"><?php esc_html_e( 'Upload', 'zeen-engine' ); ?></a>

			</span>
		</p>

		<p>
			<input class="checkbox" type="checkbox"<?php checked( $instance['round_img'] ); ?> id="<?php echo $this->get_field_id( 'round_img' ); ?>" name="<?php echo $this->get_field_name( 'round_img' ); ?>" /> <label for="<?php echo $this->get_field_id( 'round_img' ); ?>"><?php esc_html_e( 'Round Main Image', 'zeen-engine' ); ?></label></br>
		</p>

		<p id="<?php echo esc_attr( $id_signature ); ?>" class="zeen-engine-image-wrap zeen-engine-image-wrap-widget">
			<label for="<?php echo esc_attr( $this->get_field_id( 'signature_url' ) ); ?>">
				<?php esc_html_e( 'Signature Image', 'zeen-engine' ); ?>
			</label>
			<span class="zeen-engine-control-only">
				<input id="<?php echo esc_attr( $this->get_field_id( 'signature_url' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'signature_url' ) ); ?>" type="text" value="<?php echo esc_url( $instance['signature_url'] ); ?>" class="widefat zeen-engine-img-input zeen-engine-input-val">

				<a href="#" class="zeen-engine-upload" data-dest="<?php echo esc_attr( $id_signature ); ?>" data-output="src" data-file-type="video" data-name="<?php echo esc_attr( $this->get_field_name( 'signature_url' ) ); ?>"><?php esc_html_e( 'Upload', 'zeen-engine' ); ?></a>

			</span>
		</p>

		<p id="<?php echo esc_attr( $id_signature_retina ); ?>" class="zeen-engine-image-wrap zeen-engine-image-wrap-widget">
			<label for="<?php echo esc_attr( $this->get_field_id( 'signature_retina_url' ) ); ?>">
				<?php esc_html_e( 'Signature Image (Retina)', 'zeen-engine' ); ?>
			</label>
			<span class="zeen-engine-control-only">
				<input id="<?php echo esc_attr( $this->get_field_id( 'signature_retina_url' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'signature_retina_url' ) ); ?>" type="text" value="<?php echo esc_url( $instance['signature_retina_url'] ); ?>" class="widefat zeen-engine-img-input zeen-engine-input-val">

				<a href="#" class="zeen-engine-upload" data-dest="<?php echo esc_attr( $id_signature_retina ); ?>" data-output="src" data-file-type="video" data-name="<?php echo esc_attr( $this->get_field_name( 'signature_retina_url' ) ); ?>"><?php esc_html_e( 'Upload', 'zeen-engine' ); ?></a>

			</span>
		</p>

		<p><label for="<?php echo $this->get_field_id( 'content' ); ?>"><?php esc_html_e( 'About', 'zeen-engine' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'content' ); ?>" name="<?php echo $this->get_field_name( 'content' ); ?>" type="text" value="<?php echo esc_attr( $instance['content'] ); ?>" /><br></p>

		<p><label for="<?php echo $this->get_field_id( 'link' ); ?>"><?php esc_html_e( 'Signature Link', 'zeen-engine' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id( 'link' ); ?>" name="<?php echo $this->get_field_name( 'link' ); ?>" type="text" value="<?php echo esc_url( $instance['link'] ); ?>" /><br><small><?php esc_html_e( 'Make Signature A Link', 'zeen-engine' ); ?></small></p>

		<?php
	}
}
