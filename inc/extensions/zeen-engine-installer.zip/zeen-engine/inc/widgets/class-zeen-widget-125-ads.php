<?php
/**
 * Zeen 125px by 125px ads
 *
 * @since 1.0.0
 *
 * @see WP_Widget
 */
class ZeenEngine125Ads extends WP_Widget {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'zeen_125',
			'description' => esc_html__( 'Add 125px by 125px advertisment spots.', 'zeen-engine' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'zeen_125', esc_html__( 'Zeen: 125px by 125px ads', 'zeen-engine' ), $widget_ops );

	}

	/**
	 * Outputs the content for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current widget instance.
	 */
	public function widget( $args, $instance ) {

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title       = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		$output      = array();
		for ( $i = 1; $i <= 10; $i++ ) {
			$output[] = ! empty( $instance[ 'ad' . $i] ) ? $instance[ 'ad' . $i] : '';
		}

		echo $args['before_widget'];
		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		} 
		?>
		<ul>
		<?php foreach ( array_filter( $output ) as $user_ad ) { ?>
			<li>
				<?php echo ( $user_ad ); ?>
			</li>
		<?php } ?>
		</ul>

		<?php
		echo $args['after_widget'];

	}

	/**
	 * Handles updating settings for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title']      = sanitize_text_field( $new_instance['title'] );
		for ( $i = 1; $i <= 10; $i++ ) {
			$instance['ad' . $i] = $new_instance['ad' . $i];
		}

		return $instance;
	}

	/**
	 * Outputs the widget settings form.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance   = wp_parse_args( (array) $instance, array( 'title' => '', 'ad1' => '', 'ad2' => '', 'ad3' => '', 'ad4' => '', 'ad5' => '', 'ad6' => '', 'ad7' => '', 'ad8' => '', 'ad9' => '', 'ad10' => '' ) );
		?>
		<p><label for="<?php echo $this->get_field_id('title'); ?>"><?php esc_html_e( 'Title', 'zeen-engine' ); ?></label>
		<input class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" type="text" value="<?php echo esc_attr( sanitize_text_field( $instance['title'] ) ); ?>" /></p>
		<?php for ( $i = 1; $i <= 10; $i++ ) { ?>
			<p><label for="<?php echo $this->get_field_id( 'ad' . $i); ?>"><?php esc_html_e( '125px Ad', 'zeen-engine' ); ?></label>
			<input class="widefat" id="<?php echo $this->get_field_id( 'ad' . $i); ?>" name="<?php echo $this->get_field_name( 'ad' . $i); ?>" type="text" value="<?php echo esc_attr(  $instance[ 'ad' . $i ] ); ?>" /></p>
		<?php } ?>      
		<?php
	}
}
