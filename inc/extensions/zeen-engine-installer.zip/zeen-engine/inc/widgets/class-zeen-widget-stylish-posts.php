<?php
/**
 * Zeen stylish articles
 *
 * @since 1.0.0
 *
 * @see WP_Widget
 */
class ZeenEngineStylishPosts extends WP_Widget {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'zeen_stylish_posts',
			'description' => esc_html__( 'Show articles with style.', 'zeen-engine' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'zeen_stylish_posts', esc_html__( 'Zeen: Stylish Articles', 'zeen-engine' ), $widget_ops );
		if ( is_active_widget( false, false, $this->id_base ) || is_customize_preview() ) {
			$settings = $this->get_settings();
			foreach ( $settings as $setting ) {
				if ( 1 === (int) $setting['design'] ) {
					$loader = true;
				}
			}
		}
		if ( ! empty( $loader ) ) {
			wp_enqueue_script( 'flickity', ZEEN_ENGINE_DIR_URL . 'admin/js/flickity.pkgd.min.js', array(), '2.2.0', true );
		}
	}

	/**
	 * Outputs the content for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current widget instance.
	 */
	public function widget( $args, $instance ) {

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title      = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		$number     = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : 4;
		$taxonomy   = ! empty( $instance['taxonomy'] ) ? $instance['taxonomy'] : 'category';
		$taxes = $this->zeen_get_taxes();
		$tax_arg = array();
		foreach ( $taxes as $key => $value ) {
			if ( 'post_tag' == $key ) {
				$tax_arg['tag'] = ! empty( $instance['tag'] ) && 'post_tag' == $taxonomy ? $instance['tag'] : '';
			} else {
				$tax_arg[ $key ] = ! empty( $instance[ $key ] ) && $key == $taxonomy ? $instance[ $key ] : array();
			}
		}

		$sort       = ! empty( $instance['sort'] ) ? $instance['sort'] : 'date';
		$uid       = ! empty( $instance['uid'] ) ? $instance['uid'] : '';
		if ( function_exists( 'zeen_uid' ) && empty( $uid ) ) {
			$uid = zeen_uid();
		}
		$date       = ! empty( $instance['date'] ) ? $instance['date'] : 1;
		$design     = ! empty( $instance['design'] ) ? $instance['design'] : 1;
		$byline_off = ! empty( $instance['byline_off'] ) && 2 == $instance['byline_off'] ? false : true;
		$counter = ! empty( $instance['counter'] ) && 2 == $instance['counter'] ? true : false;
		$load_more = ! empty( $instance['ajax'] ) && 2 == $instance['ajax'] ? '' : 2;
		$omit = ! empty( $instance['omit_current'] ) && 2 == $instance['omit_current'] ? true : false;
		$classes      = 5 == $design ? ' rounded-img' : '';
		switch ( $design ) {
			case 1:
				$p = 55;
				$load_more = '';
				break;
			case 2:
				$p = 2;
				break;
			case 3:
				$p = 23;
				break;
			case 4:
				$p = 43;
				break;
			case 5:
				$p = 23;
				break;
			default:
				$p = 55;
				break;
		}

		$trending_name = 'all-time';
		if ( 1 == $date ) {
			$paged = -1;
		} elseif ( 2 == $date ) {
			$paged = 2;
			$trending_name = 'now';
		} elseif ( 3 == $date ) {
			$paged = 7;
			$trending_name = 'week';
		} else {
			$paged = 30;
			$trending_name = 'month';
		}

		$category = '';
		$tag__in = array();
		if ( 'post_tag' == $taxonomy || 'tag' == $taxonomy ) {
			$tag = is_array( $tax_arg['tag'] ) ? $tax_arg['tag'] : explode( ',', $tax_arg['tag'] );
			foreach ( $tag as $key ) {
				if ( is_numeric( $key ) ) {
					$tag__in[] = $key;
				} else {
					$tag = get_term_by( 'name', trim( $key ), 'post_tag' );
					if ( ! empty( $tag ) ) {
						$tag__in[] = $tag->term_id;
					}
				}
			}
		} elseif ( 'category' == $taxonomy ) {
			$category = implode( ',', $tax_arg['category'] );
		} else {
			$tax = true;
		}

		$details_off = empty( $counter ) ? false : true;
		$options = array(
			'qry' => array(
				'posts_per_page'      => $number,
				'tag__in'             => $tag__in,
				'cat'                 => $category,
				'orderby'             => $sort,
			),
			'uid'             => $uid,
			'preview'         => $p,
			'excerpt_off'     => true,
			'byline_off'      => $byline_off,
			'ndp_skip'        => true,
			'contained'       => true,
			'review_off'      => $details_off,
			'block_ani'       => true,
			'counter'         => $counter,
			'separator_off'   => true,
			'load_more'       => $load_more,
			'specific'        => 'widget',
		);
		if ( ! empty( $omit ) ) {
			global $post;
			if ( ! empty( $post->ID ) ) {
				$options['qry']['post__not_in'] = array( $post->ID );
			}
		}
		if ( ! empty( $tax ) ) {
			$options['qry']['tax_query'] = array(
				'relation' => 'OR',
			);
			foreach ( $tax_arg[ $taxonomy ] as $key ) {
				$options['qry']['tax_query'][] = array(
					'taxonomy' => $taxonomy,
					'field' => 'term_id',
					'terms' => $tax_arg[ $taxonomy ],
				);
			}
			$options['qry']['post_type'] = 'any';
		}
		if ( 'trending' == $sort ) {
			$options['qry']['trending'] = array(
				'name' => 'styling-posts-' . $trending_name . $number . $uid,
				'max' => $number,
				'num' => $paged,
			);
		}

		$i = 1;
		echo ( $args['before_widget'] );
		if ( ! empty( $title ) ) {
			echo ( $args['before_title'] . $title . $args['after_title'] );
		}
		if ( function_exists( 'zeen_block_pick' ) ) {
			echo '<div class="zeen-stylish-posts-wrap' . esc_attr( $classes ) . '">';
			$block = zeen_block_pick( $options );
			$block->output();
			echo '</div>';
		}

		echo ( $args['after_widget'] );

	}

	/**
	 * Handles updating settings for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title']      = sanitize_text_field( $new_instance['title'] );
		$instance['number']     = intval( $new_instance['number'] );
		$instance['uid']     = intval( $new_instance['uid'] );
		$taxes = $this->zeen_get_taxes();
		foreach ( $taxes as $key => $value ) {
			if ( 'post_tag' == $key ) {
				$instance['tag'] = isset( $new_instance['tag'] ) ? esc_attr( $new_instance['tag'] ) : '';
			} else {
				$instance[ $key ] = isset( $new_instance[ $key ] ) && is_array( $new_instance[ $key ] ) ? array_map( 'esc_attr', $new_instance[ $key ] ) : array();

			}
		}
		if ( in_array( $new_instance['taxonomy'], $taxes ) ) {
			$instance['taxonomy'] = $new_instance['taxonomy'];
		} else {
			$instance['taxonomy'] = 'category';
		}
		if ( in_array( $new_instance['date'], array( 1, 2, 3, 4 ) ) ) {
			$instance['date'] = $new_instance['date'];
		} else {
			$instance['date'] = 'category';
		}
		if ( in_array( $new_instance['sort'], array( 'date', 'trending', 'rand' ) ) ) {
			$instance['sort'] = $new_instance['sort'];
		} else {
			$instance['sort'] = 'date';
		}
		if ( in_array( $new_instance['design'], array( 1, 2, 3, 4, 5 ) ) ) {
			$instance['design'] = $new_instance['design'];
		} else {
			$instance['design'] = 1;
		}
		if ( in_array( $new_instance['byline_off'], array( 1, 2 ) ) ) {
			$instance['byline_off'] = $new_instance['byline_off'];
		} else {
			$instance['byline_off'] = 1;
		}
		if ( in_array( $new_instance['counter'], array( 1, 2 ) ) ) {
			$instance['counter'] = $new_instance['counter'];
		} else {
			$instance['counter'] = 1;
		}

		if ( in_array( $new_instance['ajax'], array( 1, 2 ) ) ) {
			$instance['ajax'] = $new_instance['ajax'];
		} else {
			$instance['ajax'] = 1;
		}
		if ( in_array( $new_instance['omit_current'], array( 1, 2 ) ) ) {
			$instance['omit_current'] = $new_instance['omit_current'];
		} else {
			$instance['omit_current'] = 1;
		}

		return $instance;
	}

	/**
	 * Outputs the widget settings form.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$n = 0;
		$taxes = $this->zeen_get_taxes();
		$args = array(
			'title' => '',
			'number' => 4,
			'taxonomy' => 'category',
			'design' => '1',
			'byline_off' => '1',
			'counter' => '1',
			'ajax' => '1',
			'omit_current' => '1',
			'sort' => 'date',
			'date' => 1,
			'uid' => function_exists( 'zeen_uid' ) ? zeen_uid() : 1,
		);
		foreach ( $taxes as $key => $value ) {
			$terms = get_terms( $key );
			if ( empty( $terms ) ) {
				unset( $taxes[ $key ] );
			} else {
				if ( 'post_tag' == $key ) {
					$args['tag'] = '';
				} else {
					$args[ $key ] = array();
				}
			}
		}
		$instance = wp_parse_args( (array) $instance, $args );
		if ( ! empty( $instance['taxonomy'] ) && 'tag' == $instance['taxonomy'] ) {
			$instance['taxonomy'] = 'post_tag';
		}
		?>

		<input id="<?php echo esc_attr( $this->get_field_id( 'uid' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'uid' ) ); ?>" type="hidden" value="<?php echo esc_attr( $instance['uid'] ); ?>" />
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'zeen-engine' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( sanitize_text_field( $instance['title'] ) ); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'zeen-engine' ); ?></label>
		<input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="number" step="1" min="1" value="<?php echo absint( $instance['number'] ); ?>" size="3" /></p>

		<p id="zeen-engine-req-<?php echo esc_attr( $this->get_field_id( 'sort' ) ); ?>" class="zeen-engine-control" data-control="select">
			<label for="<?php echo esc_attr( $this->get_field_id( 'sort' ) ); ?>"><?php esc_html_e( 'Sort by', 'zeen-engine' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'sort' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'sort' ) ); ?>" class="widefat zeen-engine-input-val">
				<option value="date"<?php selected( $instance['sort'], 'date' ); ?>><?php esc_html_e( 'Latest', 'zeen-engine' ); ?></option>
				<option value="trending"<?php selected( $instance['sort'], 'trending' ); ?>><?php esc_html_e( 'Trending', 'zeen-engine' ); ?></option>
				<option value="rand"<?php selected( $instance['sort'], 'rand' ); ?>><?php esc_html_e( 'Random', 'zeen-engine' ); ?></option>
			</select>
		</p>
		<p id="zeen-dependee-<?php echo esc_attr( $this->get_field_id( 'date' ) ); ?>" class="zeen-engine-req" data-req="zeen-engine-req-<?php echo esc_attr( $this->get_field_id( 'sort' ) ); ?>" data-req-val="trending"  <?php if (  $instance['sort'] != 'trending' ) { ?> style="display:none;" <?php } ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( 'date' ) ); ?>"><?php esc_html_e( 'Date filter', 'zeen-engine' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'date' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'date' ) ); ?>" class="widefat zeen-engine-input-val">
				<option value="1"<?php selected( $instance['date'], '1' ); ?>><?php esc_html_e( 'All time', 'zeen-engine' ); ?></option>
				<option value="2"<?php selected( $instance['date'], '2' ); ?>><?php esc_html_e( 'Last 24 hours', 'zeen-engine' ); ?></option>
				<option value="3"<?php selected( $instance['date'], '3' ); ?>><?php esc_html_e( 'Last 7 days', 'zeen-engine' ); ?></option>
				<option value="4"<?php selected( $instance['date'], '4' ); ?>><?php esc_html_e( 'Last month', 'zeen-engine' ); ?></option>
			</select>
		</p>
		<p class="zeen-engine-control">
			<label for="<?php echo esc_attr( $this->get_field_id( 'design' ) ); ?>"><?php esc_html_e( 'Design', 'zeen-engine' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'design' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'design' ) ); ?>" class="widefat zeen-engine-input-val">
				<option value="1"<?php selected( $instance['design'], '1' ); ?>><?php esc_html_e( 'Slider', 'zeen-engine' ); ?></option>
				<option value="2"<?php selected( $instance['design'], '2' ); ?>><?php esc_html_e( 'Large Thumbnails', 'zeen-engine' ); ?></option>
				<option value="3"<?php selected( $instance['design'], '3' ); ?>><?php esc_html_e( 'Small Thumbnails', 'zeen-engine' ); ?></option>
				<option value="4"<?php selected( $instance['design'], '4' ); ?>><?php esc_html_e( 'First Large & Others Small', 'zeen-engine' ); ?></option>
				<option value="5"<?php selected( $instance['design'], '5' ); ?>><?php esc_html_e( 'Round Thumbnails', 'zeen-engine' ); ?></option>
			</select>
		</p>

		<p class="zeen-engine-control">
			<label for="<?php echo esc_attr( $this->get_field_id( 'byline_off' ) ); ?>"><?php esc_html_e( 'Byline', 'zeen-engine' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'byline_off' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'byline_off' ) ); ?>" class="widefat zeen-engine-input-val">
				<option value="1"<?php selected( $instance['byline_off'], '1' ); ?>><?php esc_html_e( 'Off', 'zeen-engine' ); ?></option>
				<option value="2"<?php selected( $instance['byline_off'], '2' ); ?>><?php esc_html_e( 'On', 'zeen-engine' ); ?></option>
			</select>
		</p>

		<p class="zeen-engine-control">
			<label for="<?php echo esc_attr( $this->get_field_id( 'counter' ) ); ?>"><?php esc_html_e( 'Countdown', 'zeen-engine' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'counter' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'counter' ) ); ?>" class="widefat zeen-engine-input-val">
				<option value="1"<?php selected( $instance['counter'], '1' ); ?>><?php esc_html_e( 'Off', 'zeen-engine' ); ?></option>
				<option value="2"<?php selected( $instance['counter'], '2' ); ?>><?php esc_html_e( 'On', 'zeen-engine' ); ?></option>
			</select>
		</p>

		<p class="zeen-engine-control">
			<label for="<?php echo esc_attr( $this->get_field_id( 'ajax' ) ); ?>"><?php esc_html_e( 'Ajax Arrows', 'zeen-engine' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'ajax' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'ajax' ) ); ?>" class="widefat zeen-engine-input-val">
				<option value="1"<?php selected( $instance['ajax'], '1' ); ?>><?php esc_html_e( 'On', 'zeen-engine' ); ?></option>
				<option value="2"<?php selected( $instance['ajax'], '2' ); ?>><?php esc_html_e( 'Off', 'zeen-engine' ); ?></option>
			</select>
		</p>

		<p class="zeen-engine-control">
			<label for="<?php echo esc_attr( $this->get_field_id( 'omit_current' ) ); ?>"><?php esc_html_e( 'Omit Current Post', 'zeen-engine' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'omit_current' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'omit_current' ) ); ?>" class="widefat zeen-engine-input-val">
				<option value="1"<?php selected( $instance['omit_current'], '1' ); ?>><?php esc_html_e( 'Off', 'zeen-engine' ); ?></option>
				<option value="2"<?php selected( $instance['omit_current'], '2' ); ?>><?php esc_html_e( 'On', 'zeen-engine' ); ?></option>
			</select>
		</p>

		<p id="zeen-engine-req-<?php echo esc_attr( $this->get_field_id( 'taxonomy' ) ); ?>" class="zeen-engine-control" data-control="select">
			<label for="<?php echo esc_attr( $this->get_field_id( 'taxonomy' ) ); ?>"><?php esc_html_e( 'Taxonomy', 'zeen-engine' ); ?></label>
			<select name="<?php echo esc_attr( $this->get_field_name( 'taxonomy' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'taxonomy' ) ); ?>" class="widefat zeen-engine-input-val">
				<?php foreach ( $taxes as $key => $value ) { ?>
					<?php $tax = get_taxonomy( $key ); ?>
					<option value="<?php echo esc_attr( $key ); ?>"<?php selected( $instance['taxonomy'], $key ); ?>><?php echo esc_attr( $tax->label ); ?></option>
				<?php } ?>
			</select>
		</p>

		<?php foreach ( $taxes as $key => $value ) { ?>
			<?php $terms = get_terms( $key ); ?>
			<?php $tax = get_taxonomy( $key ); ?>
			<p  id="zeen-dependee-<?php echo esc_attr( $this->get_field_id( $key ) ); ?>" class="zeen-engine-req zeen-engine-multi-select" data-req="zeen-engine-req-<?php echo esc_attr( $this->get_field_id( 'taxonomy' ) ); ?>" data-req-val="<?php echo esc_attr( $key );?>" <?php if ( $instance['taxonomy'] != $key ) { ?> style="display:none;" <?php } ?>>
			<label for="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>"><?php echo esc_attr( $tax->label ); ?></label>
			<?php if ( 'post_tag' == $key ) { ?>
				<span class="howto" id="new-tag-post_tag-desc"><?php esc_attr_e( 'Separate tags with commas', 'zeen-engine' ); ?></span>
				<input class="widefat tipi-tag-suggest" id="<?php echo esc_attr( $this->get_field_id( 'tag' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'tag' ) ); ?>" type="text" value="<?php echo esc_attr( $instance['tag'] ); ?>" />
			<?php } else { ?>
			<span class="howto"><?php esc_html_e( 'No selection means all are used.', 'zeen-engine' ); ?></span>
			<select multiple="multiple" name="<?php echo esc_attr( $this->get_field_name( $key ) ); ?>[]" id="<?php echo esc_attr( $this->get_field_id( $key ) ); ?>">
				<?php foreach ( $terms as $term ) { ?>
					<option value="<?php echo esc_attr( $term->term_id ); ?>"<?php selected( in_array( $term->term_id, $instance[ $key ] ), true ); ?>><?php echo esc_attr( $term->name ) . ' ( ' . intval( $term->count ) . ' )'; ?></option>
				<?php } ?>
			</select>
			<?php } ?>
			</p>
		<?php } ?>
		<?php
	}

	private function zeen_get_taxes() {
		$output = get_taxonomies( array(
			'public'   => true,
		) );
		unset( $output['product_shipping_class'] );
		unset( $output['topic-tag'] );
		return $output;
	}
}
