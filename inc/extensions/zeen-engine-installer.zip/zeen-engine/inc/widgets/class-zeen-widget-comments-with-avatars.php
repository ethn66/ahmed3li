<?php
/**
 * Zeen comments with avatar
 *
 * @since 1.0.0
 *
 * @see WP_Widget
 */
class ZeenEngineCommentsWithAvatar extends WP_Widget {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'zeen_comments_with_avatar',
			'description' => esc_html__( 'Show your site&#8217;s most recent comments with style.', 'zeen-engine' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'zeen_comments_with_avatar', esc_html__( 'Zeen: Stylish comments', 'zeen-engine' ), $widget_ops );

	}

	/**
	 * Outputs the content for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current widget instance.
	 */
	public function widget( $args, $instance ) {

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title      = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		$number     = ( ! empty( $instance['number'] ) ) ? absint( $instance['number'] ) : 4;

		$comments = get_comments( apply_filters( 'widget_comments_args', array(
			'number'      => $number,
			'status'      => 'approve',
			'post_status' => 'publish',
		) ) );

		if ( empty( $comments ) ) {
			return;
		}
		echo $args['before_widget'];
		if ( ! empty( $title ) ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		if ( is_array( $comments ) ) {
			// Prime cache for associated posts. (Prime post term cache if we need it for permalinks.)
			$post_ids = array_unique( wp_list_pluck( $comments, 'comment_post_ID' ) );
			_prime_post_caches( $post_ids, strpos( get_option( 'permalink_structure' ), '%category%' ), false );

			?>
			<ul>
			<?php foreach ( (array) $comments as $comment ) { ?>
				<li class="stylish-comment clearfix">
					<blockquote class="comment-excerpt"><?php echo wp_trim_words( $comment->comment_content , 10, '...' ); ?>
						<a class="meta tipi-vertical-c tipi-flex-wrap" href="<?php echo esc_url( get_comment_link( $comment ) ); ?>">
						<div class="tipi-vertical-c meta-elements comment-post-title-wrap">
							<i class="tipi-i-chat"></i>
							<span class="comment-post-title"><?php echo get_the_title( $comment->comment_post_ID ); ?></span>
						</div>
						<div class="tipi-vertical-c meta-elements avatar-wrap">
							<div class="author-avatar"><?php echo get_avatar( $comment, 20 ); ?></div>
							<span class="comment-author-link"><?php echo esc_html( $comment->comment_author ); ?></span>
						</div>
						</a>
					</blockquote>
				</li>
			<?php } ?>
			</ul>

			<?php

		}
		echo $args['after_widget'];

	}

	/**
	 * Handles updating settings for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title']      = sanitize_text_field( $new_instance['title'] );
		$instance['number']     = intval( $new_instance['number'] );
		return $instance;
	}

	/**
	 * Outputs the widget settings form.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance   = wp_parse_args( (array) $instance, array(
			'title' => '',
			'number' => 4,
		));
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'zeen-engine' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( sanitize_text_field( $instance['title'] ) ); ?>" /></p>

		<p><label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of comments to show:', 'zeen-engine' ); ?></label>
		<input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="number" step="1" min="1" value="<?php echo absint( $instance['number'] ); ?>" size="3" /></p>

		<?php
	}
}
