<?php
/**
 * Zeen Facebook Like box
 *
 * @since 1.0.0
 *
 * @see WP_Widget
 */
class ZeenEngineFacebookLikeBox extends WP_Widget {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'zeen_facebook_like_box',
			'description' => esc_html__( 'A responsive Facebook Like Box', 'zeen-engine' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'zeen_facebook_like_box', esc_html__( 'Zeen: Facebook Like Box', 'zeen-engine' ), $widget_ops );
	}


	/**
	 * Outputs the content for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current widget instance.
	 */
	public function widget( $args, $instance ) {

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title      = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		$url        = ! empty( $instance['url'] ) ? $instance['url'] : '';
		$faces      = ! empty( $instance['faces'] ) ? 'true' : 'false';
		$cover      = ! empty( $instance['cover'] ) ? 'true' : 'false';
		$header     = ! empty( $instance['header'] ) ? 'true' : 'false';
		$timeline   = ! empty( $instance['timeline'] ) ? 'timeline' : '';
		$posts      = ! empty( $instance['posts'] ) ? 'posts' : '';
		$fb_app_id = get_theme_mod( 'facebook_app_id' );
		echo ( $args['before_widget'] );
		if ( ! empty( $title ) ) {
			echo ( $args['before_title'] . $title . $args['after_title'] );
		} ?>
		<div class="fb-page"
			  data-href="<?php echo esc_url( 'https://www.facebook.com/' . $url ); ?>"
			  data-width="600"
			  data-hide-cover="<?php echo esc_attr( $cover ); ?>"
			  data-show-facepile="<?php echo esc_attr( $faces ); ?>"
			  data-small-header="<?php echo esc_attr( $header ); ?>"
			  data-tabs="<?php echo esc_attr( $timeline ); ?>"
			  data-show-posts="false"></div>

	<div id="fb-root"></div>
	<script>(function(d, s, id) {
		var js, fjs = d.getElementsByTagName(s)[0];
		if (d.getElementById(id)) return;
		js = d.createElement(s); js.id = id;
		js.src = 'https://connect.facebook.net/<?php echo esc_attr( get_locale() ); ?>/sdk.js#xfbml=1&version=v3.2<?php
		if ( ! empty( $fb_app_id ) ) {
			echo '&appId=' . esc_attr( $fb_app_id );
		}
		?>';
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));</script>

		<?php
		echo ( $args['after_widget'] );
	}

	/**
	 * Handles updating settings for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title']      = sanitize_text_field( $new_instance['title'] );
		$instance['url']        = esc_attr( $new_instance['url'] );
		$instance['faces']      = $new_instance['faces'] ? 1 : 0;
		$instance['cover']      = $new_instance['cover'] ? 1 : 0;
		$instance['posts']      = $new_instance['posts'] ? 1 : 0;
		$instance['header']     = $new_instance['header'] ? 1 : 0;
		$instance['timeline']   = $new_instance['timeline'] ? 1 : 0;
		return $instance;
	}

	/**
	 * Outputs the widget settings form.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$instance = wp_parse_args( (array) $instance, array( 'title' => '', 'url' => '', 'faces' => 1, 'posts' => '', 'timeline' => '', 'header' => '', 'cover' => '' ) );
		$title = sanitize_text_field( $instance['title'] );
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id('title') ); ?>"><?php esc_html_e( 'Title', 'zeen-engine' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id('title') ); ?>" name="<?php echo esc_attr( $this->get_field_name('title') ); ?>" type="text" value="<?php echo esc_attr($title); ?>" /></p>

		<p>
			<label for="<?php echo esc_attr( $this->get_field_id( 'url' ) ); ?>"><?php esc_html_e( 'Page Url', 'zeen-engine' );  ?></label>
			<input type="text" value="<?php echo esc_attr( $instance['url'] ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'url' ) ); ?>" id="<?php echo esc_attr( $this->get_field_id( 'url' ) ); ?>" class="widefat" />
			<br />
			<small><?php esc_html_e( 'Everything after facebook.com/', 'zeen-engine' ); ?></small>
		</p>
		<p>
			<input class="checkbox" type="checkbox"<?php checked( $instance['faces'] ); ?> id="<?php echo esc_attr( $this->get_field_id('faces') ); ?>" name="<?php echo esc_attr( $this->get_field_name('faces') ); ?>" /> <label for="<?php echo esc_attr( $this->get_field_id('faces') ); ?>"><?php esc_html_e( "Show friend's faces", 'zeen-engine' ); ?></label><br/>
			<input class="checkbox" type="checkbox"<?php checked( $instance['posts'] ); ?> id="<?php echo esc_attr( $this->get_field_id('posts') ); ?>" name="<?php echo esc_attr( $this->get_field_name('posts') ); ?>" /> <label for="<?php echo esc_attr( $this->get_field_id('posts') ); ?>"><?php esc_html_e( 'Show posts', 'zeen-engine' ); ?></label><br/>
			<input class="checkbox" type="checkbox"<?php checked( $instance['timeline'] ); ?> id="<?php echo esc_attr( $this->get_field_id('timeline') ); ?>" name="<?php echo esc_attr( $this->get_field_name('timeline') ); ?>" /> <label for="<?php echo esc_attr( $this->get_field_id('timeline') ); ?>"><?php esc_html_e( 'Show timeline', 'zeen-engine' ); ?></label><br/>
			<input class="checkbox" type="checkbox"<?php checked( $instance['cover'] ); ?> id="<?php echo esc_attr( $this->get_field_id('cover') ); ?>" name="<?php echo esc_attr( $this->get_field_name('cover') ); ?>" /> <label for="<?php echo esc_attr( $this->get_field_id('cover') ); ?>"><?php esc_html_e( 'Hide cover photo', 'zeen-engine' ); ?></label><br/>
			<input class="checkbox" type="checkbox"<?php checked( $instance['header'] ); ?> id="<?php echo esc_attr( $this->get_field_id('header') ); ?>" name="<?php echo esc_attr( $this->get_field_name('header') ); ?>" /> <label for="<?php echo esc_attr( $this->get_field_id('header') ); ?>"><?php esc_html_e( 'Use small header', 'zeen-engine' ); ?></label><br/>
		</p>

		<?php
	}
}
