<?php
/**
 *
 * Zeen Engine
 *
 * @since      1.0.0
 *
 * @package    Zeen Engine
 * @subpackage zeen-engine/inc
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Zeen_Engine {

	public static function init() {
		$class = __CLASS__;
		new $class();
	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	*/
	public function __construct() {

		$this->version  = '2.8.2';
		$this->slug     = 'zeen-engine';
		$this->url      = plugin_dir_url( dirname( __FILE__ ) );
		$this->dir_path = plugin_dir_path( dirname( __FILE__ ) );
		$this->zeen_engine_loader();
		$this->zeen_engine_locale();
		$this->zeen_engine_amp();
		$this->zeen_engine_blocks();
		if ( is_admin() ) {
			$this->zeen_engine_admin();
		}
		add_action( 'widgets_init', array( $this, 'zeen_engine_widgets' ) );
		add_filter( 'user_contactmethods', array( $this, 'zeen_engine_contact_methods' ) );
		add_action( 'admin_bar_menu', array( $this, 'zeen_engine_maybe_admin_bar' ), 100 );
	}

	/**
	 * Zeen Engine Loader
	 *
	 * @since 1.0.0
	 */
	private function zeen_engine_loader() {
		if ( get_theme_mod( 'separate_mobile_bucket' ) == 1 && ! class_exists( 'Mobile_Detect' ) ) {
			require_once $this->dir_path . 'admin/Mobile_Detect.php';
		}
		require_once $this->dir_path . 'admin/class-zeen-engine-admin.php';
		require_once $this->dir_path . 'admin/class-zeen-engine-meta.php';
		require_once $this->dir_path . 'admin/meta-boxes.php';
		require_once $this->dir_path . 'admin/class-zeen-engine-tax.php';
		require_once $this->dir_path . 'admin/taxonomy.php';
		require_once $this->dir_path . 'admin/login.php';
		require_once $this->dir_path . 'admin/class-zeen-engine-options.php';
		require_once $this->dir_path . 'admin/class-zeen-engine-settings.php';
		require_once $this->dir_path . 'inc/class-zeen-engine-i18n.php';
		require_once $this->dir_path . 'inc/ip/ip.php';
		require_once $this->dir_path . 'inc/zeen-engine-sanitizers.php';
		require_once $this->dir_path . 'admin/class-zeen-engine-blocks.php';
	}

	/**
	 * Zeen Engine Widgets
	 *
	 * @since 1.0.0
	 */
	public function zeen_engine_widgets() {
		require $this->dir_path . 'inc/widgets/class-zeen-widget-125-ads.php';
		register_widget( 'ZeenEngine125Ads' );
		require $this->dir_path . 'inc/widgets/class-zeen-widget-facebook-like-box.php';
		register_widget( 'ZeenEngineFacebookLikeBox' );
		require $this->dir_path . 'inc/widgets/class-zeen-widget-stylish-posts.php';
		register_widget( 'ZeenEngineStylishPosts' );
		require $this->dir_path . 'inc/widgets/class-zeen-widget-comments-with-avatars.php';
		register_widget( 'ZeenEngineCommentsWithAvatar' );
		require $this->dir_path . 'inc/widgets/class-zeen-widget-social-icons.php';
		register_widget( 'ZeenEngineSocialIcons' );
		require $this->dir_path . 'inc/widgets/class-zeen-widget-retina-image.php';
		register_widget( 'ZeenEngineRetinaImage' );
		require $this->dir_path . 'inc/widgets/class-zeen-widget-video.php';
		register_widget( 'ZeenEngineVideo' );
		require $this->dir_path . 'inc/widgets/class-zeen-widget-about-me.php';
		register_widget( 'ZeenAboutMe' );
	}


	/**
	 * Zeen Engine Backend Loader
	 *
	 * @since    1.0.0
	 */
	private function zeen_engine_admin() {
		new Zeen_Engine_Settings();
		$admin = new Zeen_Engine_Admin( $this->slug, $this->version, $this->url );
		add_action( 'admin_enqueue_scripts', array( $admin, 'scripts' ) );
		add_action( 'wp_ajax_zeen_engine_migration', array( $admin, 'zeen_engine_migration' ) );
		add_action( 'wp_ajax_nopriv_zeen_engine_migration', array( $admin, 'zeen_engine_migration' ) );
	}

	/**
	 * Zeen Engine Blocks
	 *
	 * @since    1.0.0
	 */
	public function zeen_engine_blocks() {
		$block = new Zeen_Engine_Blocks( $this->slug, $this->version, $this->url );
		add_filter( 'block_categories', array( $block, 'zeen_engine_block_category' ), 10, 2 );
		add_action( 'enqueue_block_editor_assets', array( $block, 'zeen_engine_block_editor_assets' ) );
	}

	function zeen_engine_maybe_admin_bar( $wp_admin_bar ) {
		if ( is_admin() || ! current_user_can( 'edit_others_pages' ) || ! function_exists( 'zeen_enqueue_scripts_admin' ) ) {
			return;
		}
		$shop = function_exists( 'is_shop' ) && is_shop();
		if ( is_page() || ! empty( $shop ) ) {
			$pid = empty( $shop ) ? get_the_ID() : get_option( 'woocommerce_shop_page_id' );
			$builder = get_post_meta( $pid, 'tipi_builder_active', true );
			if ( ! empty( $builder ) ) {
				$url = add_query_arg(
					array(
						'tipi_builder' => '1',
						'pid'          => $pid,
					),
					get_permalink( $pid )
				);
			}
		} elseif ( is_category() || is_tag() || is_tax() ) {
			$term    = get_queried_object();
			$builder = get_term_meta( $term->term_id, 'tipi_builder_active', true );
			if ( ! empty( $builder ) ) {
				$url = get_term_link( intval( $term->term_id ), $term->taxonomy );
				$url = add_query_arg(
					array(
						'tipi_builder' => '1',
						'tid'          => $term->term_id,
						'tax'          => $term->taxonomy,
					),
					$url
				);
			}
		}
		if ( empty( $url ) ) {
			return;
		}
		$args = array(
			'id'    => 'tipi-builder-menu',
			'title' => '<i class="tipi-i-builder" aria-hidden="true"></i> ' . esc_attr__( 'Edit With Tipi Builder', 'zeen-engine' ),
			'href'  => $url,
		);
		$wp_admin_bar->add_node( $args );
	}

	/**
	 * Custom contact methods
	 *
	 * @since 1.0.0
	 */
	function zeen_engine_contact_methods( $contactmethods = array() ) {

		if ( ! is_admin() ) {
			return $contactmethods;
		}
		$contactmethods['publicemail'] = 'Zeen: ' . esc_html__( 'Public Email', 'zeen-engine' );
		$contactmethods['twitter']     = 'Zeen: Twitter ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['facebook']    = 'Zeen: Facebook ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['patreon']     = 'Zeen: Patreon ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['instagram']   = 'Zeen: Instagram ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['linkedin']    = 'Zeen: LinkedIn ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['twitch']      = 'Zeen: Twitch ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['youtube']     = 'Zeen: YouTube ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['pinterest']   = 'Zeen: Pinterest ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['medium']      = 'Zeen: Medium ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['tiktok']      = 'Zeen: TikTok ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['soundcloud']  = 'Zeen: Soundcloud ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['spotify']     = 'Zeen: Spotify ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['apple_music'] = 'Zeen: Apple Music ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['vimeo']       = 'Zeen: Vimeo ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['vk']          = 'Zeen: VK ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['goodreads']   = 'Zeen: Goodreads ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['itch']   = 'Zeen: Itch.io ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['producthunt']   = 'Zeen: Product Hunt ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['letterboxd']   = 'Zeen: Letterboxd ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['imdb']        = 'Zeen: IMDB ' . esc_html__( '(Full URL)', 'zeen-engine' );
		$contactmethods['position']    = 'Zeen: ' . esc_html__( 'Job title', 'zeen-engine' );

		return $contactmethods;

	}

	/**
	 * Zeen Engine Translation Loader
	 *
	 * @since 1.0.0
	 */
	public function zeen_engine_locale() {

		$i18n = new Zeen_Engine_I18n();
		add_action( 'init', array( $i18n, 'zeen_engine_textdomain' ) );

	}

	/**
	 * Share buttons
	 *
	 * @since 1.0.0
	 */
	public static function zeen_engine_share( $args = array() ) {
		if ( empty( $args['pid'] ) ) {
			global $post;
			$pid = $post->ID;
		} else {
			$pid = $args['pid'];
		}
		$url      = get_permalink( $pid );
		$type     = empty( $args['type'] ) ? 'all' : $args['type'];
		$class    = empty( $args['class'] ) ? '' : $args['class'];
		$hook     = empty( $args['hook'] ) ? '' : $args['hook'];
		$mod      = empty( $args['mod'] ) ? 'single' : $args['mod'];
		$location = empty( $args['location'] ) ? '' : $args['location'];
		$override = empty( $args['override'] ) ? '' : true;

		$single_share_before = get_post_meta( $pid, 'zeen_share_block_before', true );
		if ( empty( $single_share_before ) || 99 == $single_share_before ) {
			$share_before = get_theme_mod( 'single_before_share' );
		} elseif ( 1 == $single_share_before ) {
			$share_before = 1;
		} elseif ( 2 == $single_share_before ) {
			$share_before = '';
		}

		$single_share_below_title = get_post_meta( $pid, 'zeen_share_block_below_title', true );
		if ( empty( $single_share_below_title ) || 99 == $single_share_below_title ) {
			$share_below_title = get_theme_mod( 'single_below_title_share' );
		} elseif ( 1 == $single_share_below_title ) {
			$share_below_title = 1;
		} elseif ( 2 == $single_share_below_title ) {
			$share_below_title = '';
		}

		$single_share_end = get_post_meta( $pid, 'zeen_share_block_end', true );
		if ( empty( $single_share_end ) || 99 == $single_share_end ) {
			$share_end = get_theme_mod( 'single_end_share', 1 );
		} elseif ( 1 == $single_share_end ) {
			$share_end = 1;
		} elseif ( 2 == $single_share_end ) {
			$share_end = '';
		}

		if ( 'below_title' == $hook && 1 != $share_below_title || 'before' == $hook && 1 != $share_before || 'after' == $hook && 1 != $share_end ) {
			return;
		}
		$d          = empty( $args['design'] ) ? get_theme_mod( 'single_share_design', 1 ) : $args['design'];
		$c          = empty( $args['counts'] ) ? get_theme_mod( 'single_share_counts' ) : $args['counts'];
		$fb_app_id  = get_theme_mod( 'facebook_app_id' );
		$class_wrap = '';
		$tip        = true;
		$tip_move   = true;

		if ( $d < 20 ) {
			$icon       = true;
			$class_wrap = 'icons';
		}

		if ( $d < 10 ) {
			$class_wrap = 'bold';
		}

		if ( 2 == $d || 12 == $d ) {
			$tip        = '';
			$tip_move   = '';
			$tweet_text = true;
		}

		if ( $d > 20 ) {
			$text       = true;
			$class_wrap = 'text';
		}

		$networks = array();

		if ( get_theme_mod( $mod . '_share_fb', 1 ) == 1 || 'facebook' == $type || 'top' == $type || ! empty( $override ) ) {
			$networks['facebook'] = array(
				'url'   => 'https://www.facebook.com/sharer/sharer.php?u=',
				'short' => 'fb',
				'tip'   => esc_attr__( 'Share', 'zeen-engine' ),
				'name'  => 'Facebook',
				'icon'  => 'tipi-i-facebook',
			);
		}

		if ( get_theme_mod( $mod . '_share_tw', 1 ) == 1 || 'twitter' == $type || 'top' == $type || ! empty( $override ) ) {
			$twitter_url = 'https://twitter.com/intent/tweet?';
			if ( get_theme_mod( 'icons_twitter' ) != '' ) {
				$twitter_url .= 'via=' . get_theme_mod( 'icons_twitter' ) . '&';
			}
			$twitter_url        .= 'text=';
			$networks['twitter'] = array(
				'url'   => $twitter_url,
				'short' => 'tw',
				'tip'   => esc_attr__( 'Tweet', 'zeen-engine' ),
				'name'  => 'Twitter',
				'icon'  => 'tipi-i-twitter',
			);
		}

		if ( 'top' != $type ) {
			if ( get_theme_mod( $mod . '_share_pin', 1 ) == 1 ) {
				$networks['pinterest'] = array(
					'url'   => 'https://www.pinterest.com/pin/create/button/?url=',
					'short' => 'pin',
					'tip'   => esc_attr__( 'Pin', 'zeen-engine' ),
					'name'  => 'Pinterest',
					'icon'  => 'tipi-i-pinterest',
				);
			}
			if ( get_theme_mod( $mod . '_share_li' ) == 1 ) {
				$networks['linkedin'] = array(
					'url'   => 'https://www.linkedin.com/shareArticle?url=',
					'short' => 'li',
					'tip'   => esc_attr__( 'Share', 'zeen-engine' ),
					'name'  => 'Linkedin',
					'icon'  => 'tipi-i-linkedin',
				);
			}

			if ( get_theme_mod( $mod . '_share_flip' ) == 1 ) {
				$networks['flipboard'] = array(
					'url'   => 'https://share.flipboard.com/bookmarklet/popout?v=2&title=',
					'short' => 'flip',
					'tip'   => esc_attr__( 'Share', 'zeen-engine' ),
					'name'  => 'Flipboard',
					'icon'  => 'tipi-i-flipboard',
				);
			}

			if ( get_theme_mod( $mod . '_share_tu' ) == 1 ) {
				$networks['tumblr'] = array(
					'url'   => 'https://www.tumblr.com/widgets/share/tool?canonicalUrl=',
					'short' => 'tu',
					'tip'   => esc_attr__( 'Share', 'zeen-engine' ),
					'name'  => 'Tumblr',
					'icon'  => 'tipi-i-tumblr',
				);
			}
			if ( get_theme_mod( $mod . '_share_re' ) == 1 ) {
				$networks['reddit'] = array(
					'url'   => 'https://reddit.com/submit?url=',
					'short' => 're',
					'tip'   => esc_attr__( 'Submit', 'zeen-engine' ),
					'name'  => 'Reddit',
					'icon'  => 'tipi-i-reddit-alien',
				);
			}

			if ( get_theme_mod( $mod . '_share_hatena' ) == 1 ) {
				$networks['hatena'] = array(
					'url'   => 'http://b.hatena.ne.jp/entry/',
					'short' => 'hatena',
					'tip'   => esc_attr__( 'Share', 'zeen-engine' ),
					'name'  => 'Hatena',
					'icon'  => 'tipi-i-hatena',
				);
			}

			if ( get_theme_mod( $mod . '_share_vk' ) == 1 ) {
				$networks['vk'] = array(
					'url'   => 'https://vk.com/share.php?url=',
					'short' => 'vk',
					'tip'   => esc_attr__( 'Share', 'zeen-engine' ),
					'name'  => 'VK',
					'icon'  => 'tipi-i-vk',
				);
			}
			if ( get_theme_mod( $mod . '_share_pocket' ) == 1 ) {
				$networks['pocket'] = array(
					'url'   => 'https://getpocket.com/save?url=',
					'short' => 'pocket',
					'tip'   => esc_attr__( 'Save', 'zeen-engine' ),
					'name'  => 'Pocket',
					'icon'  => 'tipi-i-pocket',
				);
			}
			if ( get_theme_mod( $mod . '_share_instapaper' ) == 1 ) {
				$networks['instapaper'] = array(
					'url'   => 'https://www.instapaper.com/text?u=',
					'short' => 'instapaper',
					'tip'   => esc_attr__( 'Save', 'zeen-engine' ),
					'name'  => 'Instapaper',
					'icon'  => 'tipi-i-instapaper',
				);
			}

			if ( get_theme_mod( $mod . '_share_em' ) == 1 ) {
				$networks['email'] = array(
					'url'   => 'mailto:?body=',
					'short' => 'em',
					'tip'   => esc_attr__( 'Email', 'zeen-engine' ),
					'name'  => 'Email',
					'icon'  => 'tipi-i-mail',
				);
			}
		}

		if ( get_theme_mod( $mod . '_share_wa' ) == 1 || 'whatsapp' == $type || 'top' == $type || ! empty( $override ) ) {
			$networks['whatsapp'] = array(
				'url'   => 'whatsapp://send?text=',
				'short' => 'wa',
				'tip'   => esc_attr__( 'Share', 'zeen-engine' ),
				'name'  => 'Whatsapp',
				'icon'  => 'tipi-i-whatsapp',
			);
		}

		if ( get_theme_mod( $mod . '_share_line' ) == 1 || 'line' == $type || ! empty( $override ) ) {
			$networks['line'] = array(
				'url'   => 'https://lineit.line.me/share/ui?url=',
				'short' => 'lm',
				'tip'   => esc_attr__( 'Share', 'zeen-engine' ),
				'name'  => 'Line.me',
				'icon'  => 'tipi-i-line',
			);
		}

		if ( get_theme_mod( $mod . '_share_telegram' ) == 1 || 'telegram' == $type || ! empty( $override ) ) {
			$networks['telegram'] = array(
				'url'   => 'https://telegram.me/share/url?url=',
				'short' => 'tg',
				'tip'   => esc_attr__( 'Share', 'zeen-engine' ),
				'name'  => 'Telegram',
				'icon'  => 'tipi-i-telegram',
			);
		}

		if ( get_theme_mod( $mod . '_share_viber' ) == 1 || 'viber' == $type || ! empty( $override ) ) {
			$networks['viber'] = array(
				'url'   => 'viber://forward?text=',
				'short' => 'vb',
				'tip'   => esc_attr__( 'Share', 'zeen-engine' ),
				'name'  => 'Viber',
				'icon'  => 'tipi-i-viber',
			);
		}

		if ( ( ( ! empty( $hook ) || 'top' == $type ) && get_theme_mod( $mod . '_share_msg' ) == 1 ) || ( 'messenger' == $type && ! empty( $override ) ) ) {
			$networks['messenger'] = array(
				'url'    => 'fb-messenger://share/?link=',
				'short'  => 'msg',
				'tip'    => esc_attr__( 'Share', 'zeen-engine' ),
				'name'   => 'Messenger',
				'app_id' => $fb_app_id,
				'icon'   => 'tipi-i-messenger',
			);
		}

		$class_count = 0;
		if ( ! empty( $c ) && empty( $args['ipl'] ) ) {

			$counts = apply_filters( 'zeen_engine_social_count', get_transient( 'zeen-engine-social-count-' . (int) ( $pid ) ), $pid );
			if ( false === $counts ) {
				$counts = array();
				if ( get_theme_mod( $mod . '_share_pin', 1 ) == 1 ) {
					$request = wp_remote_get( 'https://api.pinterest.com/v1/urls/count.json?callback=receiveCount&url=' . $url );
					if ( ! is_wp_error( $request ) ) {
						$body = wp_remote_retrieve_body( $request );
						$body = strstr( $body, '(' );
						$body = json_decode( substr( $body, 1, -1 ) );
						if ( isset( $body->count ) ) {
							$counts['pinterest'] = $body->count;
						}
					}
				}
				if ( get_theme_mod( $mod . '_share_tu' ) == 1 ) {
					$request = wp_remote_get( 'https://api.tumblr.com/v2/share/stats?url=' . $url );
					if ( ! is_wp_error( $request ) ) {
						$body = wp_remote_retrieve_body( $request );
						$body = json_decode( $body );
						if ( isset( $body->response->note_count ) ) {
							$counts['tumblr'] = $body->response->note_count;
						}
					}
				}
				if ( get_theme_mod( $mod . '_share_re' ) == 1 ) {
					$request = wp_remote_get( 'https://www.reddit.com/api/info.json?url=' . $url );
					if ( ! is_wp_error( $request ) ) {
						$body = wp_remote_retrieve_body( $request );
						$body = json_decode( $body );
						if ( isset( $body->data->children['0']->data->ups ) ) {
							$counts['reddit'] = $body->data->children['0']->data->ups;
						}
					}
				}
				if ( get_theme_mod( $mod . '_share_hatena' ) == 1 ) {
					$request = wp_remote_get( 'https://bookmark.hatenaapis.com/count/entry?url=' . $url );
					if ( ! is_wp_error( $request ) ) {
						$body = wp_remote_retrieve_body( $request );
						$body = json_decode( $body );
						if ( isset( $body->data->children['0']->data->ups ) ) {
							$counts['hatena'] = $body->data->children['0']->data->ups;
						}
					}
				}
				if ( get_theme_mod( $mod . '_share_fb', 1 ) == 1 ) {
					$request = wp_remote_get( 'https://graph.facebook.com/v3.0?id=' . $url . '&fields=engagement&access_token=' . get_theme_mod( 'facebook_app_id' ) . '|' . get_theme_mod( 'facebook_app_secret' ) );
					if ( ! is_wp_error( $request ) ) {
						$body = wp_remote_retrieve_body( $request );
						$body = json_decode( $body );
						if ( isset( $body->engagement->share_count ) ) {
							$counts['facebook'] = $body->engagement->share_count;
						}
					}
				}
				if ( get_theme_mod( $mod . '_share_tw', 1 ) == 1 ) {
					$request = wp_remote_get( 'https://opensharecount.com/count.json?url=' . $url );
					if ( ! is_wp_error( $request ) ) {
						$body = wp_remote_retrieve_body( $request );
						$body = json_decode( $body );
						if ( isset( $body->count ) ) {
							$counts['twitter'] = $body->count;
						}
					}
					if ( empty( $counts['twitter'] ) ) {
						$request = wp_remote_get( 'https://counts.twitcount.com/counts.php?url=' . $url );
						if ( ! is_wp_error( $request ) ) {
							$body = wp_remote_retrieve_body( $request );
							$body = json_decode( $body );
							if ( isset( $body->count ) ) {
								$counts['twitter'] = $body->count;
							}
						}
					}
				}
				if ( get_theme_mod( $mod . '_share_li' ) == 1 ) {
					$request = wp_remote_get( 'https://www.linkedin.com/countserv/count/share?url=' . $url . '&format=json' );
					if ( ! is_wp_error( $request ) ) {
						$body = wp_remote_retrieve_body( $request );
						$body = json_decode( $body );
						if ( isset( $body->count ) ) {
							$counts['linkedin'] = $body->count;
						}
					}
				}

				if ( ! empty( $counts ) ) {
					$counts['total'] = 0;
					foreach ( $counts as $count ) {
						$counts['total'] = (int) $count + $counts['total'];
					}
				}

				set_transient( 'zeen-engine-social-count-' . (int) ( $pid ), $counts, 12 * HOUR_IN_SECONDS );
			}
			$class_count = 1;
		}

		if ( 'all' == $type || 'top' == $type ) {
			echo '<div class="share-it share-it-' . (int) ( $d ) . ' share-it-' . esc_attr( $class_wrap ) . ' share-it-count-' . (int) ( $class_count );

			if ( ! empty( $hook ) ) {
				echo ' share-it-' . esc_attr( $hook );
			}

			if ( $d < 3 ) {
				echo ' tipi-flex';
			}
			echo '">';
		}
		if ( empty( $location ) && ( $d > 20 || 11 == $d ) && empty( $args['block_title_off'] ) ) {
			echo '<div class="title">';
			esc_attr_e( 'Share', 'zeen-engine' );
			echo '</div>';
		}

		if ( ! empty( $args['show_total'] ) && isset( $counts['total'] ) && $counts['total'] > 0 ) {
			echo '<div class="title">';
			echo '<span class="total-shares-count font-1">' . (int) $counts['total'] . '</span><span class="total-shares-title font-2">' . esc_attr( sprintf( _n( 'share', 'shares', $counts['total'], 'zeen' ), $counts['total'] ) ) . '</span>';
			echo '</div>';
		}

		foreach ( $networks as $key => $value ) {
			if ( 'all' == $type || 'top' == $type || $key == $type ) {
				echo '<a href="';

				if ( 'whatsapp' == $key || 'messenger' == $key || 'viber' == $key || 'line' == $key || 'flipboard' == $key ) {
					echo zeen_engine_sanitize_wp_kses( $value['url'] );
					if ( 'whatsapp' == $key || 'viber' == $key ) {
						the_title_attribute(
							array(
								'post' => $pid,
							)
						);
						echo ' – ';
					}
					if ( 'flipboard' == $key ) {
						the_title_attribute(
							array(
								'post' => $pid,
							)
						);
						echo '&url=';
					}
				} else {
					echo esc_url( $value['url'] );
				}
				if ( 'twitter' == $key ) {
					echo rawurlencode(
						html_entity_decode(
							get_the_title(
								$pid
							),
							ENT_COMPAT,
							'UTF-8'
						) . ' - '
					);
				}
				echo rawurlencode( $url );
				if ( 'line' == $key ) {
					echo '&text=';
					the_title_attribute(
						array(
							'post' => $pid,
						)
					);
				}
				if ( 'pinterest' == $key ) {
					echo '&media=' . esc_attr( rawurlencode( get_the_post_thumbnail_url( $pid, 'zeen-770-full' ) ) );
					echo '&description=' . esc_attr( rawurlencode( get_the_title( $pid ) ) );
				}

				if ( ! empty( $value['app_id'] ) ) {
					echo '&app_id=' . esc_attr( $value['app_id'] );
				}
				echo '" ';

				echo 'class="';

				if ( ! empty( $tip ) ) {
					echo 'tipi-tip';
				}
				if ( ! empty( $tip_move ) ) {
					echo ' tipi-tip-move';
				}
				if ( 'whatsapp' == $key || 'messenger' == $key || 'viber' == $key ) {
					echo ' tipi-xl-0';
				}
				echo esc_attr( $class ) . ' share-button share-button-' . esc_attr( $value['short'] ) . '"';

				echo ' rel="noopener nofollow" aria-label="' . esc_attr( $value['tip'] ) . '" data-title="' . esc_attr( $value['tip'] ) . '"';

				if ( 'whatsapp' != $key && 'messenger' != $key && 'line' != $key ) {
					echo ' target="_blank"';
				}

				if ( 'pinterest' == $key ) {
					echo ' data-pin-custom="true"';
				}

				echo '><span class="share-button-content tipi-vertical-c">';
				if ( ! empty( $icon ) ) {
					echo '<i class="' . esc_attr( $value['icon'] ) . '"></i>';
				}
				$font_share = get_theme_mod( 'typo_share_buttons', 1 );
				if ( ! empty( $text ) ) {
					echo '<span class="font-' . (int) $font_share . '">' . esc_html( $value['name'] ) . '</span>';
				}
				if ( ! empty( $tweet_text ) ) {
					echo '<span class="social-tip font-base font-' . (int) $font_share . '">' . esc_html( $value['tip'] ) . '</span>';
				}
				if ( ! empty( $counts ) ) {
					if ( ! empty( $counts[ $key ] ) ) {
						if ( $counts[ $key ] > 1000 ) {
							$number = ( round( (int) $counts[ $key ] / 1000, 1 ) + 0 ) . 'k';
						} else {
							$number = number_format( (float) $counts[ $key ] );
						}
						echo '<span class="social-count font-base font-' . (int) $font_share . '">' . esc_attr( $number ) . '</span>';
					}
				}

				echo '</span></a>';
			}
		}
		if ( 'all' == $type || 'top' == $type ) {
			echo '</div>';
		}
	}
	/**
	 * Share buttons
	 *
	 * @since 1.0.0
	 */
	public function zeen_engine_amp() {
		add_filter(
			'amp_post_template_data',
			function( $data ) {
				$data['font_urls']['FontAwesome']                  = 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css';
				$data['amp_component_scripts']['amp-sidebar']      = 'https://cdn.ampproject.org/v0/amp-sidebar-0.1.js';
				$data['amp_component_scripts']['amp-social-share'] = 'https://cdn.ampproject.org/v0/amp-social-share-0.1.js';
				$data['amp_component_scripts']['amp-ad']           = 'https://cdn.ampproject.org/v0/amp-ad-0.1.js';
				$data['amp_component_scripts']['amp-carousel']     = 'https://cdn.ampproject.org/v0/amp-carousel-0.1.js';
				return $data;
			}
		);
	}
}
