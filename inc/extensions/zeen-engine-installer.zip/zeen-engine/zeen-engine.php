<?php
/*!
Plugin Name: Zeen Engine
Plugin URI: https://www.codetipi.com
Author: Codetipi
Author URI: https://www.codetipi.com
Description: Zeen theme engine
Version: 2.8.2
Text Domain: zeen-engine
License: http://codecanyon.net/licenses/regular_extended
License URI: http://codecanyon.net/licenses/regular_extended
Requires at least: 5.0
Tested up to: 5.7.0
Domain Path: /languages/
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

require plugin_dir_path( __FILE__ ) . 'inc/class-zeen-engine.php';

$url = plugin_dir_url( __FILE__ );
define( 'ZEEN_ENGINE_DIR_URL', $url );
define( 'ZEEN_ENGINE_VER', '2.8.2' );
/**
* Let's fire it up
*
* @since 1.0.0
*/
add_action( 'plugins_loaded', array( 'Zeen_Engine', 'init' ) );
