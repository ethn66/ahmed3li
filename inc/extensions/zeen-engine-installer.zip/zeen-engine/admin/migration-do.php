<?php
/**
 * Migration
 *
 * @package Zeen_Engine
 * @since 1.0.0
 */

/**
 * Scripts
 *
 * @since 1.0.0
 */

function zeen_engine_migration_do( $type = '' ) {
	$qry = new WP_Query( array(
		'posts_per_page'    => -1,
		'fields'            => 'ids',
		'post_type'         => 'any',
	) );

	if ( ! empty( $qry->posts ) ) {
		foreach ( $qry->posts as $pid ) {
			if ( 'valenti' == $type || '15zine' == $type ) {
				$url_v = get_post_meta( $pid, 'cb_video_embed_code_post', true );
				$fi_base = get_post_meta( $pid, 'cb_featured_image_style', true );
				$url_a = 'valenti' == $type ? get_post_meta( $pid, 'cb_soundcloud_embed_code_post', true ) : get_post_meta( $pid, 'cb_audio_post_url', true );
				if ( 'standard' == $fi_base || 'standard-uncrop' == $fi_base ) {
					$t_loc = get_post_meta( $pid, 'cb_featured_image_st_title_style', true ) == 'cb-fis-tl-st-above' ? 1 : 2;
				} else {
					$t_loc = get_post_meta( $pid, 'cb_featured_image_title_style', true ) == 'cb-fis-tl-overlay' ? 1 : 2;
				}
				if ( '15zine' == $type ) {
					$m_loc = get_post_meta( $pid, 'cb_featured_image_med_title_style', true ) == '' ? 'cb-fis-tl-me-overlay' : get_post_meta( $pid, 'cb_featured_image_med_title_style', true );

					if ( 'cb-fis-tl-me-overlay' == $m_loc ) {
						$m_loc = 1;
					} elseif ( 'cb-fis-tl-me-above' == $m_loc ) {
						$m_loc = 3;
					} elseif ( 'cb-fis-tl-me-below' == $m_loc ) {
						$m_loc = 2;
					}
				}
				if ( 'standard' == $fi_base || 'standard-uncrop' == $fi_base ) {
					$fi = 1;
					if ( 1 == $t_loc ) {
						$fi = 2;
					}
				} elseif ( 'full-width' == $fi_base || 'site-width' == $fi_base ) {
					$fi = 14;
					if ( ! empty( $m_loc ) ) {
						$fi = 16;
						if ( 3 == $m_loc ) {
							$fi = 12;
						} elseif ( 2 == $m_loc ) {
							$fi = 11;
						}
					}
				} elseif ( 'full-background' == $fi_base || 'screen-width' == $fi_base ) {
					$fi = '15zine' == $type ? 24 : 22;
					if ( 1 == $t_loc ) {
						$fi = 21;
					}
					if ( 'screen-width' == $fi_base ) {
						$cover = 3;
						if ( 3 == $m_loc ) {
							$fi = 26;
						} elseif ( 2 == $m_loc ) {
							$fi = 24;
						} else {
							$fi = 21;
						}
					}
				} elseif ( 'off' == $fi_base ) {
					$fi = 10;
				} elseif ( 'parallax' == $fi_base ) {
					$fi = 21;
					$parallax = true;
				}
				$s_header = get_post_meta( $pid, 'cb_post_fis_header', true ) == 'off' ? 51 : '';
				$layout = get_post_meta( $pid, 'cb_full_width_post', true );
				if ( 'sidebar_left' == $layout ) {
					$p_layout = 11;
				}
				if ( '15zine' == $type ) {
					if ( 'nosidebar-fw' == $layout ) {
						$p_layout = 51;
						if ( get_post_meta( $pid, '_cb_embed_out', true ) == 'on' || get_post_meta( $pid, '_cb_embed_fs', true ) == 'on' ) {
							$p_layout = 55;
						}
					} elseif ( 'nosidebar' == $layout ) {
						$p_layout = 31;
						if ( get_post_meta( $pid, '_cb_embed_out', true ) == 'on' || get_post_meta( $pid, '_cb_embed_fs', true ) == 'on' ) {
							$p_layout = 36;
						}
					}
					$gallery = get_post_meta( $pid, 'cb_gallery_post_images', true );
					if ( ! empty( $gallery ) ) {
						$gallery = explode( ',', $gallery );
					}
				} else {
					if ( 'nosidebar' == $layout ) {
						$p_layout = 51;
					} elseif ( 'nosidebar-narrow' == $layout ) {
						$p_layout = 31;
					}
					$gallery = get_post_meta( $pid, 'cb_gallery_content' );
				}
			}

			$url_v_o = get_post_meta( $pid, 'zeen_video_code', true );
			if ( ! empty( $url_v ) && empty( $url_v_o ) ) {
				update_post_meta( $pid, 'zeen_video_code', $url_v );
			}
			$gallery_do = get_post_meta( $pid, 'zeen_gallery_do', true );
			if ( ! empty( $gallery ) && empty( $gallery_do ) ) {
				update_post_meta( $pid, 'zeen_gallery', $gallery );
				update_post_meta( $pid, 'zeen_gallery_do', true );
			}
			$cover_o = get_post_meta( $pid, 'codetipi_15zine_cover_height', true );
			if ( ! empty( $cover ) && empty( $cover_o ) ) {
				update_post_meta( $pid, 'codetipi_15zine_cover_height', $cover );
			}
			$p_layout_o = get_post_meta( $pid, 'zeen_article_layout', true );
			if ( ! empty( $p_layout ) && empty( $p_layout_o ) ) {
				update_post_meta( $pid, 'zeen_article_layout', $p_layout );
			}
			$fi_o = get_post_meta( $pid, 'zeen_hero_design', true );
			if ( ! empty( $fi ) && empty( $fi_o ) ) {
				update_post_meta( $pid, 'zeen_hero_design', $fi );
			}
			$fi_p = get_post_meta( $pid, 'zeen_parallax', true );
			if ( ! empty( $parallax ) && empty( $fi_p ) ) {
				update_post_meta( $pid, 'zeen_parallax', 1 );
			}
			$url_a_o = get_post_meta( $pid, 'zeen_audio_code', true );
			if ( ! empty( $url_a ) && empty( $url_a_o ) ) {
				update_post_meta( $pid, 'zeen_audio_code', $url_a );
			}
			$s_header_o = get_post_meta( $pid, 'zeen_singular_header', true );
			if ( ! empty( $s_header ) && empty( $s_header_o ) ) {
				update_post_meta( $pid, 'zeen_singular_header', $s_header );
			}
		}
	}
	if ( 'valenti' == $type || '15zine' == $type ) {
		$options = get_option( 'option_tree' );
		if ( ! empty( $options ) ) {
			$logo = $options['cb_logo_url'];
			$logo = attachment_url_to_postid( $logo );
			$logo_r = $options['cb_logo_retina_url'];
			$logo_r = attachment_url_to_postid( $logo_r );
			$logo_m = $options['cb_logo_nav_m_url'];
			$logo_m = attachment_url_to_postid( $logo_m );
			$logo_m_r = $options['cb_logo_nav_m_retina_url'];
			$logo_m_r = attachment_url_to_postid( $logo_m_r );
			$logo_menu = $options['cb_logo_nav_url'];
			$logo_menu = attachment_url_to_postid( $logo_menu );
			$logo_menu_r = $options['cb_logo_nav_retina_url'];
			$logo_menu_r = attachment_url_to_postid( $logo_menu_r );
			$copyright = $options['cb_footer_copyright'];
		}
	}
	$logo_o = get_theme_mod( 'logo_main' );
	if ( ! empty( $logo ) && empty( $logo_o ) ) {
		set_theme_mod( 'logo_main', $logo );
	}
	$logo_r_o = get_theme_mod( 'logo_main_retina' );
	if ( ! empty( $logo_r ) && empty( $logo_r_o ) ) {
		set_theme_mod( 'logo_main_retina', $logo_r );
	}
	$logo_m_o = get_theme_mod( 'logo_mobile' );
	if ( ! empty( $logo_m ) && empty( $logo_m_o ) ) {
		set_theme_mod( 'logo_mobile', $logo_m );
	}
	$logo_m_r_o = get_theme_mod( 'logo_mobile_retina' );
	if ( ! empty( $logo_m_r ) && empty( $logo_m_r_o ) ) {
		set_theme_mod( 'logo_mobile_retina', $logo_m_r );
	}
	$logo_menu_o = get_theme_mod( 'logo_main_menu' );
	if ( ! empty( $logo_menu ) && empty( $logo_menu_o ) ) {
		set_theme_mod( 'logo_main_menu', $logo_menu );
	}
	$logo_menu_r_o = get_theme_mod( 'logo_main_menu_retina' );
	if ( ! empty( $logo_menu_r ) && empty( $logo_menu_r_o ) ) {
		set_theme_mod( 'logo_main_menu_retina', $logo_menu_r );
	}
	$copyright_o = get_theme_mod( 'copyright' );
	if ( ! empty( $copyright ) && empty( $copyright_o ) ) {
		set_theme_mod( 'copyright', $copyright );
	}
	return true;
}
