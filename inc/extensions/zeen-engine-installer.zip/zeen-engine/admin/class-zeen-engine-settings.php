<?php
/**
 * Zeen Engine settings
 *
 * @package     Zeen_Engine
 * @copyright   Copyright Codetipi
 * @since       1.0.0
 */
class Zeen_Engine_Settings {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	*/
	public function __construct() {
		$this->url      = plugin_dir_url( dirname( __FILE__ ) );
		$this->dir_path = plugin_dir_path( dirname( __FILE__ ) );
		$this->name = 'Zeen';
		if ( get_theme_mod( 'white_label_onoff' ) == 1 ) {
			$this->name = get_theme_mod( 'white_label_name', 'Zeen' );
		}
		$this->slug = 'zeen';
		$this->version = '2.8.2';
		add_action( 'admin_menu', array( $this, 'zeen_engine_menu_page' ) );
	}

	/**
	 * Admin Menu Page
	 *
	 * @since 1.0.0
	 */
	public function zeen_engine_menu_page() {
		$mark_url = plugin_dir_url( __FILE__ ) . 'img/mark.svg';
		if ( get_theme_mod( 'white_label_onoff' ) == 1 ) {
			$mark = get_theme_mod( 'white_label_mark' );
			$mark_url = '';
			if ( ! empty( $mark ) ) {
				$mark_url = wp_get_attachment_image_src( $mark, 'full' );
				$mark_url = $src[0];
			}
		}
		add_menu_page( $this->name,  $this->name, 'manage_options', $this->slug, array( $this, 'zeen_engine_page_loader' ),  esc_url( $mark_url ), 2 );
		add_submenu_page( $this->slug, esc_html__( 'Welcome', 'zeen-engine' ), esc_html__( 'Welcome', 'zeen-engine' ), 'manage_options', $this->slug, array( $this, 'zeen_engine_page_loader' ) );
		add_submenu_page( $this->slug, esc_html__( 'Theme Options', 'zeen-engine' ), esc_html__( 'Theme Options', 'zeen-engine' ), 'manage_options', 'customize.php?return=admin.php?page=' . $this->slug );
		if ( get_theme_mod( 'white_label_onoff' ) != 1 ) {
			add_submenu_page( $this->slug, esc_html__( 'Community', 'zeen-engine' ), esc_html__( 'Community', 'zeen-engine' ), 'manage_options', $this->slug . '-community', array( $this, 'zeen_engine_page_loader' ) );
			add_submenu_page( $this->slug, esc_html__( 'Migration', 'zeen-engine' ), esc_html__( 'Migration', 'zeen-engine' ), 'manage_options', $this->slug . '-migration', array( $this, 'zeen_engine_page_loader' ) );
			add_submenu_page( $this->slug, esc_html__( 'Help', 'zeen-engine' ), esc_html__( 'Help', 'zeen-engine' ), 'manage_options', $this->slug . '-help', array( $this, 'zeen_engine_page_loader' ) );
		}
		add_submenu_page( $this->slug, esc_html__( 'Sidebar Management', 'zeen-engine' ), esc_html__( 'Custom Sidebars', 'zeen-engine' ), 'manage_options', $this->slug . '-sidebar', array( $this, 'zeen_engine_page_loader' ) );

	}

	/**
	 * Page Loader
	 *
	 * @version 2.0.0
	 * @since 1.0.0
	 */
	public function zeen_engine_page_loader() {

		global $plugin_page;
		$this->zeen_engine_admin_head();
		switch ( $plugin_page ) {
			case $this->slug . '-help':
				require $this->dir_path . 'admin/pages/help.php';
				break;
			case $this->slug . '-community':
				require $this->dir_path . 'admin/pages/community.php';
				break;
			case $this->slug . '-migration':
				require $this->dir_path . 'admin/pages/migration.php';
				break;
			case $this->slug . '-sidebar':
				require $this->dir_path . 'admin/pages/sidebar.php';
				break;
			default:
				require $this->dir_path . 'admin/pages/welcome.php';
				break;
		}

	}
	/**
	 * Admin Page Head
	 *
	 * @since    1.0.0
	 */
	public function zeen_engine_admin_head() {
	?>
		<div class="wrap about-wrap tipi-wrap">
		<h1><?php echo esc_html( $this->name ); ?>
		<?php if ( get_theme_mod( 'white_label_onoff' ) != 1 ) {
			echo ' ' . esc_html( apply_filters( 'zeen_version', '' ) );
		} ?>

		</h1>
		<?php if ( get_theme_mod( 'white_label_onoff' ) != 1 ) { ?>
		<div class="about-text"><?php esc_html_e( 'Thank you for choosing Zeen and for joining the Codetipi community. We hope you enjoy it here :)' ,'zeen-engine' ); ?></div>
		<div class="zeen-engine-badge">
			<img src="<?php echo esc_url( get_parent_theme_file_uri( 'assets/admin/img/badge.jpg' ) ); ?>" srcset="	<?php echo esc_url( get_parent_theme_file_uri( 'assets/admin/img/badge@2x.jpg' ) ); ?> 2x" alt="">
				<span class="version"><?php echo esc_html( apply_filters( 'zeen_version', '' ) ); ?></span>
			</div>
			<?php } ?>
		<h2 class="nav-tab-wrapper">
		<?php
		$tabs = array( $this->slug => esc_html__( 'Welcome', 'zeen-engine' ), $this->slug . '-theme-options' => esc_html__( 'Theme Options', 'zeen-engine' ) );
		if ( get_theme_mod( 'white_label_onoff' ) != 1 ) {
			$tabs[ $this->slug . '-community' ] = esc_html__( 'Community', 'zeen-engine' );
			$tabs[ $this->slug . '-migration' ] = esc_html__( 'Migration', 'zeen-engine' );
			$tabs[ $this->slug . '-help' ] = esc_html__( 'Help', 'zeen-engine' );
		}
		?>
		<?php foreach( $tabs as $tab => $name ) { ?>
			<?php  $class = $tab == $_GET[ 'page' ] ? 'nav-tab-active': ''; ?>
			<?php if ( $tab == $this->slug . '-theme-options' ) { ?>
				<a class="nav-tab <?php echo esc_attr( $class ); ?>" href="customize.php?return=admin.php?page=<?php echo esc_attr( $this->slug ); ?>"><?php echo esc_html( $name ); ?></a>
			<?php } else { ?>
				<a class="nav-tab <?php echo esc_attr( $class ); ?>" href="?page=<?php echo esc_attr( $tab ); ?>"><?php echo esc_html( $name ); ?></a>
			<?php } ?>


		<?php } ?>
		</h2>

	<?php
	}

	/**
	 * Admin Page Footer
	 *
	 * @since    1.0.0
	 */
	public function zeen_engine_admin_footer() {
		if ( get_theme_mod( 'white_label_onoff' ) == 1 ) {
			return;
		}
	?>

	<div class="tipi-box tipi-xs-12 tipi-m-6 tipi-col">
		<a href="http://facebook.com/codetipi" target="_blank"><img src="<?php echo esc_url( get_parent_theme_file_uri( 'assets/admin/img/tipi-fb.png' ) ); ?>" alt=""></a>
	</div>
	<div class="tipi-box tipi-xs-12 tipi-m-6 tipi-col">
		<a href="http://twitter.com/codetipi" target="_blank"><img src="<?php echo esc_url( get_parent_theme_file_uri( 'assets/admin/img/tipi-tw.png' ) ); ?>" alt=""></a>
	</div>

	</div>
	<?php
	}


}

