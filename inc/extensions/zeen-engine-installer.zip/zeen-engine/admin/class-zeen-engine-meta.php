<?php
/**
 * Zeen Engine meta box Class
 *
 * @package 	Zeen_Engine
 * @copyright   Copyright Codetipi
 * @since 		1.0.0
 */
class Zeen_Engine_Metabox {

	/**
	 * Var for setup.
	 *
	 * @since    1.0.0
	 */
	private $zeen_engine_setup;

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	*/
	public function __construct( $zeen_engine_setup ) {
		$this->src_uri = $zeen_engine_setup['src_uri'];
		$this->zeen_engine_post_type = isset( $zeen_engine_setup['post_type'] ) ? $zeen_engine_setup['post_type'] : array( 'post' );
		$this->zeen_engine_title = $zeen_engine_setup['title'];
		$this->zeen_engine_id = $zeen_engine_setup['id'];
		$this->context = empty( $zeen_engine_setup['context'] ) ? 'advanced' : $zeen_engine_setup['context'];
		$this->zeen_engine_prefix = $zeen_engine_setup['prefix'];
		$this->zeen_engine_args = isset( $zeen_engine_setup['args'] ) ? $zeen_engine_setup['args'] : array();
		$this->zeen_engine_sections = isset( $zeen_engine_setup['sections'] ) ? $zeen_engine_setup['sections'] : '';

		add_action( 'add_meta_boxes', array( $this, 'zeen_engine_metabox_add' ) );
		add_action( 'save_post', array( $this, 'zeen_engine_save' ) );
	}

	/**
	 * Meta Box Constructor
	 *
	 * @since 1.0.0
	 * @param WP_Post $post The post object.
	 */
	public function zeen_engine_metabox_add( $post ) {
		$current_screen = get_current_screen();
		if ( ( function_exists( 'is_gutenberg_page' ) && is_gutenberg_page() ) || ( method_exists( $current_screen, 'is_block_editor' ) && $current_screen->is_block_editor() ) ) {
			$gutenberg = true;
		}

		if ( empty( $gutenberg ) && 'zeen-subtitle' == $this->zeen_engine_id ) {
			return;
		}

		add_meta_box(
			$this->zeen_engine_id,
			$this->zeen_engine_title,
			array( $this, 'zeen_engine_metabox_callback' ),
			$this->zeen_engine_post_type,
			$this->context,
			'high'
		);

	}

	/**
	 * Meta Box Save
	 *
	 * @since 1.0.0
	 * @param int $post_id The ID of the post being saved.
	 */
	public function zeen_engine_save( $post_id ) {

		// Important checks before saving
		// 1. Check if nonce exists 2. Verify nonce 3. Check if post is autosaving 4. Check quick edit doesn't affect custom fields 5. Check user has right permissions
		if (
			( ! isset( $_POST['zeen_engine_metabox_nonce'] ) )
			|| ( ! wp_verify_nonce( $_POST['zeen_engine_metabox_nonce'], 'zeen_engine_metabox' ) )
			|| ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE )
			|| ( defined( 'DOING_AJAX' ) && DOING_AJAX )
			|| ( ! current_user_can( 'edit_posts' ) )
			) {
			return;
		}

		foreach ( $this->zeen_engine_metabox_callback( $post_id, false ) as $option ) {
			$control        = $option['control'];
			$id             = $option['id'];
			$class          = isset( $option['class'] ) ? $option['class'] : '';
			$title          = isset( $option['title'] ) ? $option['title'] : '';
			$description    = isset( $option['description'] ) ? $option['description'] : '';
			$default        = isset( $option['default'] ) ? $option['default'] : '';
			$required       = isset( $option['required'] ) ? $option['required'] : '';
			$choices        = isset( $option['choices'] ) ? $option['choices'] : array();
			$global         = isset( $option['global'] ) ? $option['global'] : '';
			$global_removal = isset( $option['global_removal'] ) ? $option['global_removal'] : '';
			$name           = str_replace( '-', '_', $this->zeen_engine_prefix . '_' . $id );
			$sanitized_value = '';

			switch ( $control ) {
				case 'on-off':
					$sanitized_value = isset( $_POST[ $name ] ) ? 'on' : 'off';
				break;
				case 'text':
					$sanitized_value = isset( $_POST[ $name ] ) ? zeen_engine_sanitize_wp_kses( $_POST[ $name ] ) : '';
				break;
				case 'textarea':
					$sanitized_value = isset( $_POST[ $name ] ) ? zeen_engine_sanitize_wp_kses( $_POST[ $name ] ) : '';
				break;
				case 'radio-images':
					$sanitized_value = isset( $_POST[ $name ] ) ? esc_attr( $_POST[ $name ] ) : '';
				break;
				case 'select':
					$sanitized_value = isset( $_POST[ $name ] ) ? esc_attr( $_POST[ $name ] ) : '';
				break;
				case 'color':
					$sanitized_value = isset( $_POST[ $name ] ) ? esc_attr( $_POST[ $name ] ) : '';
				break;
				case 'color-a':
					$rgba = isset( $_POST[ $name ] ) ? str_replace( ' ', '', $_POST[ $name ] )  : '';
					if ( ! empty( $rgba ) && strtolower( mb_substr( $rgba, 0, 4 ) ) == 'rgba' ) {
						preg_match( '#\((.*?)\)#', $rgba, $matches );
						$rgba = explode( ',', $matches[1] );
						$sanitized_value = 'rgba(' . (int) ( $rgba[0] ) . ',' . (int) ( $rgba[1] ) . ',' . (int) ( $rgba[2] ) . ',' . floatval( $rgba[3] ) . ')';
					} else {
						$sanitized_value = esc_attr( $rgba );
					}
				break;
				case 'slider':
					$sanitized_value = isset( $_POST[ $name ] ) ? (int) ( $_POST[ $name ] ) : '';
				break;
				case 'image':
					$id_or_src = isset( $choices['type'] ) && $choices['type'] == 'id' ? 'id' : 'src';
					if ( $id_or_src == 'id' ) {
						$sanitized_value = isset( $_POST[ $name ] ) ? (int) ( $_POST[ $name ] ) : '';
					} else {
						$sanitized_value = isset( $_POST[ $name ] ) ? esc_url( $_POST[ $name ] ) : '';
					}
				break;
				case 'gallery':
					$sanitized_value = isset( $_POST[ $name ] ) ? zeen_engine_sanitize_array( $_POST[ $name ] ) : '';
				break;
				case 'background':
					$sanitized_value = isset( $_POST[ $name ] ) ? zeen_engine_sanitize_array( $_POST[ $name ] ) : '';
				break;
				case 'drag':
					$sanitized_value = isset( $_POST[ $name ] ) ? $_POST[ $name ] : '';
				break;
				case 'date':
					$sanitized_value = isset( $_POST[ $name ] ) ? esc_attr( $_POST[ $name ] ) : '';
				break;
			}
			$current_value = get_post_meta( $post_id, $name, true );
			if ( '' !== $sanitized_value && ! ( $default == $sanitized_value && empty( $current_value ) ) ) {
				update_post_meta( $post_id, $name, $sanitized_value );
			} elseif ( '' === $sanitized_value) {
				delete_post_meta( $post_id, $name );
			}
			if ( ! empty( $global ) ) {
				if ( ( 'empty' != $global && $current_value != $global ) || ( 'empty' == $global && empty( $current_value ) ) ) {
					if ( ! empty( $global_removal ) ) {
						if ( isset( Zeen_Engine_Options::$zeen_engine_options[ $name ] ) ) {
							$key = array_search( $post_id, Zeen_Engine_Options::$zeen_engine_options[ $name ] );
							if ( false !== $key ) {
								unset( Zeen_Engine_Options::$zeen_engine_options[ $name ][ $key ] );
								Zeen_Engine_Options::zeen_engine_update_option();
							}
						}
					}
					continue;
				}

				if ( isset( Zeen_Engine_Options::$zeen_engine_options[ $name ] ) ) {
					if ( ! in_array( $post_id, Zeen_Engine_Options::$zeen_engine_options[ $name ] ) ) {
						Zeen_Engine_Options::$zeen_engine_options[ $name ][] = $post_id;
					}
				} else {
					Zeen_Engine_Options::$zeen_engine_options[ $name ] = array( $post_id );
				}

				Zeen_Engine_Options::zeen_engine_update_option();
			}
		}
		$sanitized_subtitle = isset( $_POST['zeen_subtitle'] ) ? zeen_engine_sanitize_wp_kses( $_POST['zeen_subtitle'] ) : '';
		if ( '' !== $sanitized_subtitle ) {
			update_post_meta( $post_id, 'zeen_subtitle', $sanitized_subtitle );
		}

	}

	 /**
	 * Page Meta Box Callback
	 *
	 * @since 1.0.0
	 *
	 * @param WP_Post $post The post object.
	 *
	 */
	public function zeen_engine_metabox_callback( $post, $echo = true ) {

		if ( $echo == true ) {
			$this->zeen_engine_metabox_options( $post, $this->zeen_engine_args, $this->zeen_engine_sections );
		} else {
			return $this->zeen_engine_args;
		}

	}

	public function zeen_engine_metabox_options( $post, $zeen_engine_options ) {
		$j = 1;
		$closer = false;

		?>
		<div id="<?php echo esc_attr( $this->zeen_engine_id ); ?>" class="<?php echo esc_attr( $this->zeen_engine_id ); ?> zeen-engine-metabox-wrap tipi-metabox-wrap zeen-engine-cf">

			<?php if ( ! empty( $this->zeen_engine_sections ) ) { ?>
			<div class="zeen-engine-metabox-sections zeen-engine-cf">

			<?php foreach ( $this->zeen_engine_sections as $section ) { ?>
				<a href="#" class="zeen-engine-trig<?php if ( $j == 1 ) { echo ' zeen-engine-active'; } ?> zeen-engine-trig-<?php echo esc_attr( $section['id'] ); ?>" data-section="zeen-engine-trig-<?php echo esc_attr( $section['id'] ); ?>"><?php echo ( $section['title'] ) ? $section['title'] : ''; ?></a>
			<?php $j++; } ?>

			</div>

			<?php } ?>

			<div class="zeen-engine-metabox-controls">

			<?php
			wp_nonce_field( 'zeen_engine_metabox', 'zeen_engine_metabox_nonce' );

			foreach ( $zeen_engine_options as $option ) {

				$control        = $option['control'];
				$id             = $option['id'];
				$class          = isset( $option['class'] ) ? $option['class'] : '';
				$title          = isset( $option['title'] ) ? $option['title'] : '';
				$description    = isset( $option['description'] ) ? $option['description'] : '';
				$default        = isset( $option['default'] ) ? $option['default'] : '';
				$required       = isset( $option['required'] ) ? $option['required'] : '';
				$choices        = isset( $option['choices'] ) ? $option['choices'] : array();
				$zero_allowed   = isset( $option['zero_allowed'] ) ? $option['zero_allowed'] : '';
				$name           = str_replace( '-', '_', $this->zeen_engine_prefix . '_' . $id );

				if ( $control == 'section' ) {
					$closer = true;
					if ( $choices['count'] > 1 ) {
						echo '</div><div id="zeen-engine-trig-' . $id . '" class="zeen-engine-hide">';
					} else {
						echo '<div id="zeen-engine-trig-' . $id . '">';
					}

					continue;
				}

				if ( $control == 'slider' ) {
					$meta = get_post_meta( $post->ID, $name, true );
					$current_value = isset( $meta ) && $meta != '' ? $meta : $default;
				} else {
					if ( empty( $zero_allowed ) ) {
						$current_value = get_post_meta( $post->ID, $name, true ) ? get_post_meta( $post->ID, $name, true ) : $default;
					} else {
						$current_value = get_post_meta( $post->ID, $name, true );
						if ( $current_value === '' ) {
							$current_value = $default;
						}
					}
				}

				$bg_repeat_args = array(
					1 => esc_html__( 'Stretch', 'zeen-engine' ),
					2 => esc_html__( 'Repeat', 'zeen-engine' ),
					3 => esc_html__( 'Repeat Horizontal', 'zeen-engine' ),
					4 => esc_html__( 'Repeat Vertical', 'zeen-engine' ),
					5 => esc_html__( 'No Repeat', 'zeen-engine' ),
				);

				$zeen_engine_vis = empty( $required ) ? '' : 'display: none;';
				$zeen_engine_req_class = empty( $required ) ? '' : 'zeen-engine-req';
				$req_id = empty( $required ) ? '' : $required['id'];
				$req_value = empty( $required ) ? '' : $required['value'];
				$req_value = is_array( $req_value ) ? wp_json_encode( $req_value ) : $req_value;
				$req_id_2 = empty( $required['id_2'] ) ? '' : $required['id_2'];
				$req_value_2 = empty( $required['value_2'] ) ? '' : $required['value_2'];
				$req_value_2 = is_array( $req_value_2 ) ? wp_json_encode( $req_value_2 ) : $req_value_2;
				$suboption = function_exists( 'zeen_customizer_suboption' ) ? zeen_customizer_suboption( true ) : '';
				if ( $req_value == $current_value ) {
					$zeen_engine_vis = '';
				}
				if ( ! empty( $req_value_2 ) ) {
					$zeen_engine_req_class .= ' zeen-engine-req-level-2';
				}
				?>
				<div id="zeen-engine-meta-control-<?php echo esc_attr( $this->zeen_engine_prefix . '-' . $id ); ?>" class="zeen-engine-control zeen-engine-meta-control zeen-engine-<?php echo esc_attr( $control ); echo '-wrap ' . esc_attr( $class ) . ' ' . esc_attr( $zeen_engine_req_class ); ?> zeen-engine-cf"<?php echo 'style="' . esc_attr( $zeen_engine_vis ) . '"'; ?> data-req="<?php echo esc_attr( 'zeen-engine-meta-control-' . $this->zeen_engine_prefix . '-' . $req_id ); ?>" data-req-val="<?php echo esc_attr( $req_value ); ?>" data-req-2="<?php echo esc_attr( 'zeen-engine-meta-control-' . $this->zeen_engine_prefix . '-' . $req_id_2 ); ?>" data-req-val-2="<?php echo esc_attr( $req_value_2 ); ?>" data-control="<?php echo esc_attr( $control ); ?>">
					<div class="<?php if ( count( $choices ) > 6 && 'radio-images' == $control ) { echo 'radio-images-big'; } else { echo 'zeen-engine-control-inner'; } ?>">
						<?php if ( ! empty( $description ) || ! empty( $title ) ) { ?>
						<div class="zeen-engine-meta">
							<?php echo empty( $required ) ? '' : $suboption; ?>
							<div class="zeen-engine-title"><?php echo zeen_engine_sanitize_wp_kses( $title ); ?></div>
							<?php if ( ! empty( $description ) ) { ?>
								<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
							<?php } ?>
						</div>
						<?php } ?>
					<?php
						switch ( $control ) {
							case 'title':
							?>
								<div class="zeen-engine-control-only">
								<?php echo zeen_engine_sanitize_wp_kses( $title ); ?>
								</div>
							<?php
							break;
							case 'text':
							?>
							<div class="zeen-engine-control-only">
								<input name="<?php echo esc_attr( $name ); ?>" type="text" value="<?php echo esc_attr( $current_value ); ?>" class="zeen-engine-input-val" id="zeen-engine-<?php echo esc_attr( $id ); ?>">
							</div>
							<?php
								break;
							case 'textarea':
							?>
								<div class="zeen-engine-control-only">
								<textarea class="zeen-engine-input-val" rows="4" cols="40" name="<?php echo esc_attr( $name ); ?>" id="zeen-engine-<?php echo esc_attr( $id ); ?>"><?php echo esc_attr( $current_value ); ?></textarea>

								</div>
							<?php
								break;
							case 'on-off':
							?>
								<div class="zeen-engine-control-only">
									<span class="zeen-engine-on-off">
										<input id="zeen-engine-<?php echo esc_attr( $id ); ?>" type="checkbox" value="<?php echo esc_attr( $current_value ); ?>" <?php checked( $current_value, 'on' ); ?> name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-input-val">
										<label for="zeen-engine-<?php echo esc_attr( $id ); ?>">
											<span class="zeen-engine-on-off-ux"></span>
										</label>
									</span>
								</div>
							<?php
								break;
							case 'date':
							?>
								<div class="zeen-engine-control-only">
									<span class="zeen-engine-date-field">
										<input id="zeen-engine-<?php echo esc_attr( $id ); ?>" value="<?php echo esc_attr( $current_value ); ?>" name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-input-val">

									</span>
								</div>
							<?php
								break;
							case 'drag':
							$count = 1;
							if ( ! empty( $current_value ) ) {
								$count = count( $current_value );
							}
							?>
								<div class="zeen-engine-control-only">
									<div class="zeen-engine-drag-wrap zeen-engine-drag-drop" data-count="<?php echo (int) ( $count ); ?>">
										<?php $this->drag_field( array( 'choices' => $choices, 'current_value' => $current_value, 'name' => $name ) ); ?>
									</div>
									<div class="zeen-engine-drag-el-dummy">
										 <?php $this->drag_field( array( 'choices' => $choices, 'name' => $name, 'dummy' => true ) ); ?>
									</div>
									<a href="#" class="zeen-engine-drag-add"><span class="zeen-engine-drag-plus"></span> <?php esc_attr_e( 'Add', 'zeen-engine' ); ?></a>
								</div>
							<?php
								break;
							case 'radio-images':

							?>	<div class="zeen-engine-control-only">
									<span class="zeen-engine-radio-images zeen-engine-cf">
										<?php foreach ( $choices as $key => $value ) {

										$value['url']  = rtrim( $value['url'] , '/' );
										$ext = substr( $value['url'] , -3 );
										$retina = $ext == 'png'  ? substr_replace( $value[ 'url' ], '@2x', -4, 0) : '';
										$radio_id = $name . '-' . $id . '-' . $key ;
										?>

											<span class="zeen-engine-radio-image">
												<input type="radio" id="<?php echo esc_attr( $radio_id ); ?>" value="<?php echo esc_attr( $key );?>" <?php checked( $current_value, $key ); ?> name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-input-val">
												<label for="<?php echo esc_attr( $radio_id ); ?>">
													<?php if ( isset( $value['title'] ) ) { ?>
													<div class="zeen-engine-label"><?php echo zeen_engine_sanitize_wp_kses( $value['title'] ); ?></div>
													<?php } ?>
													<img class="<?php if ( ! empty( $value['alt'] ) ) { ?>radio-image-alt radio-image-alt-1 <?php } ?>" src="<?php echo esc_url( $this->src_uri . $value['url'] ); ?>" <?php if ( ! empty ( $retina ) ) { ?>srcset="<?php echo esc_url( $this->src_uri . $retina ); ?> 2x" <?php } ?> alt="">
													<?php if ( ! empty( $value['alt'] ) ) {

														$value['alt']  = rtrim( $value['alt'] , '/' );
														$ext = substr( $value['alt'] , -3 );
														$retina_alt =  $ext == 'png'  ? substr_replace( $value[ 'alt' ], '@2x', -4, 0) : '';
													?>
													<img class="radio-image-alt radio-image-alt-2" src="<?php echo esc_url( $this->src_uri . $value['alt'] ); ?>" <?php if ( ! empty ( $retina_alt ) ) { ?>srcset="<?php echo esc_url( $this->src_uri . $retina_alt ); ?> 2x" <?php } ?> alt="">
													<?php } ?>
												</label>
											</span>

										<?php } ?>
									</span>
								</div>
							<?php
							break;
							case 'select':
							?>
								<div class="zeen-engine-control-only">
									<select name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-input-val"  id="zeen-engine-<?php echo esc_attr( $id ); ?>">
										<?php foreach ( $choices as $key => $value ) { ?>
											<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $current_value, $key ); ?>><?php echo zeen_engine_sanitize_wp_kses( $value ); ?></option>
										<?php } ?>
									 </select>
								</div>
							<?php
							break;
							case 'color':
							?>
								<div class="zeen-engine-control-only">
									<input type="text" class="zeen-engine-color-pick zeen-engine-input-val" value="<?php echo esc_attr( $current_value ); ?>" name="<?php echo esc_attr( $name ); ?>">
								</div>
							<?php
							break;
							case 'color-a':
							?>
								<div class="zeen-engine-control-only">
									<input type="text" class="zeen-engine-color-pick-a zeen-engine-input-val" value="<?php echo esc_attr( $current_value ); ?>" name="<?php echo esc_attr( $name ); ?>">
								</div>
							<?php
							break;
							case 'slider':
							?>
								<div class="zeen-engine-control-only">
									<div class="zeen-engine-slider" data-value="<?php echo esc_attr( $current_value ); ?>" data-min="<?php echo esc_attr( $choices['min'] ); ?>" data-max="<?php echo esc_attr( $choices['max'] ); ?>" data-step="<?php echo esc_attr( $choices['step'] ); ?>" data-default="<?php echo esc_attr( $default ); ?>"></div>
									<input name="<?php echo esc_attr( $name ); ?>" type="text" value="<?php echo esc_attr( $current_value ); ?>" class="zeen-engine-input-val">
									<span class="zeen-engine-data"><span class="zeen-engine-val"><?php echo esc_attr( $current_value ); ?></span><span class="dashicons dashicons-backup zeen-engine-reset" title="<?php esc_html_e( 'Reset to default', 'zeen-engine' ); ?>"></span></span>
								</div>
							<?php
							break;
							case 'image':
								$id_or_src = isset( $choices['type'] ) && $choices['type'] == 'id' ? 'id' : 'src';
								$file_type = isset( $choices['file_type'] ) ? $choices['file_type'] : 'img';
							?>
								<div class="zeen-engine-control-only<?php if ( $id_or_src == 'id' ) { ?> zeen-engine-single-img-id<?php } ?>">
									<input <?php if ( $id_or_src == 'id' ) { ?>type="hidden"<?php } else { ?>type="hidden"<?php } ?> value="<?php if ( ! empty( $current_value ) ) { if ( $id_or_src == 'id' ) { echo (int) ( $current_value ); } else { echo esc_url( $current_value); } } ?>" name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-img-input zeen-engine-input-val">
									<a href="#" class="zeen-engine-upload" data-dest="zeen-engine-meta-control-<?php echo esc_attr( $this->zeen_engine_prefix . '-' . $id ); ?>" data-output="<?php echo esc_attr( $id_or_src ); ?>" data-file-type="<?php echo esc_attr( $file_type ); ?>" data-name="<?php echo esc_attr( $name ); ?>"><?php esc_html_e( 'Upload', 'zeen-engine' ); ?></a>
									<?php if ( ! empty( $current_value ) ) { ?>
										<span class="zeen-engine-img">
											<a href="#" class="zeen-engine-remove zeen-engine--x"></a>
											<?php
											if ( 'img' == $file_type ) {
												if ( $id_or_src == 'id' ) {
													$current_value_img = wp_get_attachment_image_src ( $current_value, 'zeen-engine-293-293' );
													$current_value_img = $current_value_img[0];
												} else {
													$current_value_img = $current_value;
												}
											} else {
												$current_value_img = get_parent_theme_file_uri( 'assets/admin/img/md-icon-1.png' );
												$current_value_img_2x = get_parent_theme_file_uri( 'assets/admin/img/md-icon-1@2x.png' );
											}
											echo '<img src="' . esc_url( $current_value_img ) . '" alt=""';
											if ( ! empty( $current_value_img_2x ) ) {
												echo ' srcset="' . esc_url( $current_value_img_2x ) . ' 2x" class="media--not-img"';
											}
											echo '>';
											?>
										</span>
									<?php } ?>
								</div>

							<?php
							break;
							case 'gallery':
							$i = 1;
							?>
								<div class="zeen-engine-control-only">
									<a href="#" class="zeen-engine-gallery" data-dest="zeen-engine-meta-control-<?php echo esc_attr( $this->zeen_engine_prefix . '-' . $id ); ?>" data-counter="<?php if ( ! empty ( $current_value ) ) { echo (int) ( count( $current_value ) ); } else { echo (int) ( $i ); } ?>" data-name="<?php echo esc_attr( $name ); ?>"><?php esc_html_e( 'Edit Gallery', 'zeen-engine' ); ?></a>
									<span class="zeen-engine-gallery-images-wrap zeen-engine-drag-drop">
										<?php if ( ! empty( $current_value ) ) { ?>

											<?php foreach ( $current_value as $key => $value) { ?>
												<span class="zeen-engine-img">
													<?php $current_value_img = wp_get_attachment_image_src ( $value, 'zeen-engine-293-293' ); ?>
													<a href="#" class="zeen-engine-remove-gallery zeen-engine--x"></a>
													<img src="<?php echo esc_url( $current_value_img[0] ); ?>" alt="">
													<input type="hidden" value="<?php echo ( $value ); ?>" name="<?php echo esc_attr( $name ); ?>[]" class="zeen-engine-input-val">
												</span>
												<?php $i++; ?>
											<?php } ?>

										<?php } ?>
									</span>
								</div>
							<?php
							break;
							case 'background':
								$current_bg_repeat = isset( $current_value ['repeat'] ) ? $current_value ['repeat'] : 1;
								$current_bg_src = isset( $current_value ['src'] ) ? $current_value ['src'] : '';
								$current_bg_color = isset( $current_value ['color'] ) ? $current_value ['color'] : '';
								$current_bg_select = isset( $current_value ['src'] ) && ! empty( $current_value ['src'] ) ? '' : 'zeen-engine-hide';
								?>
								<div class="zeen-engine-control-only">
									<input class="zeen-engine-color-pick zeen-engine-input-val" name="<?php echo esc_attr( $name ); ?>[color]" type="text" value="<?php echo esc_attr( $current_bg_color ); ?>">
									<span class="tipi-img-input-wrap">
										<input type="text" value="<?php echo esc_url( $current_bg_src ); ?>" name="<?php echo esc_attr( $name ); ?>[src]" class="zeen-engine-img-input zeen-engine-input-val">
										<a href="#" class="zeen-engine-upload" data-dest="zeen-engine-meta-control-<?php echo esc_attr( $this->zeen_engine_prefix . '-' . $id ); ?>" data-output="src" data-name="<?php echo esc_attr( $name ); ?>"><?php esc_html_e( 'Upload', 'zeen-engine' ); ?></a>
									</span>

									<select name="<?php echo esc_attr( $name ); ?>[repeat]" class="zeen-engine-vis-switch <?php echo esc_attr( $current_bg_select ); ?>">
										<?php foreach ( $bg_repeat_args as $key => $value ) { ?>
											<option value="<?php echo (int) ( $key ); ?>" <?php selected( $current_bg_repeat, $key ); ?>><?php echo zeen_engine_sanitize_wp_kses( $value ); ?></option>
										<?php } ?>
									</select>

									<?php if  ( ! empty( $current_bg_src ) ) { ?>
										<span class="zeen-engine-img">
											<a href="#" class="zeen-engine-remove zeen-engine--x"></a>
											<img src="<?php echo esc_url( $current_bg_src ); ?>" alt="">
										</span>
									<?php } ?>
								</div>
							<?php
							break;
						}
						?>
					</div>
				</div>

			<?php } ?>
			<?php if ( $closer == true ) { ?></div><?php } ?>
			</div>
		</div>
	<?php
	}
	public function drag_field( $args = array() ) {

		if ( empty( $args['current_value']) ) {
			$allvals = array();
			foreach ( $args['choices'] as $choice ) {
				$allvals[0][$choice['name']] =  '';
			}
		} else {
			$allvals = $args['current_value'];
		}

		$count = count( $args['choices'] );
		$i = 1;
		$j = 1;
		foreach ( $allvals as $key ) {
			?>
			<div class="zeen-engine-drag-el">
				<div class="zeen-engine-drag-x"></div>
				<?php foreach ( $args['choices'] as $choice ) {
					echo '<div class="drag-item-title">' . $choice['title'] . '</div>';
					if ( $choice['type'] == 'text' ) {
						?>
						<div class="zeen-engine-text-wrap">
						<input <?php $this->drag_name( $args, $choice, $j ); ?> type="text" value="<?php echo esc_attr( $key[$choice['name']] ); ?>" class="zeen-engine-input-val<?php if ( ! empty( $args['dummy'] ) ) { ?> zeen-engine-data<?php } ?>">
						</div>
						<?php
					}
				}
				if ( $i = $count + 1 ) {
					$i = 1;
					$j++;
				}
				$i++;
				?>
			</div>
		<?php
		}

	}

	public function drag_name( $args, $choice, $j ) {
			if ( empty( $args['dummy'] ) ) { ?>
				name="<?php echo esc_attr( $args['name'] ) . '[' . (int) ( $j ) . '][' .  $choice['name'] . ']' ; ?>"
		<?php } else { ?>
			data-name="<?php echo esc_attr( $args['name'] ); ?>"
			data-choice="<?php echo esc_attr( $choice['name'] ); ?>"
		<?php }
	}

}
