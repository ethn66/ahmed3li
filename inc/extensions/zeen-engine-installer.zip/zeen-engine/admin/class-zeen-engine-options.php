<?php
/**
 * Zeen Engine options
 *
 * @package     Zeen_Engine
 * @copyright   Copyright Codetipi
 * @since       1.0.0
 */
class Zeen_Engine_Options {

	/**
	 * Options
	 *
	 * @since    1.0.0
	 */
	static $zeen_engine_options;

	/**
	 * Options getter
	 *
	 * @since    1.0.0
	 */
	static function zeen_engine_get_option( $option = 'zeen_engine_options' ) {

		self::$zeen_engine_options = get_option( $option, array() );

	}

	/**
	 * Options setter
	 *
	 * @since    1.0.0
	 */
	static function zeen_engine_update_option() {

		$options = self::zeen_engine_sanitized();
		update_option( 'zeen_engine_options', $options );
		self::$zeen_engine_options = get_option( 'zeen_engine_options' );

	}

	/**
	 * Options sanitizer
	 *
	 * @since    1.0.0
	 */
	private static function zeen_engine_sanitized( $option = '' ) {

		$option = empty( $option ) ? self::$zeen_engine_options : $option;
		$sanitized_array = array();
		if ( ! is_array( $option ) ) {
			return array();
		}

		foreach ( $option as $key => $value ) {

			if ( ! is_array( $value ) && ! is_object( $value ) ) {
				$sanitized_array[ esc_html( $key ) ] = esc_attr( $value );
			}

			if ( is_array( $value ) && ! empty( $value ) ) {
				$sanitized_array[ esc_html( $key ) ] = self::zeen_engine_sanitized( $value );
			}
		}

		return $sanitized_array;
	}

}

Zeen_Engine_Options::zeen_engine_get_option();
