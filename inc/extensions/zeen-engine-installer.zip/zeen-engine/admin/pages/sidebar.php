<?php
/**
 * Sidebar Page
 *
 * @since    1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$sidebars = array();
if ( class_exists( 'ZeenOptions' ) ) {
	$pids = ZeenOptions::zeen_get_sidebar_pids();
	if ( ! empty( $pids ) ) {
		foreach ( $pids as $pid ) {
			$sidebars[] = array(
				'sbtype' => 'pids',
				'type'   => esc_html__( 'Post', 'zeen-engine' ),
				'id'     => $pid,
				'label'  => get_the_title( $pid ),
			);
		}
	}
	$bids = ZeenOptions::zeen_get_sidebar_bids();
	if ( ! empty( $bids ) ) {
		foreach ( $bids as $bid => $bid_val ) {
			$bid_uid              = is_array( $bid_val ) ? $bid_val['uid'] : $bid;
			$sidebars[ $bid_uid ] = array(
				'sbtype' => 'bids',
				'type'   => esc_html__( 'Builder', 'zeen-engine' ),
				'id'     => $bid_uid,
				'label'  => esc_attr( 'Tipi Builder Sidebar', 'zeen' ) . ' (' . $bid_uid . ')',
			);
		}
	}
	$tids = ZeenOptions::zeen_get_sidebar_tids();
	if ( ! empty( $tids ) ) {
		foreach ( $tids as $tid ) {
			$taxonomies = get_taxonomies(
				array(
					'public' => true,
				),
				'names'
			);
			if ( is_array( $tid ) ) {
				$tuid = $tid['uid'];
			} else {
				$tuid = $tid;
			}
			$terms = get_terms(
				array(
					'taxonomy'   => $taxonomies,
					'hide_empty' => false,
					'include'    => $tuid,
				)
			);
			if ( empty( $terms[0]->taxonomy ) || ! empty( $terms[0]->taxonomy ) && 'post_tag' == $terms[0]->taxonomy ) {
				$tax      = get_taxonomy_labels( $terms[0] );
				$tax_name = $tax->singular_name;
			} else {
				$tax_name = $terms[0]->taxonomy;
			}
			$sidebars[] = array(
				'sbtype' => 'tids',
				'type'   => $tax_name,
				'id'     => $tuid,
				'label'  => $terms[0]->name,
			);
		}
	}
	$cids = ZeenOptions::zeen_get_sidebar_cids();
	if ( ! empty( $cids ) ) {
		foreach ( $cids as $cid => $cid_val ) {
			$cid_uid              = $cid_val['uid'];
			$sidebars[ $cid_uid ] = array(
				'sbtype' => 'cids',
				'type'   => esc_html__( 'Custom Sidebars', 'zeen-engine' ),
				'id'     => $cid_uid,
				'label'  => $cid_val['label'] . ' (' . $cid_uid . ')',
			);
		}
	}
}
?>
<div class="tipi-block tipi-help">
	<div class="tipi-box tipi-xs-12 tipi-col">
		<div class="tipi-content-area">
			<div class="tipi-title-with-i zeen-engine-cf">
				<span class="tipi-title-i"><i class="ze-i-layout"></i></span>
				<div class="tipi-title">
					<h3><?php esc_html_e( 'Custom Sidebars', 'zeen-engine' ); ?></h3>
				</div>
			</div>
			<div class="tipi-content">
				<?php
				if ( ! class_exists( 'ZeenOptions' ) || empty( $sidebars ) ) {
					esc_html_e( 'You have not created any custom sidebars in Zeen yet.', 'zeen-engine' );
				} else {
					?>
				<div class="zeen-engine-cf tipi-content-text">
					<?php esc_html_e( 'Here is a list of all the custom sidebars you have created in Zeen', 'zeen-engine' ); ?>:
				</div>
				<div class="zeen-engine-cf tipi-content-text">
					<div class="zeen-engine-sb-wrap">
						<div class="zeen-engine-sb">
							<div class="sb-type"><?php esc_html_e( 'Created In', 'zeen-engine' ); ?></div>
							<div class="sb-title"><?php esc_html_e( 'Name', 'zeen-engine' ); ?></div>
						</div>
						<?php foreach ( $sidebars as $sb ) { ?>
								<div class="zeen-engine-sb">
									<div class="sb-type"><?php echo ucfirst( esc_attr( $sb['type'] ) ); ?></div>
									<div class="sb-title"><?php echo esc_attr( $sb['label'] ); ?></div>
									<a href="#" class="zeen-engine-sb-delete" data-id="<?php echo esc_attr( $sb['id'] ); ?>" data-type="<?php echo esc_attr( $sb['sbtype'] ); ?>"><i class="ze-i-x"></i></a>
								</div>
						<?php } ?>
					</div>
				</div>
				<div class="zeen-engine-cf tipi-content-text zeen-engine-create-sb-wrap">
					<input type="text" name="zeen_engine_sidebar_title" id="zeen-engine-create-sb-title" autocomplete="off">
					<a href="#" id="zeen-engine-create-sb" class="button button-primary" target="_blank"><?php esc_html_e( 'Create Sidebar', 'zeen-engine' ); ?></a>
				</div>
				<?php } ?>
			</div>
		</div>
	</div>
</div>
