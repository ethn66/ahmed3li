<?php
/**
 * Default Page
 *
 * @since    1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
$src = get_parent_theme_file_uri( 'assets/admin/img/welcome.jpg' );
$src2x = 'srcset="' . get_parent_theme_file_uri( 'assets/admin/img/welcome@2x.jpg' ) . ' 2x"';
$override = get_theme_mod( 'white_label_welcome_image' );
if ( ! empty( $override ) && get_theme_mod( 'white_label_onoff' ) == 1 ) {
	$src = wp_get_attachment_image_src( $override, 'full' );
	$src = $src[0];
	$src2x = '';
	$white_label = true;
}
?>	
<div class="tipi-block tipi-welcome">
	
	<div class="tipi-box tipi-xs-12 tipi-m-6 tipi-col tipi-col-first">
		<img src="<?php echo esc_url( $src ); ?>" <?php echo zeen_engine_sanitize_wp_kses( $src2x ); ?> alt="">
	</div>
	<?php if ( empty( $white_label ) ) { ?>
	<div class="tipi-box tipi-xs-12 tipi-m-6 tipi-col tipi-col-last tipi-changelog">
		<div class="tipi-content-area">
			<div class="tipi-title-with-i zeen-engine-cf">
				<span class="tipi-title-i"><i class="ze-i-file-text"></i></span>
				<div class="tipi-title">
					<h3><?php esc_html_e( 'Changelog', 'zeen-engine' ); ?></h3>
				</div>
			</div>
			<div class="tipi-content">
				<?php echo do_action( 'zeen_engine_changelog' ); ?>
			</div>
		</div>
	</div>
	<?php } ?>
</div>
