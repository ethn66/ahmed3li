<?php
/**
 * Community Page
 *
 * @since    1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>	
<div class="tipi-block tipi-help">
	<div class="tipi-box tipi-xs-12 tipi-col">
		<div class="tipi-content-area">
			<div class="tipi-title-with-i zeen-engine-cf">
				<span class="tipi-title-i"><i class="ze-i-users"></i></span>
				<div class="tipi-title">
					<h3><?php esc_html_e( 'Join The Zeen Community', 'zeen-engine' ); ?></h3>
				</div>
			</div>
			<div class="tipi-content">
				<div class="zeen-engine-cf tipi-content-text">
					<?php esc_html_e( 'Join the Zeen community to meet other Zeen users, learn, share and discuss everything Zeen.', 'zeen-engine' ); ?>
				</div>
				<a href="https://www.facebook.com/groups/zeentheme/" class="button button-primary" target="_blank"><?php esc_html_e( 'Apply For Free Membership', 'zeen-engine' ); ?></a>
			</div>
		</div>
	</div>
</div>