<?php
/**
 * Documentation Page
 *
 * @since    1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>	
<div class="tipi-block tipi-help">
	
	<div class="tipi-box tipi-xs-12 tipi-m-4 tipi-col">
		<div class="tipi-content-area">
			<div class="tipi-title-with-i zeen-engine-cf">
				<span class="tipi-title-i"><i class="ze-i-book"></i></span>
				<div class="tipi-title">
					<h3><?php esc_html_e( 'Documentation', 'zeen-engine' ); ?></h3>
				</div>
			</div>
			<div class="tipi-content">
				<div class="zeen-engine-cf tipi-content-text">
					<?php esc_html_e( 'The first place to go to whenever you have any questions about the plugin. Detailed instructions for all the plugin features.', 'zeen-engine' ); ?>
				</div>
				<a href="https://docs.codetipi.com/zeen" class="button button-primary" target="_blank"><?php esc_html_e( 'Open documentation', 'zeen-engine' ); ?></a>
			</div>
		</div>
	</div>
	<div class="tipi-box tipi-xs-12 tipi-m-4 tipi-col ">
		<div class="tipi-content-area">
			<div class="tipi-title-with-i zeen-engine-cf">
				<span class="tipi-title-i"><i class="ze-i-play-circle"></i></span>
				<div class="tipi-title">
					<h3><?php esc_html_e( 'Video Tutorials', 'zeen-engine' ); ?></h3>
				</div>
			</div>
			<div class="tipi-content">
				<div class="zeen-engine-cf tipi-content-text">
					<?php esc_html_e( 'If you prefer watching videos showing how things are done. Watch multiple video tutorials to show how things work.', 'zeen-engine' ); ?>
				</div>
				<a href="https://www.youtube.com/channel/UCabkI1KhtijXEnq_S0XtQ0g" class="button button-primary" target="_blank"><?php esc_html_e( 'Watch Videos', 'zeen-engine' ); ?></a>
			</div>
		</div>
	</div>
	<div class="tipi-box tipi-xs-12 tipi-m-4 tipi-col">
		<div class="tipi-content-area">
			<div class="tipi-title-with-i zeen-engine-cf">
				<span class="tipi-title-i"><i class="ze-i-users"></i></span>
				<div class="tipi-title">
					<h3><?php esc_html_e( 'Support', 'zeen-engine' ); ?></h3>
				</div>
			</div>
			<div class="tipi-content">
				<div class="zeen-engine-cf tipi-content-text">
				<?php esc_html_e( "If you can't find the answer in the documentation or video tutorials then feel free to open a ticket in the support system.", 'zeen-engine' ); ?>
				</div>
				<a href="http://codetipi.ticksy.com" class="button button-primary" target="_blank"><?php esc_html_e( 'Open Support', 'zeen-engine' ); ?></a>
			</div>
		</div>
	</div>
</div>