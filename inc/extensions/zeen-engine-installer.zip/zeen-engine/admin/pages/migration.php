<?php
/**
 * Migration Page
 *
 * @since    1.0.0
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
?>	
<div class="tipi-block tipi-help">
	<div class="tipi-box tipi-xs-12 tipi-col">
		<div class="tipi-content-area">
			<div class="tipi-title-with-i zeen-engine-cf">
				<span class="tipi-title-i"><i class="ze-i-play-circle"></i></span>
				<div class="tipi-title">
					<h3><?php esc_html_e( 'Migration', 'zeen-engine' ); ?></h3>
				</div>
			</div>
			<div class="tipi-content">
				<div class="zeen-engine-cf tipi-content-text">
					<?php esc_html_e( 'To migrate old data from your previous theme simply select your previous theme and then click the button below. This will attempt to migrate old theme options and post data such as video and audio data. Is will not overwrite any Zeen settings if you have already set them.', 'zeen-engine' ); ?>
				</div>
				<div class="zeen-engine-cf tipi-content-text">
					<select id="theme__selection">
						<option value="valenti">Valenti</option>
						<option value="15zine">15Zine</option>
					</select>
				</div>
				<a href="#" class="button button-primary button__zeen__migration"><?php esc_html_e( 'Run Migration', 'zeen-engine' ); ?></a>
			</div>
		</div>
	</div>
</div>