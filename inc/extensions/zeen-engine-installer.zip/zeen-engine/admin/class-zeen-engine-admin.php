<?php
/**
 *
 * Zeen Engine Admin
 *
 * @since      1.0.0
 *
 * @package    Zeen Engine
 * @subpackage zeen-engine/admin
 */

class Zeen_Engine_Admin {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	*/
	public function __construct( $slug, $version, $url ) {
		$this->slug    = $slug;
		$this->version = $version;
		$this->url     = $url;
		add_action( 'after_setup_theme', array( $this, 'zeen_engine_thumbnails' ) );
		add_action( 'edit_form_before_permalink', array( $this, 'zeen_engine_after_title' ) );
		add_action( 'wp_ajax_zeen_engine_sb_remove', array( $this, 'zeen_engine_sb_remove' ) );
		add_action( 'wp_ajax_zeen_engine_sb_add', array( $this, 'zeen_engine_sb_add' ) );
		add_action( 'wp_ajax_zeen_engine_migration', array( $this, 'zeen_engine_migration' ) );
		add_filter( 'wp_prepare_themes_for_js', array( $this, 'zeen_engine_white_label' ) );
	}

	/**
	 * Scripts
	 *
	 * @since    1.0.0
	 */
	public function scripts( $pagenow ) {

		if ( 'post.php' == $pagenow || 'post-new.php' == $pagenow || 'widgets.php' == $pagenow || 'term.php' == $pagenow || 'edit-tags.php' == $pagenow || 'nav-menus.php' == $pagenow || strpos( $pagenow, 'zeen' ) !== false ) {
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_script( 'jquery-ui-core' );
			wp_enqueue_script( 'jquery-ui-slider' );
			wp_enqueue_script( 'suggest' );
			wp_enqueue_script( 'jquery-ui-datepicker' );
			wp_enqueue_media();
			wp_enqueue_style( 'zeen-engine', esc_url( $this->url . 'admin/css/admin-style.min.css' ), array(), $this->version, 'all' );
			wp_enqueue_style( 'zeen-engine-i', esc_url( $this->url . 'admin/css/style.css' ), array(), $this->version, 'all' );

			wp_enqueue_script( 'zeen-engine-admin-vendors-js', esc_url( $this->url . 'admin/js/zeen-engine-admin-vendors.js' ), array( 'jquery', 'jquery-ui-datepicker', 'jquery-ui-core', 'jquery-ui-slider', 'wp-color-picker' ), $this->version, true );
			wp_enqueue_script( 'zeen-engine-js', esc_url( $this->url . 'admin/js/zeen-engine-admin.js' ), array( 'jquery', 'zeen-engine-admin-vendors-js' ), $this->version, true );
			wp_localize_script(
				'zeen-engine-js',
				'zeenEngineJS',
				array(
					'i18n'  => self::i18n(),
					'nonce' => wp_create_nonce( 'zeen_engine_nonce' ),
					'ajax'  => admin_url( 'admin-ajax.php' ),
				)
			);
		}

	}

	public function zeen_engine_migration() {
		if ( ! wp_verify_nonce( $_POST['nonce'], 'zeen_engine_nonce' ) || ! current_user_can( 'edit_posts' ) ) {
			wp_die();
		}
		require_once plugin_dir_path( dirname( __FILE__ ) ) . 'admin/migration-do.php';
		$type      = $_POST['type'];
		$migration = zeen_engine_migration_do( $type );
		wp_send_json_success( $migration );
		wp_die();
	}

	public function zeen_engine_sb_remove() {

		if ( ! wp_verify_nonce( $_POST['nonce'], 'zeen_engine_nonce' ) || ! current_user_can( 'edit_posts' ) ) {
			wp_die();
		}
		$id   = $_POST['id'];
		$type = $_POST['type'];
		$name = 'zeen_sidebar_' . $type;
		if ( isset( Zeen_Engine_Options::$zeen_engine_options[ $name ] ) ) {
			foreach ( Zeen_Engine_Options::$zeen_engine_options[ $name ] as $key => $val ) {
				if ( ! empty( $val['uid'] ) && $id == $val['uid'] ) {
					$search = $key;
				}
			}
			if ( ! isset( $search ) ) {
				$search = array_search( $id, Zeen_Engine_Options::$zeen_engine_options[ $name ] );
			}
			if ( false !== $search ) {
				unset( Zeen_Engine_Options::$zeen_engine_options[ $name ][ $search ] );
				Zeen_Engine_Options::zeen_engine_update_option();
				if ( 'tids' == $type ) {
					update_term_meta( $id, $name, '' );
				} elseif ( 'pids' == $type ) {
					update_post_meta( $id, $name, '' );
				}
			}
		}
		wp_send_json_success();
		wp_die();
	}

	public function zeen_engine_sb_add() {

		if ( ! wp_verify_nonce( $_POST['nonce'], 'zeen_engine_nonce' ) || ! current_user_can( 'edit_posts' ) ) {
			wp_die();
		}
		$uid   = mt_rand( 10000, 99999 );
		$title = empty( $_POST['title'] ) ? 'Sidebar ' . $uid : $_POST['title'];
		$entry = array(
			'uid'   => $uid,
			'label' => $title,
		);
		if ( isset( Zeen_Engine_Options::$zeen_engine_options['zeen_sidebar_cids'] ) ) {
			if ( ! in_array( $title, Zeen_Engine_Options::$zeen_engine_options['zeen_sidebar_cids'] ) ) {
				Zeen_Engine_Options::$zeen_engine_options['zeen_sidebar_cids'][ $uid ] = $entry;
			}
		} else {
			Zeen_Engine_Options::$zeen_engine_options['zeen_sidebar_cids'] = array( $entry );
		}
		Zeen_Engine_Options::zeen_engine_update_option();
		wp_send_json_success( $entry );
		wp_die();
	}

	/**
	 * Thumbnail Sizes
	 *
	 * @since    1.0.0
	 */
	public function zeen_engine_thumbnails() {
		add_image_size( 'zeen-engine-293-293', 293, 293, true );
	}

	/**
	 * i18n
	 *
	 * @since    1.0.0
	 */
	public static function i18n() {

		$output = array();

		$output['titleButton']          = esc_html__( 'Insert', 'zeen-engine' );
		$output['titleModal']           = esc_html__( 'Select Image', 'zeen-engine' );
		$output['customSidebars']       = esc_html__( 'Custom Sidebars', 'zeen-engine' );
		$output['titleGalleryModal']    = esc_html__( 'Select or Upload Images', 'zeen-engine' );
		$output['mdIcon1']              = get_parent_theme_file_uri( 'assets/admin/img/md-icon-1.png' );
		$output['mdIcon12x']            = get_parent_theme_file_uri( 'assets/admin/img/md-icon-1@2x.png' );
		$output['titleSbRemoveConfirm'] = esc_html__( 'Are you sure you want to delete this custom sidebar? If deleted it will no longer appear in your Widgets page either.', 'zeen-engine' );

		return $output;
	}

	function zeen_engine_white_label( $themes ) {
		if ( get_theme_mod( 'white_label_onoff' ) == 1 ) {
			$theme_name = get_theme_mod( 'white_label_folder_name', 'zeen' );
			if ( ! empty( $themes[ $theme_name ] ) ) {
				$shot = get_theme_mod( 'white_label_theme_screenshot' );
				if ( ! empty( $shot ) ) {
					$shot = wp_get_attachment_image_src( $shot, 'full' );
				}
				$shot                                   = empty( $shot[0] ) ? '' : $shot[0];
				$themes[ $theme_name ]['screenshot'][0] = $shot;
			}
			$child_theme_name = get_theme_mod( 'white_label_folder_name', 'zeen-child' );
			if ( ! empty( $themes[ $child_theme_name ] ) ) {
				$child_shot = get_theme_mod( 'white_label_theme_screenshot_child' );
				if ( ! empty( $child_shot ) ) {
					$child_shot = wp_get_attachment_image_src( $child_shot, 'full' );
				}
				$child_shot                                   = empty( $child_shot[0] ) ? '' : $child_shot[0];
				$themes[ $child_theme_name ]['screenshot'][0] = $child_shot;
			}
		}
		return $themes;
	}

	/**
	 * After Title
	 *
	 * @since    1.0.0
	 */
	public function zeen_engine_after_title( $post ) {
		if ( 'post' != $post->post_type ) {
			return;
		}
		$pid = $post->ID;

		$value = get_post_meta( $pid, 'zeen_subtitle', true );
		$value = ! isset( $value ) ? get_post_meta( $pid, 'wps_subtitle', true ) : $value;
		$value = ! isset( $value ) ? get_post_meta( $pid, '_subtitle', true ) : $value;
		?>
		<input type="text" id="zeen-engine-subtitle" tabindex="1" class="zeen-engine-subtitle" name="zeen_subtitle" value="<?php echo esc_attr( $value ); ?>" autocomplete="off" spellcheck="true" placeholder="<?php esc_html_e( 'Enter subtitle here', 'zeen-engine' ); ?>">
		<?php
	}
}
