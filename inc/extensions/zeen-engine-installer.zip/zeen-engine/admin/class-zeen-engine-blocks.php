<?php
/**
 *
 * Zeen Engine Blocks
 *
 * @since      2.0.0
 *
 * @package    Zeen Engine
 * @subpackage zeen-engine/admin
 */

class Zeen_Engine_Blocks {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	*/
	public function __construct( $slug, $version, $url ) {
		$this->slug = $slug;
		$this->version = $version;
		$this->url = $url;
	}

	public function zeen_engine_block_category( $categories, $post ) {
		return array_merge(
			$categories,
			array(
				array(
					'slug' => 'zeen-blocks',
					'title' => esc_attr__( 'Zeen Blocks', 'zeen-engine' ),
				),
			)
		);
	}

	public function zeen_engine_render_inline( $attr = '' ) {
		$pid = empty( $attr['pid'] ) ? '' : $attr['pid'];
		$title = empty( $attr['title'] ) ? '' : $attr['title'];
		if ( ! function_exists( 'zeen_post_inline' ) ) {
			return;
		}
		return zeen_post_inline( array( 'pid' => $pid, 'title' => $title ) );
	}

	function zeen_engine_builder_launch( $active = '' ) {
		global $post;
		$url = $this->zeen_engine_builder_url( $post->ID );
		ob_start();
		?>
		<button type="button"<?php if ( empty( $active ) ) { echo ' disabled'; } ?> data-href="<?php echo esc_url( $url ); ?>" id="tipi-builder-launcher" class="editor-post-save-draft components-button editor-launch-tipi-builder is-button is-default is-primary is-large"><?php esc_html_e( 'Edit With Tipi Builder', 'zeen-engine' ); ?></button>
		<?php
		return ob_get_clean();
	}

	function zeen_engine_builder_url( $pid = '' ) {
		return add_query_arg( array( 'tipi_builder' => '1', 'pid' => $pid ), get_permalink( $pid ) );
	}

	function zeen_engine_args() {
		global $post;
		$output = array();
		$output['tipiBuilderActive'] = get_post_meta( $post->ID, 'tipi_builder_active', true ) ? true : false;
		$output['launcher'] = $this->zeen_engine_builder_launch( $output['tipiBuilderActive'] );
		$output['textActive'] = esc_attr__( 'Active', 'zeen-engine' );
		$output['textStatus'] = esc_attr__( 'Status', 'zeen-engine' );
		$output['buttonURL'] = $this->zeen_engine_builder_url( $post->ID );
		$output['buttonText'] = esc_html__( 'Edit With Tipi Builder', 'zeen-engine' );
		$output['close']       = esc_html__( 'Close', 'zeen-engine' );
		$output['now']       = esc_html__( 'Now', 'zeen-engine' );
		$output['titleWarning']       = esc_html__( 'Warning', 'zeen-engine' );
		$output['titleCancel']       = esc_html__( 'Cancel', 'zeen-engine' );
		$output['titleContinue']     = esc_html__( 'Continue', 'zeen-engine' );
		$output['tipiModalContent']  = esc_html__( 'Existing content was found on the page. If you use the Tipi Builder that content will be replaced.', 'zeen-engine' );
		$output['titleModal']        = esc_html__( 'Select Image', 'zeen-engine' );
		$output['titleGalleryModal'] = esc_html__( 'Select or Upload Images', 'zeen-engine' );
		$output['validateMsg']       = esc_html__( 'Are you sure you want to remove your validated license from this domain?', 'zeen-engine' );
		$output['tipiBuilderLogo'] = array( esc_url( get_parent_theme_file_uri( 'inc/builder/assets/img/tipi-builder-mark-s.png' ) ), esc_url( get_parent_theme_file_uri( 'inc/builder/assets/img/tipi-builder-mark-s@2x.png' ) ) );
		return $output;
	}

	function zeen_engine_block_editor_assets() {
		wp_enqueue_script( 'zeen_engine-builder-js', esc_url( $this->url . 'admin/js/zeen-engine-builder.min.js' ), array( 'wp-blocks', 'wp-dom-ready', 'wp-i18n', 'wp-element', 'wp-editor' ) );
		wp_localize_script( 'zeen_engine-builder-js', 'zeenEngineBuilderJS', array(
			'args' => $this->zeen_engine_args(),
		) );
	}

}
