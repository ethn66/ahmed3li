<?php
/**
 * Login
 *
 * @package Zeen_Engine
 * @since 1.0.0
 */

/**
 * Scripts
 *
 * @since 1.0.0
 */

function zeen_engine__login() {
	$logo_id = get_theme_mod( 'logo_login' );
	$url = wp_get_attachment_url( $logo_id );
	$meta = wp_get_attachment_metadata( $logo_id );

	$logo_id_2x = get_theme_mod( 'logo_login_retina' );
	$url_2x = wp_get_attachment_url( $logo_id_2x );
	$skin = get_theme_mod( 'login_skin' );
	?>
	<style type="text/css">
		<?php if ( ! empty( $url ) ) { ?>
			#login h1 a {
				background-image: url( <?php echo esc_url( $url ); ?> );
				background-size: contain;
				margin: 0 auto 25px;
				width: <?php echo intval( $meta['width'] ); ?>px;
				height: <?php echo intval( $meta['height'] ); ?>px;
			}
			<?php if ( ! empty( $url_2x ) ) { ?>
			@media ( -webkit-min-device-pixel-ratio: 2 ) {
				#login h1 a {
					background-image: url( <?php echo esc_url( $url_2x ); ?> );
				}
			}
			<?php } ?>
		<?php } ?>
		<?php if ( 2 == $skin ) { ?>
			body { background:  #161616!important; }
			.login #login form {
				padding: 26px 24px 10px;
				box-shadow: none;
				background: transparent;
			}
			#wp-submit { 
				width: 100%;
				margin-top: 15px;
				height: 40px;
				border: 0;
				border-radius: 3px;
			 }
			input[type=text], input[type=search], input[type=radio], input[type=tel], input[type=time], input[type=url], input[type=week], input[type=password], input[type=checkbox], input[type=color], input[type=date], input[type=datetime], input[type=datetime-local], input[type=email], input[type=month], input[type=number], select, textarea {
				border: 0;
				box-shadow: none;
			}
			.login #login form .input, .login #login form input[type=checkbox], .login #login input[type=text] {
				background: #272727;
				border:  0;
				border-radius: 3px;
			}
			.login #login #backtoblog a, .login #login #nav a, .login #login label {
				color: #fff;
				opacity: 0.6;
			}
			.login #login #backtoblog a:hover, .login #login #nav a:hover, .login #login h1 a:hover {
				color: #00a0d2;
				opacity: 1;
			}
			.login #login #backtoblog a, .login #login #nav a, .login #login label {
				color: #fff;
				opacity: 0.6;
			}
			.login #login form .input, .login #login input[type=text] {
				border: none;
				color:  #fff;
				height: 40px;
				line-height: 40px;
				outline: none;
				background: #272727;
				margin-bottom: 15px;
				font-size: 1rem;
				width: 100%;
				border-radius: 3px;
				padding: 0 10px;
				-webkit-transition: all 0.2s;
				transition: all 0.2s;
			}
		<?php } ?>
	</style>
	<?php
}
add_action( 'login_enqueue_scripts', 'zeen_engine__login' );
