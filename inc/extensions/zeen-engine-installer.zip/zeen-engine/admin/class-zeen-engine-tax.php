<?php
/**
 * Zeen Engine Tax Class
 *
 * @package 	Zeen_Engine
 * @copyright   Copyright Codetipi
 * @since 		1.0.0
 */
class Zeen_Engine_Tax {

	/**
	 * Var for setup.
	 *
	 * @since    1.0.0
	 */
	private $zeen_engine_setup;

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	*/
	public function __construct( $zeen_engine_setup ) {

		$this->zeen_engine_args = $zeen_engine_setup['args'];
		$this->zeen_engine_taxonomy = $zeen_engine_setup['taxonomy'];
		$this->zeen_engine_src_uri = $zeen_engine_setup['src_uri'];
		$this->zeen_engine_prefix = $zeen_engine_setup['prefix'];
		if ( ! empty( $this->zeen_engine_taxonomy ) ) {
			foreach ( $this->zeen_engine_taxonomy as $taxonomy ) {
				add_action( 'created_' . $taxonomy, array( $this, 'zeen_engine_save' ) );
				add_action( 'edited_' . $taxonomy, array( $this, 'zeen_engine_save' ) );
				add_action( $taxonomy . '_add_form_fields', array( $this, 'zeen_engine_add_callback' ) );
				add_action( $taxonomy . '_edit_form_fields', array( $this, 'zeen_engine_edit_callback' ) );
			}
		}

	}

	/**
	 * Taxonomy Saver
	 *
	 * @since 1.0.0
	 * @param int $term_id The ID of the term being saved.
	 */
	public function zeen_engine_save( $term_id ) {
		// Important checks before saving
		// 1. Check if nonce exists 2. Verify nonce 3. Check for autosaving 4. Check taxonomy exists 5. Check user has right permissions
		if (
			( ! isset( $_POST['zeen_engine_tax_nonce'] ) )
			|| ( ! wp_verify_nonce( $_POST['zeen_engine_tax_nonce'], 'zeen_engine_tax' ) )
			|| ( ! isset( $term_id ) )
			|| ( ! isset( $_POST['taxonomy'] ) )
			|| ( ! current_user_can( 'manage_options' ) )
			) {
			return $term_id;
		}
		foreach ( $this->zeen_engine_edit_callback( $term_id, false ) as $option ) {
			$control        = $option['control'];
			$id             = $option['id'];
			$class          = isset( $option['class'] ) ? $option['class'] : '';
			$title          = isset( $option['title'] ) ? $option['title'] : '';
			$description    = isset( $option['description'] ) ? $option['description'] : '';
			$default        = isset( $option['default'] ) ? $option['default'] : '';
			$required       = isset( $option['required'] ) ? $option['required'] : '';
			$choices        = isset( $option['choices'] ) ? $option['choices'] : array();
			$global         = isset( $option['global'] ) ? $option['global'] : '';
			$name           = str_replace( '-', '_', $this->zeen_engine_prefix . '_' . $id );
			$sanitized_value = '';

			switch ( $control ) {
				case 'on-off':
					$sanitized_value = isset( $_POST[ $name ] ) ? 'on' : 'off';
					break;
				case 'text':
					$sanitized_value = isset( $_POST[ $name ] ) ? wp_kses_post( $_POST[ $name ] ) : '';
					break;
				case 'radio-images':
					$sanitized_value = isset( $_POST[ $name ] ) ? esc_attr( $_POST[ $name ] ) : '';
					break;
				case 'select':
					$sanitized_value = isset( $_POST[ $name ] ) ? esc_attr( $_POST[ $name ] ) : '';
					break;
				case 'color':
					$sanitized_value = isset( $_POST[ $name ] ) ? esc_attr( $_POST[ $name ] ) : '';
					break;
				case 'slider':
					$sanitized_value = isset( $_POST[ $name ] ) ? intval( $_POST[ $name ] ) : '';
					break;
				case 'image':
					$id_or_src = isset( $choices['type'] ) && 'id' == $choices['type'] ? 'id' : 'src';
					if ( 'id' == $id_or_src ) {
						$sanitized_value = isset( $_POST[ $name ] ) ? intval( $_POST[ $name ] ) : '';
					} else {
						$sanitized_value = isset( $_POST[ $name ] ) ? esc_url( $_POST[ $name ] ) : '';
					}
					break;
				case 'gallery':
					$sanitized_value = isset( $_POST[ $name ] ) ? $_POST[ $name ] : '';
					break;
				case 'background':
					$sanitized_value = isset( $_POST[ $name ] ) ? $_POST[ $name ] : '';
					break;

			}

			update_term_meta( $term_id, $name, $sanitized_value );

			if ( '' != $global ) {
				$current_value = get_term_meta( $term_id, $name, true );

				if ( $current_value != $global ) {
					continue;
				}

				$taxonomies = $this->zeen_engine_get_taxonomies();
				$terms = get_terms( array(
					'taxonomy' => $taxonomies,
					'hide_empty' => false,
					'include' => $term_id,
				) );

				if ( isset( Zeen_Engine_Options::$zeen_engine_options[ $name ] ) ) {
					if ( ! in_array( $term_id, Zeen_Engine_Options::$zeen_engine_options[ $name ] ) ) {
						Zeen_Engine_Options::$zeen_engine_options[ $name ][ $term_id ] = array(
							'uid' => $term_id,
							'label' => $terms[0]->name,
							'taxonomy' => $terms[0]->taxonomy,
						);
					}
				} else {
					Zeen_Engine_Options::$zeen_engine_options[ $name ][ $term_id ] = array(
						'uid' => $term_id,
						'label' => $terms[0]->name,
						'taxonomy' => $terms[0]->taxonomy,
					);
				}

				Zeen_Engine_Options::zeen_engine_update_option();
			}
		}
	}

	 /**
	 * Edit Callback
	 *
	 * @since 1.0.0
	 *
	 * @param string $term Name of taxonomy object.
	 *
	 */
	public function zeen_engine_add_callback( $term, $echo = true ) {

		$zeen_engine_options = $this->zeen_engine_args;

		if ( $echo == true ) {
			$this->zeen_engine_metabox_options( $term, $zeen_engine_options, 'add' );
		} else {
			return $zeen_engine_options;
		}

	}

	/**
	 * Edit Callback
	 *
	 * @since 1.0.0
	 *
	 * @param string $term Name of taxonomy object.
	 *
	 */
	public function zeen_engine_edit_callback( $term, $echo = true ) {

		$zeen_engine_options = $this->zeen_engine_args;

		if ( ! empty( $echo ) ) {
			$this->zeen_engine_metabox_options( $term, $zeen_engine_options, 'edit' );
		} else {
			return $zeen_engine_options;
		}

	}

	 /**
	 * Taxonomy Arguments
	 *
	 * @since 1.0.0
	 *
	 */
	public function zeen_engine_args() {
		return;
	}

	public function zeen_engine_metabox_options( $term, $zeen_engine_options, $zeen_engine_type ) {
		$j = 1;
		if ( $zeen_engine_type == 'add' ) {
			return;
		?>
		<div id="zeen-engine-taxonomy-extras" class="zeen-engine-metabox-wrap zeen-engine-cf">
			<div class="zeen-engine-metabox-controls">
			<?php
		}
			wp_nonce_field( 'zeen_engine_tax', 'zeen_engine_tax_nonce' );
			$builder_active = get_term_meta( $term->term_id, 'tipi_builder_active', true );
			foreach ( $zeen_engine_options as $option ) {

				$control        = $option['control'];
				$id             = $option['id'];
				$class          = isset( $option['class'] ) ? $option['class'] : '';
				$title          = isset( $option['title'] ) ? $option['title'] : '';
				$description    = isset( $option['description'] ) ? $option['description'] : '';
				$default        = isset( $option['default'] ) ? $option['default'] : '';
				$required       = isset( $option['required'] ) ? $option['required'] : '';
				$choices        = isset( $option['choices'] ) ? $option['choices'] : array();
				$name           = str_replace( '-', '_', $this->zeen_engine_prefix . '_' . $id );

				$current_value = $default;
				if ( isset( $term->term_id ) ) {
					$term_value = get_term_meta( $term->term_id, $name, true );
					$current_value = !empty( $term_value ) ? $term_value : $default;
				}

				$bg_repeat_args = array(
					1 => esc_html__( 'Cover', 'zeen-engine' ),
					2 => esc_html__( 'Repeat', 'zeen-engine' ),
					3 => esc_html__( 'No Repeat', 'zeen-engine' ),
				);

				$zeen_engine_vis = $required == NULL ? '' : 'display: none;';
				$zeen_engine_req = $required == NULL ? '' : 'zeen-engine-req';
				$req_id = $required == NULL ? '' : $required['id'];
				$req_value = $required == NULL ? '' :  $required['value'];
				$req_operator = ( $required != NULL && isset( $required['operator'] ) ) ? $required['operator'] : '';
				$req_value = is_array( $req_value ) ? json_encode( $req_value ) : $req_value;

				if ( $req_value == $current_value ) {
					$zeen_engine_vis = NULL;
				}

				if ( $zeen_engine_type == 'add' ) {
				?>
				<div id="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>" class="zeen-engine-control zeen-engine-meta-control zeen-engine-<?php echo esc_attr( $control ); echo '-wrap ' . esc_attr( $class ) . ' ' . esc_attr( $zeen_engine_req ); ?> zeen-engine-cf"<?php echo 'style="' . $zeen_engine_vis . '"'; ?> data-req="<?php echo esc_attr( 'zeen-engine-meta-control-' . $req_id ); ?>" data-req-val="<?php echo esc_attr( $req_value ); ?>" data-req-op="<?php echo esc_attr( $req_operator ); ?>" data-control="<?php echo esc_attr( $control ); ?>">


					<div class="zeen-engine-meta">
						<div class="zeen-engine-meta-title">
							<?php echo sanitize_text_field( $title ); ?>
							<?php if ( ! empty( $description) ) { ?>
								<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
							<?php } ?>
						</div>
					</div>
					<?php
				}
					switch ( $control ) {
						case 'builder':
						if ( $zeen_engine_type != 'add' ) {
							$url = get_term_link( intval( $term->term_id ), $term->taxonomy );
							$url = add_query_arg( array( 'tipi_builder' => '1', 'tid' => $term->term_id, 'tax' => $term->taxonomy ), $url );
							?>
							 <tr class="form-field zeen-engine-edit-tax zeen-engine-<?php echo esc_attr( $control ); ?>-wrap">
								<th scope="row"><label class="zeen-engine-meta-title" for="<?php echo esc_attr( $name ); ?>"><?php echo sanitize_text_field( $title ); ?><?php if ( ! empty( $description) ) { ?>
									<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
								<?php } ?>
								</label></th>
								<td id="tipi-builder-term" data-builder="<?php if ( 1 == $builder_active ) { echo 'on'; } else { echo 'off'; } ?>" class="tipi-builder-term"><a href="<?php echo esc_url( $url ); ?>" class="builder-launcher"><img src="<?php echo esc_url( $this->zeen_engine_src_uri . 'tipi-builder-mark-s.png' ); ?>" srcset="<?php echo esc_url( $this->zeen_engine_src_uri . 'tipi-builder-mark-s@2x.png' ); ?> 2x"> <?php esc_attr_e( 'Edit With Tipi Builder', 'zeen-engine' ); ?></a>
									<p class="description"><?php if ( 1 == $builder_active ) { echo '<span class="zeen-engine-info zeen-engine-info-on">' . esc_html__( 'Status', 'zeen-engine' ) . '</span>' . esc_attr__( 'Tipi Builder is active', 'zeen-engine' ); } else { echo '<span class="zeen-engine-info">' . esc_html__( 'Status', 'zeen-engine' ) . '</span>' . esc_attr__( 'Tipi Builder is not active', 'zeen-engine' );  } ?></p>
								</td>
							</tr>

							<?php
							}
							break;
						case 'text':
							if ( $zeen_engine_type == 'add' ) {
						?>
							<div class="zeen-engine-control-only form-field">
								<input name="<?php echo esc_attr( $name ); ?>" type="text" value="<?php echo esc_attr( $current_value ); ?>" class="zeen-engine-input-val">
							</div>
						<?php
							} else {
						?>  <tr class="form-field zeen-engine-edit-tax zeen-engine-<?php echo esc_attr( $control ); ?>-wrap">
								<th scope="row"><label class="zeen-engine-meta-title" for="<?php echo esc_attr( $name ); ?>"><?php echo sanitize_text_field( $title ); ?><?php if ( ! empty( $description) ) { ?>
									<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
								<?php } ?>
								</label></th>
								<td><input name="<?php echo esc_attr( $name ); ?>" id="zeen_engine_<?php echo esc_attr( $id ); ?>" type="text" value="<?php echo esc_attr( $current_value ); ?>" size="40" aria-required="true">
								</td>
							</tr>
						<?php
							}
						break;
						case 'on-off':
							if ( $zeen_engine_type == 'add' ) {
						?>
							<div class="zeen-engine-control-only form-field">
								<span class="zeen-engine-on-off">
									<input id="zeen-engine-id-<?php echo esc_attr( $id ); ?>" type="checkbox" value="<?php echo esc_attr( $current_value ); ?>" <?php checked( $current_value, 'on' ); ?> name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-input-val">
									<label for="zeen-engine-id-<?php echo esc_attr( $id ); ?>">
										<span class="zeen-engine-on-off-ux"></span>
									</label>
								</span>
							</div>
						 <?php
							} else {
						?>
							<tr id="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>" class="form-field zeen-engine-edit-tax zeen-engine-control zeen-engine-meta-control zeen-engine-<?php echo esc_attr( $control ); echo '-wrap ' . esc_attr( $class ) . ' ' . esc_attr( $zeen_engine_req ); ?>"<?php echo 'style="' . $zeen_engine_vis . '"'; ?> data-req="<?php echo esc_attr( 'zeen-engine-meta-control-' . $req_id ); ?>" data-req-val="<?php echo esc_attr( $req_value ); ?>" data-req-op="<?php echo esc_attr( $req_operator ); ?>" data-control="<?php echo esc_attr( $control ); ?>">

								<th scope="row"><label class="zeen-engine-meta-title" for="<?php echo esc_attr( $name ); ?>"><?php echo sanitize_text_field( $title ); ?><?php if ( ! empty( $description) ) { ?>
									<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
								<?php } ?>
								</label></th>
								<td class="zeen-engine-relative">
									<span class="zeen-engine-on-off">
										<input id="zeen-engine-id-<?php echo esc_attr( $id ); ?>" type="checkbox" value="<?php echo esc_attr( $current_value ); ?>" <?php checked( $current_value, 'on' ); ?> name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-input-val">
										<label for="zeen-engine-id-<?php echo esc_attr( $id ); ?>">
											<span class="zeen-engine-on-off-ux"></span>
										</label>
									</span>
								</td>
							</tr>
						<?php
							}
						break;
						case 'radio-images':
							if ( $zeen_engine_type == 'add' ) {
						?>
							<span class="zeen-engine-radio-images zeen-engine-cf">
								<?php foreach ( $choices as $key => $value ) {
									$value['url']  = rtrim( $value['url'] , '/');
									$ext = substr( $value['url'] , -3 );

									if ( $ext == 'png' ) {
										$retina = substr_replace( $value[ 'url' ], '@2x', -4, 0);
									} ?>

									<span class="zeen-engine-radio-image">
										<input type="radio" id="<?php echo esc_attr( $id ) . '-' . $key; ?>" value="<?php echo esc_attr( $key );?>" <?php checked( $current_value, $key ); ?> name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-input-val">
										<label for="<?php echo esc_attr( $id . '-' . $key ); ?>">
											<?php if ( ! empty( $value['title'] ) ) { ?><div class="zeen-engine-label"><?php echo sanitize_text_field( $value['title'] ); ?></div>
													<?php } ?>
											<img src="<?php echo esc_url( $this->zeen_engine_src_uri . $value['url'] ); ?>" alt="" <?php if ( ! empty ( $retina ) ) { ?>srcset="<?php echo esc_url( $this->zeen_engine_src_uri . $retina ); ?> 2x" <?php } ?>>
										</label>
									</span>

								<?php } ?>
							</span>
							<?php } else { ?>
								<tr id="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>" class="form-field zeen-engine-edit-tax zeen-engine-control zeen-engine-meta-control zeen-engine-<?php echo esc_attr( $control ); echo '-wrap ' . esc_attr( $class ) . ' ' . esc_attr( $zeen_engine_req ); ?>"<?php echo 'style="' . $zeen_engine_vis . '"'; ?> data-req="<?php echo esc_attr( 'zeen-engine-meta-control-' . $req_id ); ?>" data-req-val="<?php echo esc_attr( $req_value ); ?>" data-req-op="<?php echo esc_attr( $req_operator ); ?>" data-control="<?php echo esc_attr( $control ); ?>">

									<th scope="row"><label class="zeen-engine-meta-title" for="<?php echo esc_attr( $name ); ?>"><?php echo sanitize_text_field( $title ); ?><?php if ( ! empty( $description) ) { ?>
									<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
								<?php } ?>
								</label></th>
									<td>
									<span class="zeen-engine-radio-images zeen-engine-cf">
									   <?php foreach ( $choices as $key => $value ) {
											$value['url']  = rtrim( $value['url'] , '/');
											$ext = substr( $value['url'] , -3 );

											if ( $ext == 'png' ) {
												$retina = substr_replace( $value[ 'url' ], '@2x', -4, 0);
											} ?>

											<span class="zeen-engine-radio-image">
												<input type="radio" id="<?php echo esc_attr( $id ) . '-' . $key; ?>" value="<?php echo esc_attr( $key );?>" <?php checked( $current_value, $key ); ?> name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-input-val">
												<label for="<?php echo esc_attr( $id . '-' . $key ); ?>">
													<?php if ( ! empty( $value['title'] ) ) { ?><div class="zeen-engine-label"><?php echo sanitize_text_field( $value['title'] ); ?></div>
													<?php } ?>
													<img src="<?php echo esc_url( $this->zeen_engine_src_uri . $value['url'] ); ?>" alt="" <?php if ( ! empty ( $retina ) ) { ?>srcset="<?php echo esc_url( $this->zeen_engine_src_uri . $retina ); ?> 2x" <?php } ?>>
												</label>
											</span>

										<?php } ?>
									</span>
									</td>
								</tr>
							<?php } ?>
						<?php
						break;
						case 'select':

							if ( $zeen_engine_type == 'add' ) {
						?>
							<div class="zeen-engine-control-only form-field">
								<select name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-input-val">
									<?php foreach ( $choices as $key => $value ) { ?>
										<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $current_value, $key ); ?>><?php echo sanitize_text_field( $value ); ?></option>
									<?php } ?>
								 </select>
							</div>
						<?php
							} else {
								?>
								<tr id="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>" class="form-field zeen-engine-edit-tax zeen-engine-control zeen-engine-<?php echo esc_attr( $control ); echo '-wrap ' . esc_attr( $class ) . ' ' . esc_attr( $zeen_engine_req ); ?>"<?php echo 'style="' . $zeen_engine_vis . '"'; ?> data-req="<?php echo esc_attr( 'zeen-engine-meta-control-' . $req_id ); ?>" data-req-val="<?php echo esc_attr( $req_value ); ?>" data-req-op="<?php echo esc_attr( $req_operator ); ?>" data-control="<?php echo esc_attr( $control ); ?>">

									<th scope="row"><label class="zeen-engine-meta-title" for="<?php echo esc_attr( $name ); ?>"><?php echo sanitize_text_field( $title ); ?><?php if ( ! empty( $description) ) { ?>
									<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
								<?php } ?>
								</label></th>
									<td>
										<select name="<?php echo esc_attr( $name ); ?>" id="zeen_engine_<?php echo esc_attr( $id ); ?>" class="postform">
											<?php foreach ( $choices as $key => $value ) { ?>
												<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $current_value, $key ); ?>><?php echo sanitize_text_field( $value ); ?></option>
											<?php } ?>
										</select>
									</td>
								</tr>
							<?php
							}
						break;
						case 'color':
						if ( $zeen_engine_type == 'add' ) {
						?>
							<div class="zeen-engine-control-only form-field">
								<input type="text" class="zeen-engine-color-pick zeen-engine-input-val" value="<?php echo esc_attr( $current_value ); ?>" name="<?php echo esc_attr( $name ); ?>">
							</div>
						<?php } else { ?>
							<tr class="form-field zeen-engine-edit-tax zeen-engine-<?php echo esc_attr( $control ); ?>-wrap">
								<th scope="row"><label class="zeen-engine-meta-title" for="<?php echo esc_attr( $name ); ?>"><?php echo sanitize_text_field( $title ); ?><?php if ( ! empty( $description) ) { ?>
									<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
								<?php } ?>
								</label></th>
								<td class="zeen-engine-control-only zeen-engine-meta-control"><input type="text" class="zeen-engine-color-pick zeen-engine-input-val" value="<?php echo esc_attr( $current_value ); ?>" name="<?php echo esc_attr( $name ); ?>">
								</td>
							</tr>
						<?php }
						break;
						case 'slider':
						if ( $zeen_engine_type == 'add' ) {
						?>
							<div class="zeen-engine-control-only form-field">
								<div class="zeen-engine-slider" data-value="<?php echo esc_attr( $current_value ); ?>" data-min="<?php echo esc_attr( $choices['min'] ); ?>" data-max="<?php echo esc_attr( $choices['max'] ); ?>" data-step="<?php echo esc_attr( $choices['step'] ); ?>" data-default="<?php echo esc_attr( $default ); ?>"></div>
								<input name="<?php echo esc_attr( $name ); ?>" type="text" value="<?php echo esc_attr( $current_value ); ?>" class="zeen-engine-input-val">
								<span class="zeen-engine-data"><span class="zeen-engine-val"><?php echo esc_attr( $current_value ); ?></span><span class="dashicons dashicons-backup zeen-engine-reset" title="<?php esc_html_e( 'Reset to default', 'zeen-engine' ); ?>"></span></span>
							</div>
						<?php } else { ?>
							<tr class="form-field zeen-engine-control zeen-engine-edit-tax zeen-engine-<?php echo esc_attr( $control ); ?>-wrap">
								<th scope="row"><label class="zeen-engine-meta-title" for="<?php echo esc_attr( $name ); ?>"><?php echo sanitize_text_field( $title ); ?><?php if ( ! empty( $description) ) { ?>
									<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
								<?php } ?>
								</label></th>
								<td> <span class="zeen-engine-slider" data-value="<?php echo esc_attr( $current_value ); ?>" data-min="<?php echo esc_attr( $choices['min'] ); ?>" data-max="<?php echo esc_attr( $choices['max'] ); ?>" data-step="<?php echo esc_attr( $choices['step'] ); ?>" data-default="<?php echo esc_attr( $default ); ?>"></span>
								<input name="<?php echo esc_attr( $name ); ?>" type="text" value="<?php echo esc_attr( $current_value ); ?>" class="zeen-engine-input-val">
								<span class="zeen-engine-data"><span class="zeen-engine-val"><?php echo esc_attr( $current_value ); ?></span><span class="dashicons dashicons-backup zeen-engine-reset" title="<?php esc_html_e( 'Reset to default', 'zeen-engine' ); ?>"></span></span>
								</td>
							</tr>
						<?php }
						break;
						case 'image':
							$id_or_src = isset( $choices['type'] ) && $choices['type'] == 'id' ? 'id' : 'src';
							if ( $zeen_engine_type == 'add' ) {
						?>
							<div class="zeen-engine-control-only form-field<?php if ( $id_or_src == 'id' ) { ?> zeen-engine-single-img-id<?php } ?>">
								<input <?php if ( $id_or_src == 'id' ) { ?>type="hidden"<?php } else { ?>type="text"<?php } ?> value="<?php if ( ! empty ( $current_value ) ) { if ( $id_or_src == 'id' ) { echo intval( $current_value ); } else { echo esc_url( $current_value); } } ?>" name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-img-input zeen-engine-input-val">
								<a href="#" class="zeen-engine-upload" data-dest="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>" data-output="<?php echo esc_attr( $id_or_src ); ?>" data-name="<?php echo esc_attr( $name ); ?>"><i class="fa fa-upload" aria-hidden="true"></i> <?php esc_html_e( 'Upload', 'zeen-engine' ); ?></a>
								<?php if ( ! empty ( $current_value ) ) { ?>
									<span class="zeen-engine-img">
										<?php
										if ( $id_or_src == 'id' ) {
											$current_value_img = wp_get_attachment_image_src ( $current_value, 'zeen-engine-293-293' );
											$current_value_img = $current_value_img[0];
										} else {
											$current_value_img = $current_value;
										}
										?>
										<a href="#" class="zeen-engine-remove zeen-engine--x"></a>
										<img src="<?php echo esc_url( $current_value_img ); ?>" alt="">
									</span>

								<?php } ?>
							</div>
							<?php } else { ?>
								<tr class="form-field zeen-engine-control zeen-engine-edit-tax zeen-engine-<?php echo esc_attr( $control ); ?>-wrap"  id="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>">
								<th scope="row"><label class="zeen-engine-meta-title" for="<?php echo esc_attr( $name ); ?>"><?php echo sanitize_text_field( $title ); ?><?php if ( ! empty( $description) ) { ?>
									<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
								<?php } ?>
								</label></th>
								<td class="zeen-engine-control-only zeen-engine-meta-control">

									<input <?php if ( $id_or_src == 'id' ) { ?>type="hidden"<?php } else { ?>type="text"<?php } ?> value="<?php if ( ! empty ( $current_value ) ) { if ( $id_or_src == 'id' ) { echo intval( $current_value ); } else { echo esc_url( $current_value); } } ?>" name="<?php echo esc_attr( $name ); ?>" class="zeen-engine-img-input zeen-engine-input-val">
									<a href="#" class="zeen-engine-upload" data-file-type="img" data-dest="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>" data-output="<?php echo esc_attr( $id_or_src ); ?>" data-name="<?php echo esc_attr( $name ); ?>"><i class="fa fa-upload" aria-hidden="true"></i> <?php esc_html_e( 'Upload', 'zeen-engine' ); ?></a>
									<?php if ( ! empty ( $current_value ) ) { ?>
										<span class="zeen-engine-img">
											<?php
											if ( $id_or_src == 'id' ) {
												$current_value_img = wp_get_attachment_image_src ( $current_value, 'zeen-engine-293-293' );
												$current_value_img = $current_value_img[0];
											} else {
												$current_value_img = $current_value;
											}
											?>
											<a href="#" class="zeen-engine-remove zeen-engine--x"></a>
											<img src="<?php echo esc_url( $current_value_img ); ?>" alt="">
										</span>

									<?php } ?>

								</td>
							</tr>

						<?php }
						break;
						case 'gallery':
						$i = 1;
						if ( $zeen_engine_type == 'add' ) {
						?>
							<div class="zeen-engine-control-only form-field">
								<a href="#" class="zeen-engine-gallery" data-dest="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>" data-counter="<?php if ( !empty ( $current_value ) ) { echo intval( count( $current_value ) ); } else { echo intval( $i ); } ?>" data-name="<?php echo esc_attr( $name ); ?>"><i class="fa fa-picture-o" aria-hidden="true"></i> <?php esc_html_e( 'Edit Gallery', 'zeen-engine' ); ?></a>
								<span class="zeen-engine-gallery-wrap zeen-engine-drag-drop">
									<?php if ( ! empty ( $current_value ) ) { ?>
										<?php foreach ( $current_value as $key => $value) { ?>
											<span class="zeen-engine-img">
												<?php $current_value_img = wp_get_attachment_image_src ( $value, 'zeen-engine-293-293' ); ?>
												<a href="#" class="zeen-engine-remove-gallery zeen-engine--x"></a>
												<img src="<?php echo esc_url( $current_value_img[0] ); ?>" alt="">
												<input type="hidden" value="<?php echo ( $value ); ?>" name="<?php echo esc_attr( $name ); ?>[]" class="zeen-engine-input-val">
											</span>
											<?php $i++; ?>
										<?php } ?>

									<?php } ?>
								</span>
							</div>
						<?php } else { ?>
							<tr class="form-field zeen-engine-control zeen-engine-edit-tax zeen-engine-<?php echo esc_attr( $control ); ?>-wrap"  id="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>">
								<th scope="row"><label class="zeen-engine-meta-title" for="<?php echo esc_attr( $name ); ?>"><?php echo sanitize_text_field( $title ); ?><?php if ( ! empty( $description) ) { ?>
									<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
								<?php } ?>
								</label></th>
								<td class="zeen-engine-control-only zeen-engine-meta-control"> <span><a href="#" class="zeen-engine-gallery" data-dest="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>" data-counter="<?php if ( !empty ( $current_value ) ) { echo intval( count( $current_value ) ); } else { echo intval( $i ); } ?>" data-name="<?php echo esc_attr( $name ); ?>"><i class="fa fa-picture-o" aria-hidden="true"></i> <?php esc_html_e( 'Edit Gallery', 'zeen-engine' ); ?></a>
								<span class="zeen-engine-gallery-wrap zeen-engine-drag-drop">
									<?php if ( ! empty ( $current_value ) ) { ?>

										<?php foreach ( $current_value as $key => $value) { ?>
											<span class="zeen-engine-img">
												<?php $current_value_img = wp_get_attachment_image_src ( $value, 'zeen-engine-293-293' ); ?>
												<a href="#" class="zeen-engine-remove-gallery zeen-engine--x"></a>
												<img src="<?php echo esc_url( $current_value_img[0] ); ?>" alt="">
												<input type="hidden" value="<?php echo ( $value ); ?>" name="<?php echo esc_attr( $name ); ?>[]" class="zeen-engine-input-val">
											</span>
											<?php $i++; ?>
										<?php } ?>

									<?php } ?>
								</span>
								</td>
							</tr>

						<?php }
						break;
						case 'background':
							$current_bg_repeat = isset( $current_value ['repeat'] ) ? $current_value ['repeat'] : 1;
							$current_bg_src = isset( $current_value ['src'] ) ? $current_value ['src'] : '';
							$current_bg_color = isset( $current_value ['color'] ) ? $current_value ['color'] : '';
							$current_bg_select = isset( $current_value ['src'] ) && ( $current_value ['src'] != NULL ) ? '' : 'zeen-engine-hide';
							if ( $zeen_engine_type == 'add' ) {
							?>
							<div class="zeen-engine-control-only form-field">
								<span class="tipi-img-input-wrap">
									<input type="text" value="<?php echo esc_url( $current_bg_src ); ?>" name="<?php echo esc_attr( $name ); ?>[src]" class="zeen-engine-img-input zeen-engine-input-val">
									<a href="#" class="zeen-engine-upload" data-dest="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>" data-output="src" data-name="<?php echo esc_attr( $name ); ?>"><?php esc_html_e( 'Upload', 'zeen-engine' ); ?></a>
								</span>

								<select name="<?php echo esc_attr( $name ); ?>[repeat]" class="zeen-engine-vis-switch <?php echo esc_attr( $current_bg_select ); ?>">
									<?php foreach ( $bg_repeat_args as $key => $value ) { ?>
										<option value="<?php echo intval( $key ); ?>" <?php selected( $current_bg_repeat, $key ); ?>><?php echo sanitize_text_field( $value ); ?></option>
									<?php } ?>
								</select>

								<?php if  ( ! empty( $current_bg_src ) ) { ?>
									<span class="zeen-engine-img">
										<a href="#" class="zeen-engine-remove zeen-engine--x"></a>
										<img src="<?php echo esc_url( $current_bg_src ); ?>" alt="">
									</span>
								<?php } ?>
								<input class="zeen-engine-color-pick zeen-engine-input-val" name="<?php echo esc_attr( $name ); ?>[color]" type="text" value="<?php echo esc_attr( $current_bg_color ); ?>">
							</div>
							<?php } else { ?>
								<tr class="form-field zeen-engine-control zeen-engine-edit-tax zeen-engine-<?php echo esc_attr( $control ); ?>-wrap"  id="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>">
								<th scope="row"><label class="zeen-engine-meta-title" for="<?php echo esc_attr( $name ); ?>"><?php echo sanitize_text_field( $title ); ?><?php if ( ! empty( $description) ) { ?>
									<div class="zeen-engine-description"><i class="dashicons dashicons-editor-help"></i><span><?php echo zeen_engine_sanitize_wp_kses( $description ); ?></span></div>
								<?php } ?>
								</label></th>
								<td class="zeen-engine-control-only zeen-engine-meta-control">
									<span class="tipi-img-input-wrap">
										<input type="text" value="<?php echo esc_url( $current_bg_src ); ?>" name="<?php echo esc_attr( $name ); ?>[src]" class="zeen-engine-img-input zeen-engine-input-val">
										<a href="#" class="zeen-engine-upload" data-dest="zeen-engine-meta-control-<?php echo esc_attr( $id ); ?>" data-output="src" data-name="<?php echo esc_attr( $name ); ?>"><?php esc_html_e( 'Upload', 'zeen-engine' ); ?></a>
									</span>

									<select name="<?php echo esc_attr( $name ); ?>[repeat]" class="zeen-engine-vis-switch <?php echo esc_attr( $current_bg_select ); ?>">
										<?php foreach ( $bg_repeat_args as $key => $value ) { ?>
											<option value="<?php echo intval( $key ); ?>" <?php selected( $current_bg_repeat, $key ); ?>><?php echo sanitize_text_field( $value ); ?></option>
										<?php } ?>
									</select>
									<?php if  ( ! empty( $current_bg_src ) ) { ?>
										<span class="zeen-engine-img">
											<a href="#" class="zeen-engine-remove zeen-engine--x"></a>
											<img src="<?php echo esc_url( $current_bg_src ); ?>" alt="">
										</span>
									<?php } ?>
									<input class="zeen-engine-color-pick zeen-engine-input-val" name="<?php echo esc_attr( $name ); ?>[color]" type="text" value="<?php echo esc_attr( $current_bg_color ); ?>">

								</td>
							</tr>
						<?php }
						break;
					}
				?>
				<?php if ( $zeen_engine_type == 'add' ) { ?>
					</div>
				<?php } ?>
			<?php } ?>
		<?php if ( $zeen_engine_type == 'add' ) { ?>
			</div>
		</div>
	<?php
		}
	}

	public function zeen_engine_get_taxonomies( $output = 'names' ) {

		if ( function_exists( 'zeen_get_taxonomies' ) ) {
			return zeen_get_taxonomies();
		}
		$taxonomies = get_taxonomies(
			array(
				'public'   => true,
			),
			$output
		);

		unset( $taxonomies['product_shipping_class'] );
		unset( $taxonomies['topic-tag'] );

		return $taxonomies;

	}

}

