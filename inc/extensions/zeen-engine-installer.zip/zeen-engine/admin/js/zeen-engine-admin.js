/**
 * Copyright: Codetipi
 * Theme: Zeen Engine
 * Version: 2.8.2
 */
(function( $ ) {

    'use strict';
	var zeenEngineAdmin = {
		init: function() {
			this.cache();
			this.bind();
			this.colorPicker();
			this.dragDrop();
			this.required();
			this.slider();
			this.dates();
		},
		cache: function() {
			this.$doc				= $( document );
			this.$body				= $( 'body' );
			this.$colorPicker 		= $( '.zeen-engine-color-pick' );
			this.$colorPickerA 		= $( '.zeen-engine-color-pick-a' );
			this.$sbCreator			= $( '#zeen-engine-create-sb' );
			this.$sbCreatorTitle    = $( '#zeen-engine-create-sb-title' );
			this.$slider			= $( '.zeen-engine-slider' );
			this.$widgetMulti		= $( '#widgets-right .tipi-multi-on' );
			this.$dates				= $( '.zeen-engine-date-field' ).find( 'input' );
			this.$dateTimes			= $( '.zeen-engine-date-time-field' ).find( 'input' );
			this.$sliderReset		= $( '.zeen-engine-slider-wrap .zeen-engine-reset' );
			this.$sectionShower		= $( '.zeen-engine-metabox-wrap .zeen-engine-trig' );
			this.$required			= $( '.zeen-engine-req' );
			this.$dragDrop			= $( '.zeen-engine-drag-drop' );
			this.modal 				= false;
			this.galleryModal		= false;
			this.galleryNativeModal = false;
		},
		dates: function() {
			if ( this.$dates.length > 0 ) {
				this.$dates.datepicker({
					beforeShow: function(input, inst) {
					   $('#ui-datepicker-div').addClass('zeen-engine-date-box-wrap');
					   },
					showOtherMonths: true,
					closeText: zeenEngineJS.i18n.close,
					currentText: zeenEngineJS.i18n.now,
					prevText: '<span class="dashicons dashicons-arrow-left-alt2"></span>',
					nextText: '<span class="dashicons dashicons-arrow-right-alt2"></span>'
				  });
			}
			if ( this.$dateTimes.length > 0 ) {
				this.$dateTimes.datetimepicker({
					beforeShow: function(input, inst) {
					   $('#ui-datepicker-div').addClass('zeen-engine-date-box-wrap');
					   },
					showOtherMonths: true,
					closeText: zeenEngineJS.i18n.close,
					currentText: zeenEngineJS.i18n.now,
					prevText: '<span class="dashicons dashicons-arrow-left-alt2"></span>',
					nextText: '<span class="dashicons dashicons-arrow-right-alt2"></span>'
				  });
			}
		},
		bind: function() {
			this.$sliderReset.on( 'click', this.sliderReset );
			this.$sectionShower.on( 'click', this.sectionShower );
			this.$sbCreator.on( 'click', this.sbCreator );
			this.$body.on( 'click', '.zeen-engine-gallery', this.galleryUpload );
			this.$body.on( 'click', '.zeen-engine-upload', this.upload );
			this.$body.on( 'click', '.tipi-del-tag', this.tagRemove );
			this.$body.on( 'click', '.zeen-engine-remove', this.uploadRemove );
			this.$body.on( 'click', '.zeen-engine-remove-gallery', this.parentRemove );
			this.$body.on( 'click', '.zeen-engine-sb-delete', this.sbRemove );
			this.$body.on( 'change', '.zeen-engine-required', this.requiredCheck );
			this.$doc.on( 'widget-added widget-updated', this.widgetChange );
			this.$doc.on( 'widget-added widget-updated', this.tagSuggest.bind(this ) );
			this.$body.on( 'click', '.zeen-engine-drag-x', this.dragRemove );
			this.$body.on( 'click', '.zeen-engine-drag-add', this.dragAdd );
			this.$body.on( 'click', '.button__zeen__migration', this.migration );

		},
		sbCreator: function( e ) {
			e.preventDefault();
			var $sbWrap = $('.zeen-engine-sb-wrap');
			$.ajax({
                type : "POST",
                data : {
                	action: 'zeen_engine_sb_add',
                	nonce: zeenEngineJS.nonce,
                	title: zeenEngineAdmin.$sbCreatorTitle.val(),
                },
                url: zeenEngineJS.ajax,
                dataType: "json",
                success : function( data ) {
					var entry = data.data;
					$sbWrap.append('<div class="zeen-engine-sb"><div class="sb-type">' + zeenEngineJS.i18n.customSidebars + '</div><div class="sb-title">' + entry.label + ' (' + entry.uid + ')</div><a href="#" class="zeen-engine-sb-delete" data-id="' + entry.uid + '" data-type="cids"><i class="ze-i-x"></i></a></div>')
                },
                error : function( jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR, textStatus,errorThrown);
                }
            });
		},
		sbRemove: function( e ) {
			e.preventDefault();
			var check = confirm( zeenEngineJS.i18n.titleSbRemoveConfirm );
	        if ( ! check ) {
	        	return;
	        }
			var remover = $( this );
			$.ajax({
                type : "POST",
                data : {
                	action: 'zeen_engine_sb_remove',
                	nonce: zeenEngineJS.nonce,
                	id: remover.data('id'),
                	type: remover.data('type')
                },
                url: zeenEngineJS.ajax,
                dataType: "json",
                success : function( data ) {
                	remover.closest('.zeen-engine-sb').fadeOut();
                },
                error : function( jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR, textStatus,errorThrown);
                }
            });
		},
		dragRemove: function( e ) {
			e.preventDefault();
			$( this ).parent().remove();
		},
		dragDrop: function() {
			this.$dragDrop.sortable({
			  	placeholder: "ui-state-highlight",
				classes: {
					"ui-sortable": "zeen-engine-control-only"
				},
				start: function( e, ui ){
			        ui.placeholder.height( ui.item.height() );
			    }
			});
			this.$dragDrop.disableSelection();
		},
		migration: function( e ) {
			e.preventDefault();
			var button = $( this ),
			type = $( '#theme__selection' ).find(":selected").val();
			$.ajax({
                type : "POST",
                data : { action: 'zeen_engine_migration', nonce: zeenEngineJS.nonce, type: type },
                url: zeenEngineJS.ajax,
                dataType: "json",
                beforeSend : function() {
                	button.closest( '.tipi-content-area' ).addClass('migrate--running');
                },
                success : function( data ) {
                	button.closest( '.tipi-content-area' ).removeClass('migrate--running');
                },
                error : function( jqXHR, textStatus, errorThrown) {
                    console.log(jqXHR, textStatus,errorThrown);
                }
            });
		},
		dragAdd: function( e ) {
			e.preventDefault();
			var $adder = $( this ),
				$addParent = $adder.parent(),
				$dragDummy = $addParent.find( '> .zeen-engine-drag-el-dummy' ),
				$dragWarp = $addParent.find( '> .zeen-engine-drag-drop' );

			$dragWarp.data( 'count', $dragWarp.data('count') + 1 );

			var $theClone = $dragDummy.find('> div').clone();

			var $theCloneData = $theClone.find( '.zeen-engine-data' );
			$theCloneData.each( function() {
			    var el = $( this );
			    el.removeClass('zeen-engine-data');
			    var elName = el.data('name') + '[' + $dragWarp.data('count') + ']' + '[' + el.data('choice') + ']';
			    el.attr('name', elName );
			});

			$theClone.appendTo( $dragWarp );
			$theClone.find('input:first').focus();
		},
		requiredCheck: function ( e, el ) {

			var $reqCheckThis =  typeof el === 'undefined' ? $( this ) : $(el);
			$reqCheckThis.each( function() {
				var $reqCheckEachThis = $( this );
				var $reqCheck = $reqCheckEachThis.closest('.zeen-engine-control');
				var $reqCheckControl = $reqCheck.data('control');

				switch( $reqCheckControl ) {
				    case 'on-off':

				    	$reqCheckEachThis.data('dependees').forEach( function(dependee) {
						    if ( ( $reqCheckEachThis.is(":checked") === true ) && ( dependee.val === 'on' ) ) {
								zeenEngineAdmin.showIt( $('#' + dependee.id ), e );
							} else if ( ( $reqCheckEachThis.is(":checked") === false ) && ( dependee.val === 'on' ) ) {
								zeenEngineAdmin.hideIt( $('#' + dependee.id ), e );
							}

							if ( ( $reqCheckEachThis.is(":checked") === false ) && ( dependee.val === 'off' ) ) {
								zeenEngineAdmin.showIt( $('#' + dependee.id ), e );
							} else if ( ( $reqCheckEachThis.is(":checked") === true ) && ( dependee.val === 'off' ) ) {
								zeenEngineAdmin.hideIt( $('#' + dependee.id ), e );
							}
						});

				        break;
				    case 'radio-images':

				    	$reqCheckEachThis.data('dependees').forEach( function(dependee) {

				    		if ( dependee.val.length > 1 ) {
				    			for( var i = 0, len = dependee.val.length; i < len; i++){
									dependee.val[i] = dependee.val[i].toString();
								}

					    		if ( $reqCheckEachThis.is(':checked') === true && $.inArray(  $reqCheckEachThis.val(), dependee.val ) != -1 ) {
					    			zeenEngineAdmin.showIt( $('#' + dependee.id ), e );
					    		} else {
					    			if ( typeof el === 'undefined' ) {
					    				zeenEngineAdmin.hideIt( $('#' + dependee.id ), e );
					    			}
								}

				    		} else {

				    			if ( ( $reqCheckEachThis.is(':checked') === true ) && ( $reqCheckEachThis.val() == dependee.val ) ) {
					    			zeenEngineAdmin.showIt( $('#' + dependee.id ), e );
					    		} else {
					    			if ( typeof el === 'undefined' ) {
					    				zeenEngineAdmin.hideIt( $('#' + dependee.id ), e );
					    			}
								}
				    		}
						});

				        break;
				    case 'select':

				    	$reqCheckEachThis.data('dependees').forEach( function(dependee) {

				    		if ( ( $reqCheckEachThis.val() ) == dependee.val ) {
				    			zeenEngineAdmin.showIt( $('#' + dependee.id ), e );
				    		} else {
				    			if ( typeof el === 'undefined' ) {
				    				zeenEngineAdmin.hideIt( $('#' + dependee.id ), e );
				    			}
							}

						});

				        break;
				    default:
				}
			});
		},
		showIt: function ( el, e ) {
			if ( typeof e !== 'undefined' ) {
				el.slideDown(100);
				return;
			}
			el.show();
		},
		hideIt: function ( el, e ) {
			if ( typeof e !== 'undefined' ) {
				el.slideUp(100);
				return;
			}
			el.hide();
		},
		required: function ( e ) {
			this.$required.each( function() {
				var $reqThis = $( this );
				var $reqId = $reqThis.attr('id');
				var $reqVal = $reqThis.data('req-val');
				var $req = $reqThis.data('req');

				var $req2 = $reqThis.data('req-2');

				if ( $req2 !== '' ) {
					var $reqVal2 = $reqThis.data('req-val-2');
					var $reqInputVal2 = $( '#' + $req2 ).find('.zeen-engine-input-val');
					$reqInputVal2.addClass('zeen-engine-required');


					if ( typeof $reqInputVal2.data('dependees') === 'undefined' ) {
						$reqInputVal2.data('dependees', [ { id: $reqId, val: $reqVal2 } ] );
					} else {
						var $reqArray = $reqInputVal2.data('dependees');
						$reqArray.push( { id: $reqId, val: $reqVal2 } );
						$reqInputVal2.data('dependees', $reqArray );
					}

				}

				var $reqInputVal = $( '#' + $req ).find('.zeen-engine-input-val');
				$reqInputVal.addClass('zeen-engine-required');


				if ( typeof $reqInputVal.data('dependees') === 'undefined' ) {
					$reqInputVal.data('dependees', [ { id: $reqId, val: $reqVal } ] );
				} else {
					var $reqArray = $reqInputVal.data('dependees');
					$reqArray.push( { id: $reqId, val: $reqVal } );
					$reqInputVal.data('dependees', $reqArray );
				}

			});
			zeenEngineAdmin.requiredCheck(e, '.zeen-engine-required');
		},
		uploadRemove: function( e ) {
			e.preventDefault();

			var uploadThis = $( this );
			uploadThis.closest('.zeen-engine-meta-control').find('.zeen-engine-img-input').val('');
			var zeenEngineVisSwitch 	= uploadThis.closest('.zeen-engine-meta-control').find('.zeen-engine-vis-switch');
			if ( zeenEngineVisSwitch.length ) {
				zeenEngineVisSwitch.addClass('zeen-engine-hide');
			}
			zeenEngineAdmin.parentRemove(e, uploadThis );
		},
		parentRemove: function( e, el ) {
			e.preventDefault();

			if ( typeof el !== 'undefined' ) {
				el.parent().remove();
			} else {
				$( this ).parent().remove();
			}
		},
		upload: function( e ) {
		 	e.preventDefault();
		 	var zeenEngineDest 		= $( this ).closest( '#' + $( this ).data( 'dest' ) ),
		 		zeenEngineOutput 	= $( this ).data( 'output' ),
		 		zeenEngineFileType	= $( this ).data( 'file-type' ),
		 		zeenEngineVisSwitch 	= zeenEngineDest.find('.zeen-engine-vis-switch');

			zeenEngineAdmin.modal = wp.media({
				title: zeenEngineJS.i18n.titleModal,
				button: {
					text: zeenEngineJS.i18n.titleButton,
				},
				multiple: false
			});

		    zeenEngineAdmin.modal.on( 'select', function() {

	        	var zeenEngineImg = zeenEngineAdmin.modal.state().get('selection').first().toJSON();
	        	if ( zeenEngineFileType === 'img' ) {
					var	zeenEngineImgUrl = typeof zeenEngineImg.sizes.thumbnail !== 'undefined' ? zeenEngineImg.sizes.thumbnail.url : zeenEngineImg.url;
				}

				var zeenEngineSrcId = zeenEngineOutput === 'id' ? zeenEngineImg.id : zeenEngineImg.url;
				zeenEngineDest.find('.zeen-engine-img-input').val( zeenEngineSrcId ).trigger('change');


				zeenEngineDest.find('.zeen-engine-img').remove();
		        zeenEngineDest.find('.zeen-engine-control-only').append( '<span class="zeen-engine-img"><a href="#" class="zeen-engine-remove zeen-engine--x"></a></span>' );
				if ( zeenEngineFileType === 'img' ) {
					zeenEngineDest.find('.zeen-engine-control-only .zeen-engine-img').append('<img src="' + zeenEngineImgUrl + '" alt="">');
		        } else {
		        	zeenEngineDest.find('.zeen-engine-control-only .zeen-engine-img').append('<img class="media--not-img" src="' + zeenEngineJS.i18n.mdIcon1 + '" srcset="' + zeenEngineJS.i18n.mdIcon1 + ' 2x" alt="">');
		        }

	            if ( zeenEngineVisSwitch.length ) {
					zeenEngineVisSwitch.removeClass('zeen-engine-hide');
				}

			}).open();
		},
		galleryGetter: function( currGal ) {
			// Inspired in parts by Option Tree - thanks Derek.
			var output,	inputs = currGal.closest('.zeen-engine-control-only').find('.zeen-engine-input-val'), ids = '';
			inputs.each( function() {
				ids += $(this).val() + ',';
			});
			if ( ids.length > 0 ) {
				ids = ids.slice( 0, -1 );
			}
			var sc = wp.shortcode.next( 'gallery', ( '[gallery ids="' + ids + '"]' ) );

			if ( sc.shortcode.get('ids') === 'undefined' ) {
				sc.shortcode.set( 'ids', ids )
			}
			var attachments = wp.media.gallery.attachments( sc.shortcode );
			output = new wp.media.model.Selection( attachments.models, {
		        props:    attachments.props.toJSON()
		      , multiple: true
		      })
		    output.gallery = attachments.gallery;
			output.more().done( function () {
				output.props.set({ query: false })
				output.unmirror()
				output.props.unset('orderby')
			});

			return output;
		},
		galleryUpload: function( e ) {
		 	e.preventDefault();
		 	var currGal = $( this );
			zeenEngineAdmin.galleryNativeModal = wp.media({
				title: zeenEngineJS.i18n.titleGalleryModal,
				button: {
					text: zeenEngineJS.i18n.titleButton,
				},
				multiple: true,
				id: 'zeen-engine-gallery',
				editing: true,
				frame: 'post',
				state: 'gallery-edit',
				selection:  zeenEngineAdmin.galleryGetter( currGal )
			});

		    zeenEngineAdmin.galleryNativeModal.on( 'update insert', function(){
	        	var models = zeenEngineAdmin.galleryNativeModal.states.get("gallery-edit"),
	        		library = models.get('library').models;
				$( '#' + currGal.data( 'dest' ) ).find('.zeen-engine-gallery-images-wrap').html('');
				for ( var counter = 0; counter < library.length; counter++ ) {
					var obj = library[counter].toJSON();
					var zeenEngineGalleryImgUrl = typeof obj.sizes.thumbnail !== 'undefined' ? obj.sizes.thumbnail.url : obj.url;
		            $( '#' + currGal.data( 'dest' ) ).find('.zeen-engine-gallery-images-wrap').append( '<span data-id="' + obj.id + '" class="zeen-engine-img"><a href="#" class="zeen-engine-remove-gallery zeen-engine--x"></a><img src="' + zeenEngineGalleryImgUrl + '" alt=""><input type="hidden" class="zeen-engine-input-val" value="' + obj.id + '" name="' + currGal.data( 'name' ) +'[]"></span>' );
		        }

		        counter = 0;

			}).open();
		},
		sectionShower: function( e ) {
			e.preventDefault();
			var zeenEngineTrig = $('#' + $( this ).data('section') );
			zeenEngineTrig.siblings().addClass('zeen-engine-hide');
			zeenEngineTrig.removeClass('zeen-engine-hide');
			$( this ).siblings().removeClass('zeen-engine-active');
			$( this ).addClass('zeen-engine-active');
		},
		colorPicker: function() {
			this.$colorPicker.wpColorPicker();
			this.$colorPickerA.alphaColorPicker();
		},
		slider: function() {
			this.$slider.each( function() {
				var $this = $( this );
		        $this.slider({
			        min: $this.data('min'),
			        max: $this.data('max'),
			        step: $this.data('step'),
			        range: 'min',
			        value: $this.data('value'),
			        slide: function( event, ui ) {
			        	$this.next().val( ui.value );
			        	$this.next().next().find('.zeen-engine-val').html( ui.value );
			       }
			    });
			});
		},
		tagRemove: function( e ) {

			var removeTagData = $( this ).data();
			var revemoTagInput = $( this ).closest('.tipi-tags-suggest-wrap').find( '.tipi-tag-suggest' ).val();

			revemoTagInput = $.grep(revemoTagInput, function(value) {
			  return value != removeTagData['id'];
			});
			$( this ).closest('span').remove();
		},
		tagSuggest: function( e ) {
			$('.tipi-tag-suggest').suggest( zeenEngineJS.ajaxURL + '?action=ajax-tag-search&tax=post_tag', { delay: 350, minchars: 2, multiple: true, multipleSep: ',' } );
		},
		sliderReset: function() {
	        var slider = $( this ).closest( '.zeen-engine-control' ).find( '.zeen-engine-slider' );
	        var defaultVal = slider.data( 'default' );
	        slider.slider({
	            value: defaultVal,
	        });
	        slider.next().val( defaultVal );
	        slider.next().next().find('.zeen-engine-val').html( defaultVal );
		},
		widgetChange: function( e, widget ) {

			if ( typeof widget !== 'undefined' ) {
				this.$widgetMulti = widget.find('.tipi-multi-on');
			}

			if ( ! this.$widgetMulti.hasClass('tipi-sorted') ) {
		        this.$widgetMulti.addClass('tipi-sorted').searchableOptionList();
		    }
		    zeenEngineAdmin.$required = $( '.zeen-engine-req' );

			zeenEngineAdmin.required();
		},
	};

	zeenEngineAdmin.init();

} )( jQuery );