<?php
/**
 * Metaboxes
 *
 * @package Zeen_Engine
 * @copyright Copyright Codetipi
 * @since 1.0.0
 */

/**
 * Taxonomy Class init
 *
 * @since  1.0.0
 */
function zeen_engine_tax() {
	$taxonomies = get_taxonomies(
		array(
			'public' => true,
		),
		'names'
	);

	unset( $taxonomies['product_shipping_class'] );
	unset( $taxonomies['topic-tag'] );
	$widget_areas = array();
	$layouts      = array();
	$grids        = array();
	if ( function_exists( 'zeen_all_sidebars' ) ) {
		$widget_areas = zeen_all_sidebars(
			array(
				1 => esc_html__( 'Inherit', 'zeen-engine' ),
			)
		);
	}
	if ( function_exists( 'zeen_customizer_layouts' ) ) {
		$layouts = zeen_customizer_layouts( '', array( 99 => array( 'url' => 'default.png' ) ) );
	}
	if ( function_exists( 'zeen_customizer_grid_values' ) ) {
		$grids = zeen_customizer_grid_values();
	}
	$zeen_engine_tax = array(
		'prefix'   => 'zeen',
		'taxonomy' => $taxonomies,
		'src_uri'  => get_parent_theme_file_uri( 'assets/admin/img/' ),
		'args'     => array(
			array(
				'control' => 'builder',
				'id'      => 'builder',
				'title'   => 'Tipi Builder',
				'default' => '',
			),
			array(
				'control'     => 'color',
				'id'          => 'color',
				'title'       => 'Zeen: ' . esc_html__( 'Accent Color', 'zeen-engine' ),
				'description' => esc_html__( 'Set the main color for this taxonomy', 'zeen-engine' ),
				'default'     => '',
			),
			array(
				'control' => 'image',
				'id'      => 'logo_main',
				'choices' => array(
					'type' => 'id',
				),
				'title'   => 'Zeen: ' . esc_html__( 'Main Logo Override', 'zeen-engine' ),
				'default' => '',
			),
			array(
				'control' => 'image',
				'id'      => 'logo_main_retina',
				'choices' => array(
					'type' => 'id',
				),
				'title'   => 'Zeen: ' . esc_html__( 'Retina Main Logo Override', 'zeen-engine' ),
				'default' => '',
			),
			array(
				'control'     => 'background',
				'id'          => 'background',
				'title'       => 'Zeen: ' . esc_html__( 'Background', 'zeen-engine' ),
				'description' => esc_html__( 'Optional background image or color for this taxonomy. This will take precedence over any global background options that are set.', 'zeen-engine' ),
				'default'     => '',
			),
			array(
				'control' => 'radio-images',
				'id'      => 'layout',
				'title'   => 'Zeen: ' . esc_html__( 'Layout', 'zeen-engine' ),
				'default' => 99,
				'choices' => $layouts,
			),
			array(
				'control'  => 'select',
				'id'       => 'image_shape',
				'title'    => 'Zeen: ' . esc_html__( 'Image Shape', 'zeen-engine' ),
				'default'  => 99,
				'choices'  => array(
					99 => esc_html__( 'Use Theme Options Setting', 'zeen-engine' ),
					1 => esc_html__( 'Default', 'zeen-engine' ),
					2 => esc_html__( 'Square', 'zeen-engine' ),
					3 => esc_html__( 'Portrait', 'zeen-engine' ),
				),
				'required' => array(
					'id'    => 'layout',
					'value' => array( '1', '21', '26', '27', '28', '61', '71', '72', '79' ),
				),
			),
			array(
				'control'     => 'radio-images',
				'id'          => 'sidebar',
				'title'       => 'Zeen: ' . esc_html__( 'Sidebar Location', 'zeen-engine' ),
				'description' => '<span class="zeen-info">' . esc_html__( 'Info', 'zeen-engine' ) . '</span>' . esc_html__( 'Use Default = The setting Appearance > Customizer > Category/Tag/Etc > Category > Default Sidebar Layout.', 'zeen-engine' ),
				'default'     => 99,
				'choices'     => array(
					99 => array(
						'url' => 'default.png',
					),
					1  => array(
						'url' => 'sidebar-1.png',
					),
					2  => array(
						'url' => 'sidebar-2.png',
					),
				),
				'required'    => array(
					'id'    => 'layout',
					'value' => array( '99', '1', '2', '5', '21', '22', '24', '41', '42', '44' ),
				),
			),
			array(
				'control'  => 'on-off',
				'id'       => 'fs',
				'default'  => 'on',
				'title'    => 'Zeen: ' . esc_html__( 'Screen Edge To Edge layout', 'zeen-engine' ),
				'required' => array(
					'id'    => 'layout',
					'value' => $grids,
				),
			),
			array(
				'control'     => 'select',
				'id'          => 'sidebar-tids',
				'title'       => 'Zeen: ' . esc_html__( 'Sidebar to use', 'zeen-engine' ),
				'description' => esc_html__( 'Inherit = Default Sidebar in Appearance > Widgets', 'zeen-engine' ),
				'default'     => 99,
				'choices'     => $widget_areas,
				'global'      => 2,
				'required'    => array(
					'id'    => 'layout',
					'value' => array( '99', '1', '2', '5', '21', '22', '24', '41', '42', '44' ),
				),
			),
			array(
				'control' => 'select',
				'id'      => 'pagination',
				'title'   => 'Zeen: ' . esc_html__( 'Pagination', 'zeen-engine' ),
				'default' => 99,
				'choices' => array(
					99 => esc_html__( 'Use Customizer Default', 'zeen-engine' ),
					1  => esc_html__( 'Numbered Pages', 'zeen-engine' ),
					2  => esc_html__( 'Load Button', 'zeen-engine' ),
					3  => esc_html__( 'Infinite Scroll', 'zeen-engine' ),
					4  => esc_html__( 'Load Button Once Then Infinite', 'zeen-engine' ),
				),
			),
		),
	);

	new Zeen_Engine_Tax( $zeen_engine_tax );
	if ( ! function_exists( 'wc_get_attribute_taxonomies' ) ) {
		return;
	}
	$att_taxes       = wc_get_attribute_taxonomies();
	$att_taxes_color = array();
	$att_taxes_image = array();
	foreach ( $att_taxes as $key ) {
		if ( $key->attribute_type == 'zeen_color' ) {
			$att_taxes_color[] = 'pa_' . $key->attribute_name;
		}
		if ( $key->attribute_type == 'zeen_image' ) {
			$att_taxes_image[] = 'pa_' . $key->attribute_name;
		}
	}
	$zeen_engine_att = array(
		'prefix'   => 'zeen',
		'taxonomy' => $att_taxes_color,
		'src_uri'  => get_parent_theme_file_uri( 'assets/admin/img/' ),
		'args'     => array(
			array(
				'control' => 'color',
				'id'      => 'color',
				'title'   => 'Zeen: ' . esc_html__( 'Color', 'zeen-engine' ),
				'default' => '',
			),
		),
	);
	if ( ! empty( $att_taxes_color ) ) {
		new Zeen_Engine_Tax( $zeen_engine_att );
	}
	$zeen_engine_att = array(
		'prefix'   => 'zeen',
		'taxonomy' => $att_taxes_image,
		'src_uri'  => get_parent_theme_file_uri( 'assets/admin/img/' ),
		'args'     => array(
			array(
				'control' => 'image',
				'id'      => 'image',
				'choices' => array(
					'type' => 'id',
				),
				'title'   => 'Zeen: ' . esc_html__( 'Image', 'zeen-engine' ),
				'default' => '',
			),
		),
	);
	if ( ! empty( $att_taxes_image ) ) {
		new Zeen_Engine_Tax( $zeen_engine_att );
	}
}
add_action( 'admin_init', 'zeen_engine_tax' );
