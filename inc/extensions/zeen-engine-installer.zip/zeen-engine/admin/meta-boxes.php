<?php
/**
 * Metaboxes
 *
 * @package     Zeen_Engine
 * @copyright   Copyright Codetipi
 * @since       1.0.0
 */
/**
 * Metabox Class init
 *
 * @since  1.0.0
 */
function zeen_engine__metabox() {

	$post_types = get_post_types(
		array(
			'public'   => true,
			'_builtin' => false,
		)
	);

	$post_types[]       = 'post';
	$post_types_formats = $post_types;
	unset( $post_types['product'] );
	$gutenberg_video = '';
	$gutenberg_audio = '';
	$gutenberg       = '';
	if ( function_exists( 'register_block_type' ) ) {
		$gutenberg       = true;
		$gutenberg_video = '(Video)';
		$gutenberg_audio = '(Audio)';
	}

	$zeen_engine__metabox = array(
		'post_type' => $post_types,
		'prefix'    => 'zeen',
		'id'        => 'zeen-options',
		'src_uri'   => get_parent_theme_file_uri( 'assets/admin/img/' ),
		'title'     => get_theme_mod( 'white_label_onoff' ) == 1 ? get_theme_mod( 'white_label_name', 'Zeen' ) . ' ' . esc_html__( 'Options', 'zeen-engine' ) : esc_html__( 'Zeen Options', 'zeen-engine' ),
		'args'      => array(),
	);
	$widget_areas        = array();
	$heros               = array();
	$layouts             = array();
	$singular_h          = array();
	$md_v                = array();
	$md_g                = array();
	$layouts_p           = array();
	$parallax_effect     = array( 1, 2, 3, 5, 11, 12, 13, 14, 15, 16, 17, 18, 21, 22, 23, 24, 25, 26, 27, 41, 42, 19, 43 );
	$cover_height        = array( 21, 22, 23, 24, 25, 26, 27 );
	$medium_height       = array( 11, 12, 13, 14, 15, 16, 17 );
	$hero_design         = array( 3, 16, 17, 21, 25, 26, 27 );
	$sticky_details      = array( 2, 12, 32 );
	$splitter_list       = array();
	$product_tabs        = function_exists( 'zeen_customizer_product_tabs_designs' ) ? zeen_customizer_product_tabs_designs( false, array( 99 => array( 'url' => 'default.png' ) ) ) : array();
	$product_width       = function_exists( 'zeen_customizer_product_tabs_designs' ) ? zeen_customizer_product_layout_width( false, array( 99 => array( 'url' => 'default.png' ) ) ) : array();
	$product_hero        = function_exists( 'zeen_customizer_product_designs' ) ? zeen_customizer_product_designs( false, array( 99 => array( 'url' => 'default.png' ) ) ) : array();
	if ( function_exists( 'zeen_all_sidebars' ) ) {
		$widget_areas  = zeen_all_sidebars( array( 1 => esc_html__( 'Inherit', 'zeen-engine' ) ) );
		$heros         = zeen_customizer_hero_designs( false, array( 99 => array( 'url' => 'default.png' ) ) );
		$layouts       = zeen_customizer_article_layout_designs( false, array( 99 => array( 'url' => 'default.png' ) ) );
		$singular_h    = zeen_customizer_singular_headers( false, array( 99 => array( 'url' => 'default.png' ) ) );
		$md_v          = zeen_customizer_md_v( false, array( 99 => array( 'url' => 'default.png' ) ) );
		$md_g          = zeen_customizer_md_g( false, array( 99 => array( 'url' => 'default.png' ) ) );
		$layouts_p     = zeen_customizer_article_layout_designs( false, array( 99 => array( 'url' => 'default.png' ) ), true );
		$shapes        = zeen_shape_list();
		$splitter_list = array(
			99  => array( 'url' => 'default.png' ),
			100 => array( 'url' => 'off.png' ),
		);
		foreach ( $shapes as $shape => $shape_val ) {
			$splitter_list[ $shape ] = $shape_val;
		}
	}

	$zeen_engine__metabox['args']     = array(
		array(
			'control' => 'section',
			'id'      => 'section-design',
			'choices' =>
				array(
					'count' => 1,
				),
		),
		array(
			'control'     => 'radio-images',
			'id'          => 'hero-design',
			'title'       => esc_html__( 'Hero Design', 'zeen-engine' ),
			'description' => esc_html__( 'Select the design for your featured image. The "Use Default" option uses the selection set in Theme Options > Posts > Default Hero Design.', 'zeen-engine' ),
			'default'     => 99,
			'choices'     => $heros,
		),
		array(
			'control'  => 'select',
			'id'       => 'cover-height',
			'title'    => esc_html__( 'Hero Height', 'zeen-engine' ),
			'default'  => 1,
			'choices'  => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( '100% Screen Height', 'zeen-engine' ),
				2  => esc_html__( '66% Screen Height', 'zeen-engine' ),
				3  => esc_html__( '50% Screen Height', 'zeen-engine' ),
				11 => esc_html__( 'Native Image Height (No Crop)', 'zeen-engine' ),
			),
			'required' => array(
				'id'    => 'hero-design',
				'value' => $cover_height,
			),
		),
		array(
			'control'  => 'select',
			'id'       => 'medium-height',
			'title'    => esc_html__( 'Hero Height', 'zeen-engine' ),
			'default'  => 99,
			'choices'  => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'Cropped', 'zeen-engine' ),
				2  => esc_html__( 'Uncropped', 'zeen-engine' ),
			),
			'required' => array(
				'id'    => 'hero-design',
				'value' => $medium_height,
			),
		),
		array(
			'control'  => 'select',
			'id'       => 'parallax',
			'title'    => esc_html__( 'Parallax Effect', 'zeen-engine' ),
			'default'  => 99,
			'choices'  => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
			'required' => array(
				'id'    => 'hero-design',
				'value' => $parallax_effect,
			),
		),
		array(
			'control'     => 'select',
			'id'          => 'hero-color',
			'title'       => esc_html__( 'Hero Overlay Color', 'zeen-engine' ),
			'description' => esc_html__( 'This color appears on top of the hero image. The Use Customizer Option uses the color set in Theme Options > Posts > Hero Overlay Color.', 'zeen-engine' ),
			'default'     => 99,
			'choices'     => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
			),
			'required'    => array(
				'id'    => 'hero-design',
				'value' => $hero_design,
			),
		),
		array(
			'control'  => 'color-a',
			'id'       => 'overlay',
			'title'    => esc_html__( 'Hero Overlay Custom Color', 'zeen-engine' ),
			'default'  => 'rgba(0,0,0,0.4)',
			'required' => array(
				'id'      => 'hero-color',
				'value'   => 1,
				'id_2'    => 'hero-design',
				'value_2' => $hero_design,
			),
		),
		array(
			'control'  => 'color',
			'id'       => 'overlay-text',
			'title'    => esc_html__( 'Hero Title Text Color', 'zeen-engine' ),
			'default'  => '#fff',
			'required' => array(
				'id'      => 'hero-color',
				'value'   => 1,
				'id_2'    => 'hero-design',
				'value_2' => $hero_design,
			),
		),
		array(
			'control'  => 'color',
			'id'       => 'background-color',
			'title'    => esc_html__( 'Background Transition Color', 'zeen-engine' ),
			'default'  => '#fff',
			'required' => array(
				'id'    => 'hero-design',
				'value' => 31,
			),
		),
		array(
			'control'      => 'radio-images',
			'id'           => 'splitter_bottom',
			'title'        => esc_html__( 'Bottom Divider Shape', 'zeen-engine' ),
			'default'      => 99,
			'zero_allowed' => true,
			'choices'      => $splitter_list,
		),
		array(
			'control'     => 'image',
			'id'          => 'secondary-image',
			'class'       => 'secondary-image',
			'title'       => esc_html__( 'Secondary Hero', 'zeen-engine' ),
			'description' => esc_html__( 'Show a second image on hover. This only appears outside the post page.', 'zeen-engine' ),
			'choices'     => array(
				'type' => 'id',
			),
		),
		array(
			'control'     => 'image',
			'id'          => 'hero-image-override',
			'class'       => 'hero-image-override',
			'title'       => esc_html__( 'Hero Image Override', 'zeen-engine' ),
			'description' => esc_html__( 'Show a different image as the hero of this post.', 'zeen-engine' ),
			'choices'     => array(
				'type' => 'id',
			),
		),
		array(
			'control' => 'section',
			'id'      => 'section-layout',
			'choices' =>
				array(
					'count' => 2,
				),
		),
		array(
			'control'     => 'radio-images',
			'id'          => 'article-layout',
			'title'       => esc_html__( 'Article Layout', 'zeen-engine' ),
			'description' => esc_html__( 'The Use Default option uses the selection set in Theme Options > Posts > Default Article Layout.', 'zeen-engine' ),
			'default'     => 99,
			'choices'     => $layouts,
		),
		array(
			'control'  => 'select',
			'id'       => 'article-layout-sticky-share',
			'title'    => esc_html__( 'Floating Social Share', 'zeen-engine' ),
			'default'  => 99,
			'choices'  => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
			'required' => array(
				'id'    => 'article-layout',
				'value' => $sticky_details,
			),
		),
		array(
			'control'  => 'select',
			'id'       => 'article-layout-author',
			'title'    => esc_html__( 'Show Author', 'zeen-engine' ),
			'default'  => 99,
			'choices'  => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
			'required' => array(
				'id'    => 'article-layout',
				'value' => $sticky_details,
			),
		),
		array(
			'control'     => 'drag',
			'id'          => 'share-details',
			'title'       => esc_html__( 'Sticky Details', 'zeen-engine' ),
			'description' => esc_html__( 'Add as many blocks of information you want to show in the sticky block that slides alongside the article. Can be drag and dropped too.', 'zeen-engine' ),
			'default'     => '',
			'choices'     => array(
				1 => array(
					'name'  => 'title',
					'title' => esc_attr__( 'Title', 'zeen-engine' ),
					'type'  => 'text',
				),
				2 => array(
					'name'  => 'content',
					'title' => esc_attr__( 'Content', 'zeen-engine' ),
					'type'  => 'text',
				),
			),
			'required'    => array(
				'id'    => 'article-layout',
				'value' => $sticky_details,
			),
		),
		array(
			'control' => 'on-off',
			'id'      => 'article-layout-skin',
			'title'   => esc_html__( 'Dark Article Background', 'zeen-engine' ),
			'default' => 'off',
		),
		array(
			'control'  => 'gallery',
			'id'       => 'article-layout-gallery',
			'title'    => esc_html__( 'Side Gallery', 'zeen-engine' ),
			'required' => array(
				'id'    => 'article-layout',
				'value' => array( 58, 59 ),
			),
		),
		array(
			'control'     => 'select',
			'id'          => 'sidebar-pids',
			'title'       => esc_html__( 'Sidebar to use', 'zeen-engine' ),
			'description' => esc_html__( 'Inherit = uses the category (if exists) or global sidebar. Unique sidebar = Adds new sidebar in Appearance > Widgets with post title', 'zeen-engine' ),
			'default'     => 1,
			'choices'     => $widget_areas,
			'global'      => 2,
			'required'    => array(
				'id'    => 'article-layout',
				'value' => array( 1, 2, 11, 12 ),
			),
		),
		array(
			'control' => 'section',
			'id'      => 'section-header',
			'choices' =>
				array(
					'count' => 3,
				),
		),
		array(
			'control'     => 'radio-images',
			'id'          => 'singular-header',
			'title'       => esc_html__( 'Special Header Design', 'zeen-engine' ),
			'description' => esc_html__( 'Set a special header for this post. If you choose "Default" then whatever option you set in the Customizer > Posts option will load. If you choose "x" then the main global header will load.', 'zeen-engine' ),
			'default'     => 99,
			'choices'     => $singular_h,
		),
		array(
			'control' => 'section',
			'id'      => 'section-extra',
			'choices' =>
				array(
					'count' => 4,
				),
		),
		array(
			'control' => 'select',
			'id'      => 'user-box',
			'title'   => esc_html__( 'Show About The Author', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'related-posts-hero',
			'title'   => esc_html__( 'Show Small Related Posts Above Hero', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'related-posts',
			'title'   => esc_html__( 'Show Related Posts', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'next-previous',
			'title'   => esc_html__( 'Show Next + Previous Posts', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'inline-post',
			'title'   => esc_html__( 'Show Inline Post Block', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'last-updated',
			'title'   => esc_html__( 'Show Last Updated Date', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'share-block-below-title',
			'title'   => esc_html__( 'Show Share Block Below Title', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'share-block-before',
			'title'   => esc_html__( 'Show Share Block Start Of Article', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'share-block-end',
			'title'   => esc_html__( 'Show Share Block End Of Article', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'dropcap',
			'title'   => esc_html__( 'Show Dropcap', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				1  => esc_html__( 'On', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'breadcrumbs',
			'title'   => esc_html__( 'Show Breadcrumbs', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'next-post-auto-load',
			'title'   => esc_html__( 'Next Post Auto Load', 'zeen-engine' ),
			'default' => 99,
			'choices' => array(
				99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
				2  => esc_html__( 'Off', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'select',
			'id'      => 'voice-search',
			'title'   => esc_html__( 'Voice Search Ready', 'zeen-engine' ),
			'default' => 2,
			'choices' => array(
				2 => esc_html__( 'Inactive', 'zeen-engine' ),
				1 => esc_html__( 'Ready', 'zeen-engine' ),
			),
		),
		array(
			'control' => 'section',
			'id'      => 'section-spon',
			'choices' =>
				array(
					'count' => 5,
				),
		),
		array(
			'control'        => 'on-off',
			'id'             => 'spon',
			'global'         => 'on',
			'global_removal' => 'on',
			'title'          => esc_html__( 'Sponsored Post', 'zeen-engine' ),
			'default'        => 'off',
		),
		array(
			'control'  => 'text',
			'id'       => 'spon-name',
			'class'    => 'spon-name',
			'title'    => esc_html__( 'Sponsor Name', 'zeen-engine' ),
			'required' => array(
				'id'    => 'spon',
				'value' => 'on',
			),
		),
		array(
			'control'  => 'text',
			'id'       => 'spon-link',
			'class'    => 'spon-link',
			'title'    => esc_html__( 'Sponsor Link', 'zeen-engine' ),
			'required' => array(
				'id'    => 'spon',
				'value' => 'on',
			),
		),
		array(
			'control'  => 'image',
			'id'       => 'spon-img',
			'class'    => 'spon-img',
			'title'    => esc_html__( 'Sponsor Image', 'zeen-engine' ),
			'required' => array(
				'id'    => 'spon',
				'value' => 'on',
			),
		),
		array(
			'control'  => 'image',
			'id'       => 'spon-img-retina',
			'class'    => 'spon-img-retina',
			'title'    => esc_html__( 'Sponsor Image Retina Version', 'zeen-engine' ),
			'required' => array(
				'id'    => 'spon',
				'value' => 'on',
			),
		),
		array(
			'control' => 'section',
			'id'      => 'section-list',
			'choices' =>
				array(
					'count' => 6,
				),
		),
		array(
			'control'        => 'on-off',
			'id'             => 'list',
			'global'         => 'on',
			'global_removal' => 'on',
			'title'          => esc_html__( 'Listicle', 'zeen-engine' ),
			'default'        => 'off',
		),
		array(
			'control'  => 'on-off',
			'id'       => 'countdown',
			'title'    => esc_html__( 'Show Countdown', 'zeen-engine' ),
			'default'  => 'off',
			'required' => array(
				'id'    => 'list',
				'value' => 'on',
			),
		),
		array(
			'control'  => 'select',
			'id'       => 'countdown-order',
			'title'    => esc_html__( 'Countdown Style', 'zeen-engine' ),
			'default'  => 1,
			'choices'  => array(
				1 => '3, 2, 1',
				2 => '1, 2, 3',
			),
			'required' => array(
				'id'      => 'list',
				'value'   => 'on',
				'id_2'    => 'countdown',
				'value_2' => 'on',
			),
		),
		array(
			'control'  => 'select',
			'id'       => 'list-design',
			'title'    => esc_html__( 'List Design', 'zeen-engine' ),
			'default'  => 1,
			'choices'  => array(
				1 => esc_html__( 'Slider Navigation', 'zeen-engine' ),
				2 => esc_html__( 'Standard Listicle', 'zeen-engine' ),
			),
			'required' => array(
				'id'    => 'list',
				'value' => 'on',
			),
		),
		array(
			'control'  => 'select',
			'id'       => 'list-separator',
			'title'    => esc_html__( 'Separating Element', 'zeen-engine' ),
			'default'  => 'h3',
			'choices'  => array(
				'h2' => 'H2',
				'h3' => 'H3',
				'h4' => 'H4',
				'h5' => 'H5',
			),
			'required' => array(
				'id'    => 'list',
				'value' => 'on',
			),
		),
		array(
			'control' => 'section',
			'id'      => 'section-misc',
			'choices' =>
				array(
					'count' => 7,
				),
		),
		array(
			'control' => 'drag',
			'id'      => 'source-block',
			'title'   => esc_html__( 'Source', 'zeen-engine' ),
			'default' => '',
			'choices' => array(
				1 => array(
					'name'  => 'title',
					'title' => esc_attr__( 'Source', 'zeen-engine' ),
					'type'  => 'text',
				),
				2 => array(
					'name'  => 'url',
					'title' => esc_attr__( 'URL', 'zeen-engine' ),
					'type'  => 'text',
				),
			),
		),
		array(
			'control' => 'drag',
			'id'      => 'via-block',
			'title'   => esc_html__( 'Via', 'zeen-engine' ),
			'default' => '',
			'choices' => array(
				1 => array(
					'name'  => 'title',
					'title' => esc_attr__( 'Via', 'zeen-engine' ),
					'type'  => 'text',
				),
				2 => array(
					'name'  => 'url',
					'title' => esc_attr__( 'URL', 'zeen-engine' ),
					'type'  => 'text',
				),
			),
		),
	);
	$zeen_engine__metabox['sections'] = array(
		array(
			'id'    => 'section-design',
			'title' => esc_attr__( 'Hero', 'zeen-engine' ),
		),
		array(
			'id'    => 'section-layout',
			'title' => esc_attr__( 'Layout', 'zeen-engine' ),
		),
		array(
			'id'    => 'section-header',
			'title' => esc_attr__( 'Header', 'zeen-engine' ),
		),
		array(
			'id'    => 'section-extra',
			'title' => esc_attr__( 'Overrides', 'zeen-engine' ),
		),
		array(
			'id'    => 'section-spon',
			'title' => esc_attr__( 'Sponsored Post', 'zeen-engine' ),
		),
		array(
			'id'    => 'section-list',
			'title' => esc_attr__( 'Listicle', 'zeen-engine' ),
		),
		array(
			'id'    => 'section-misc',
			'title' => esc_attr__( 'Misc.', 'zeen-engine' ),
		),
	);

	$zeen_engine__metabox_post_formats         = array(
		'post_type' => $post_types_formats,
		'id'        => 'zeen-media-options',
		'src_uri'   => get_parent_theme_file_uri( 'assets/admin/img/' ),
		'prefix'    => 'zeen',
		'title'     => get_theme_mod( 'white_label_onoff' ) == 1 ? get_theme_mod( 'white_label_name', 'Zeen' ) . ' ' . esc_html__( 'Media', 'zeen-engine' ) : esc_html__( 'Zeen Media', 'zeen-engine' ),
	);
	$zeen_engine__metabox_post_formats['args'] = array(
		array(
			'control' => 'select',
			'id'      => 'source',
			'class'   => 'post-format-video post-format-audio post-format-dependant',
			'title'   => esc_html__( 'Source', 'zeen-engine' ),
			'default' => 1,
			'choices' => array(
				1 => esc_html__( 'External', 'zeen-engine' ),
				2 => esc_html__( 'HTML5 Self-Hosted', 'zeen-engine' ),
			),
		),
		array(
			'control'     => 'radio-images',
			'id'          => 'media-design',
			'title'       => esc_html__( 'Media Design', 'zeen-engine' ),
			'description' => esc_html__( 'The Use Default option uses the selection set in Theme Options > Posts > Global Hero Size.', 'zeen-engine' ),
			'default'     => 99,
			'class'       => 'post-format-video post-format-audio post-format-dependant',
			'choices'     => $md_v,
		),
		array(
			'control'     => 'text',
			'id'          => 'duration',
			'title'       => esc_html__( 'Duration', 'zeen-engine' ),
			'description' => esc_html__( 'Enter duration (Optional).', 'zeen-engine' ),
			'class'       => 'post-format-video post-format-audio post-format-dependant',
		),
		array(
			'control' => 'title',
			'id'      => 'title-video',
			'title'   => esc_html__( 'Video', 'zeen-engine' ),
		),
		array(
			'control'     => 'textarea',
			'id'          => 'video-code',
			'class'       => 'post-format-video post-format-video-ext post-format-dependant',
			'title'       => esc_html__( 'Video', 'zeen-engine' ),
			'description' => esc_html__( 'Enter the url or embed code of your video', 'zeen-engine' ),
		),
		array(
			'control' => 'image',
			'id'      => 'video-file-1',
			'class'   => 'post-format-video post-format-video-self post-format-dependant',
			'title'   => 'MP4 ' . $gutenberg_video,
			'choices' => array(
				'file_type' => 'video',
			),
		),
		array(
			'control' => 'image',
			'id'      => 'video-file-2',
			'class'   => 'post-format-video post-format-video-self post-format-dependant',
			'title'   => 'OGG ' . $gutenberg_video,
			'choices' => array(
				'file_type' => 'video',
			),
		),
		array(
			'control' => 'title',
			'id'      => 'title-audio',
			'title'   => esc_html__( 'Audio', 'zeen-engine' ),
		),
		array(
			'control'     => 'textarea',
			'id'          => 'audio-code',
			'class'       => 'post-format-audio post-format-audio-ext post-format-dependant',
			'title'       => esc_html__( 'External Audio', 'zeen-engine' ),
			'description' => esc_html__( 'Enter the full embed code here. See documentation for instructions for specific services.', 'zeen-engine' ),
		),
		array(
			'control' => 'image',
			'id'      => 'audio-file-1',
			'class'   => 'post-format-audio post-format-audio-self post-format-dependant',
			'title'   => 'MP3 ' . $gutenberg_audio,
			'choices' => array(
				'file_type' => 'audio',
			),
		),
		array(
			'control' => 'image',
			'id'      => 'audio-file-2',
			'class'   => 'post-format-audio post-format-audio-self post-format-dependant',
			'title'   => 'OGG ' . $gutenberg_audio,
			'choices' => array(
				'file_type' => 'audio',
			),
		),
		array(
			'control' => 'title',
			'id'      => 'title-gallery',
			'title'   => esc_html__( 'Gallery', 'zeen-engine' ),
		),
		array(
			'control'     => 'radio-images',
			'id'          => 'gallery-design',
			'title'       => esc_html__( 'Gallery Design', 'zeen-engine' ),
			'description' => esc_html__( 'The Use Default option uses the selection set in Theme Options > Posts > Global Hero Size. Note the exact size of the gallery depends on the chosen Hero Design below.', 'zeen-engine' ),
			'default'     => 99,
			'class'       => 'post-format-gallery post-format-dependant',
			'choices'     => $md_g,
		),
		array(
			'control'     => 'gallery',
			'id'          => 'gallery',
			'class'       => 'post-format-gallery post-format-dependant',
			'title'       => esc_html__( 'Gallery Images', 'zeen-engine' ),
			'description' => esc_html__( 'The description', 'zeen-engine' ),
		),
		array(
			'control' => 'title',
			'id'      => 'title-podcast',
			'title'   => esc_html__( 'Podcast', 'zeen-engine' ),
		),
		array(
			'control' => 'on-off',
			'id'      => 'podcast-mode',
			'title'   => esc_html__( 'Podcast Mode', 'zeen-engine' ),
			'default' => 'off',
		),
	);

	$zeen_engine__metabox_page = array(
		'post_type' => array( 'page' ),
		'id'        => 'zeen-page-options',
		'src_uri'   => get_parent_theme_file_uri( 'assets/admin/img/' ),
		'prefix'    => 'zeen',
		'title'     => get_theme_mod( 'white_label_onoff' ) == 1 ? get_theme_mod( 'white_label_name', 'Zeen' ) . ' ' . esc_html__( 'Options', 'zeen-engine' ) : esc_html__( 'Zeen Options', 'zeen-engine' ),
		'args'      => array(
			array(
				'control' => 'section',
				'id'      => 'section-design',
				'choices' =>
					array(
						'count' => 1,
					),
			),
			array(
				'control'     => 'radio-images',
				'id'          => 'hero-design',
				'title'       => esc_html__( 'Hero Design', 'zeen-engine' ),
				'description' => esc_html__( 'Select the design for your featured image. The "Use Default" option uses the selection set in Theme Options > Pages > Default Hero Design.', 'zeen-engine' ),
				'default'     => 99,
				'choices'     => $heros,
			),
			array(
				'control'  => 'select',
				'id'       => 'cover-height',
				'title'    => esc_html__( 'Hero Height', 'zeen-engine' ),
				'default'  => 1,
				'choices'  => array(
					99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
					1  => esc_html__( '100% Screen Height', 'zeen-engine' ),
					2  => esc_html__( '66% Screen Height', 'zeen-engine' ),
					3  => esc_html__( '50% Screen Height', 'zeen-engine' ),
					11 => esc_html__( 'Native Image Height (No Crop)', 'zeen-engine' ),
				),
				'required' => array(
					'id'    => 'hero-design',
					'value' => $cover_height,
				),
			),
			array(
				'control'  => 'select',
				'id'       => 'parallax',
				'title'    => esc_html__( 'Parallax Effect', 'zeen-engine' ),
				'default'  => 99,
				'choices'  => array(
					99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
					1  => esc_html__( 'On', 'zeen-engine' ),
					2  => esc_html__( 'Off', 'zeen-engine' ),
				),
				'required' => array(
					'id'    => 'hero-design',
					'value' => $parallax_effect,
				),
			),
			array(
				'control'     => 'select',
				'id'          => 'hero-color',
				'title'       => esc_html__( 'Hero Overlay Color', 'zeen-engine' ),
				'description' => esc_html__( 'This color appears on top of the hero image. The Use Default option uses the color set in Theme Options > Pages > Hero Overlay Color.', 'zeen-engine' ),
				'default'     => 99,
				'choices'     => array(
					99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
					1  => esc_html__( 'On', 'zeen-engine' ),
				),
				'required'    => array(
					'id'    => 'hero-design',
					'value' => $hero_design,
				),
			),
			array(
				'control'  => 'color-a',
				'id'       => 'overlay',
				'title'    => esc_html__( 'Hero Overlay Custom Color', 'zeen-engine' ),
				'default'  => 'rgba(0,0,0,0.4)',
				'required' => array(
					'id'      => 'hero-color',
					'value'   => 1,
					'id_2'    => 'hero-design',
					'value_2' => $hero_design,
				),
			),
			array(
				'control'  => 'color',
				'id'       => 'overlay-text',
				'title'    => esc_html__( 'Hero Title Text Color', 'zeen-engine' ),
				'default'  => '#fff',
				'required' => array(
					'id'      => 'hero-color',
					'value'   => 1,
					'id_2'    => 'hero-design',
					'value_2' => $hero_design,
				),
			),
			array(
				'control'  => 'color',
				'id'       => 'background-color',
				'title'    => esc_html__( 'Background Transition Color', 'zeen-engine' ),
				'default'  => '#fff',
				'required' => array(
					'id'    => 'hero-design',
					'value' => 31,
				),
			),
			array(
				'control'      => 'radio-images',
				'id'           => 'splitter_bottom',
				'title'        => esc_html__( 'Bottom Divider Shape', 'zeen-engine' ),
				'default'      => 99,
				'zero_allowed' => true,
				'choices'      => $splitter_list,
			),
			array(
				'control' => 'section',
				'id'      => 'section-layout',
				'choices' =>
					array(
						'count' => 2,
					),
			),
			array(
				'control'     => 'radio-images',
				'id'          => 'article-layout',
				'title'       => esc_html__( 'Article Layout', 'zeen-engine' ),
				'description' => esc_html__( 'The Use Default option uses the selection set in Theme Options > Pages > Default Article Layout.', 'zeen-engine' ),
				'default'     => 99,
				'choices'     => $layouts_p,
			),
			array(
				'control'  => 'gallery',
				'id'       => 'article-layout-gallery',
				'title'    => esc_html__( 'Sticky Side Gallery', 'zeen-engine' ),
				'required' => array(
					'id'    => 'article-layout',
					'value' => array( 58, 59 ),
				),
			),
			array(
				'control' => 'on-off',
				'id'      => 'article-layout-skin',
				'title'   => esc_html__( 'Dark Article', 'zeen-engine' ),
				'default' => 'off',
			),
			array(
				'control'     => 'drag',
				'id'          => 'share-details',
				'title'       => esc_html__( 'Sticky Details', 'zeen-engine' ),
				'description' => esc_html__( 'Add as many blocks of information you want to show in the sticky block that slides alongside the article. Can be drag and dropped too.', 'zeen-engine' ),
				'default'     => '',
				'choices'     => array(
					1 => array(
						'name'  => 'title',
						'title' => esc_attr__( 'Title', 'zeen-engine' ),
						'type'  => 'text',
					),
					2 => array(
						'name'  => 'content',
						'title' => esc_attr__( 'Content', 'zeen-engine' ),
						'type'  => 'text',
					),
				),
				'required'    => array(
					'id'    => 'article-layout',
					'value' => $sticky_details,
				),
			),
			array(
				'control'     => 'select',
				'id'          => 'sidebar-pids',
				'title'       => esc_html__( 'Sidebar to use', 'zeen-engine' ),
				'description' => esc_html__( 'Inherit = uses the category (if exists) or global sidebar. Unique sidebar = Adds new sidebar in Appearance > Widgets with post title', 'zeen-engine' ),
				'default'     => 1,
				'choices'     => $widget_areas,
				'global'      => 2,
				'required'    => array(
					'id'    => 'article-layout',
					'value' => array( 1, 2, 11, 12 ),
				),
			),
			array(
				'control'     => 'radio-images',
				'id'          => 'singular-header',
				'title'       => esc_html__( 'Special Header Design', 'zeen-engine' ),
				'description' => esc_html__( 'Set a special header for this post. If you choose "Default" then whatever option you set in the Customizer > Pages option will load. If you choose "x" then the main global header will load.', 'zeen-engine' ),
				'default'     => 99,
				'choices'     => $singular_h,
			),
		),
		'sections'  => array(
			array(
				'id'    => 'section-design',
				'title' => esc_attr__( 'Hero', 'zeen-engine' ),
			),
			array(
				'id'    => 'section-layout',
				'title' => esc_attr__( 'Layout', 'zeen-engine' ),
			),
		),
	);

	if ( ! empty( $gutenberg ) ) {
		$zeen_engine__metabox['args'][]     = array(
			'control' => 'section',
			'id'      => 'section-media',
			'choices' => array(
				'count' => 5,
			),
		);
		$zeen_engine__metabox['args']       = array_merge( $zeen_engine__metabox['args'], $zeen_engine__metabox_post_formats['args'] );
		$zeen_engine__metabox['sections'][] = array(
			'id'    => 'section-media',
			'title' => esc_attr__( 'Media Formats', 'zeen-engine' ),
		);
	}

	new Zeen_Engine_Metabox( $zeen_engine__metabox );
	new Zeen_Engine_Metabox( $zeen_engine__metabox_page );
	if ( empty( $gutenberg ) ) {
		new Zeen_Engine_Metabox( $zeen_engine__metabox_post_formats );
	} else {
		$post_types[] = 'page';
		new Zeen_Engine_Metabox(
			array(
				'post_type' => $post_types,
				'prefix'    => 'zeen',
				'context'   => 'side',
				'id'        => 'zeen-subtitle',
				'src_uri'   => get_parent_theme_file_uri( 'assets/admin/img/' ),
				'title'     => get_theme_mod( 'white_label_onoff' ) ? get_theme_mod( 'white_label_name', 'Zeen' ) . ' ' . esc_html__( 'Subtitle', 'zeen-engine' ) : esc_html__( 'Zeen Subtitle', 'zeen-engine' ),
				'args'      => array(
					array(
						'control' => 'text',
						'id'      => 'subtitle',
						'class'   => 'subtitle',
					),
				),
			)
		);
	}
	if ( class_exists( 'woocommerce' ) ) {
		$zeen_engine__metabox_product = array(
			'post_type' => array( 'product' ),
			'id'        => 'zeen-product-options',
			'src_uri'   => get_parent_theme_file_uri( 'assets/admin/img/' ),
			'prefix'    => 'zeen',
			'title'     => get_theme_mod( 'white_label_onoff' ) == 1 ? get_theme_mod( 'white_label_name', 'Zeen' ) . ' ' . esc_html__( 'Options', 'zeen-engine' ) : esc_html__( 'Zeen Options', 'zeen-engine' ),
			'args'      => array(
				array(
					'control' => 'section',
					'id'      => 'section-design',
					'choices' =>
						array(
							'count' => 1,
						),
				),
				array(
					'control'     => 'radio-images',
					'id'          => 'hero-design',
					'title'       => esc_html__( 'Hero Layout', 'zeen-engine' ),
					'description' => esc_html__( 'Select the hero design for this product. The "Use Default" option uses the selection set in Theme Options > WooCommerce > Zeen WooCommerce > Default Product Hero Area.', 'zeen-engine' ),
					'default'     => 99,
					'choices'     => $product_hero,
				),
				array(
					'control'     => 'select',
					'id'          => 'sidebar-pids',
					'title'       => esc_html__( 'Sidebar to use', 'zeen-engine' ),
					'description' => esc_html__( 'Inherit = uses the category (if exists) or global sidebar. Unique sidebar = Adds new sidebar in Appearance > Widgets with post title', 'zeen-engine' ),
					'default'     => 1,
					'choices'     => $widget_areas,
					'global'      => 2,
					'required'    => array(
						'id'    => 'hero-design',
						'value' => array( 1 ),
					),
				),
				array(
					'control'     => 'select',
					'id'          => 'hero-color',
					'title'       => esc_html__( 'Hero Area Background Color', 'zeen-engine' ),
					'description' => esc_html__( 'The Use Customizer Option uses the color set in Theme Options > WooCommerce > Zeen WooCommerce: Hero Area Background Color.', 'zeen-engine' ),
					'default'     => 99,
					'choices'     => array(
						99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
						1  => esc_html__( 'On', 'zeen-engine' ),
						2  => esc_html__( 'Off', 'zeen-engine' ),
					),
					'required'    => array(
						'id'    => 'hero-design',
						'value' => array( 2, 3, 4, 5, 6, 7 ),
					),
				),
				array(
					'control'  => 'select',
					'id'       => 'hero-text-color',
					'title'    => esc_html__( 'Hero Area Text Color', 'zeen-engine' ),
					'default'  => 2,
					'choices'  => array(
						2 => esc_html__( 'Dark', 'zeen-engine' ),
						1 => esc_html__( 'Light', 'zeen-engine' ),
					),
					'required' => array(
						'id'      => 'hero-color',
						'value'   => 1,
						'id_2'    => 'hero-design',
						'value_2' => array( 2, 3, 4, 5, 6, 7 ),
					),
				),
				array(
					'control'  => 'color-a',
					'id'       => 'overlay',
					'title'    => esc_html__( 'Background Color', 'zeen-engine' ),
					'default'  => 'rgba(255,255,255,1)',
					'required' => array(
						'id'      => 'hero-color',
						'value'   => 1,
						'id_2'    => 'hero-design',
						'value_2' => array( 2, 3, 4, 5, 6, 7 ),
					),
				),
				array(
					'control'  => 'color-a',
					'id'       => 'inputs-bg',
					'title'    => esc_html__( 'Input Background Colors', 'zeen-engine' ),
					'default'  => 'rgba(255,255,255,1)',
					'required' => array(
						'id'      => 'hero-color',
						'value'   => 1,
						'id_2'    => 'hero-design',
						'value_2' => array( 2, 3, 4, 5, 6, 7 ),
					),
				),
				array(
					'control'  => 'color-a',
					'id'       => 'inputs-border',
					'title'    => esc_html__( 'Input Border Colors', 'zeen-engine' ),
					'default'  => '#f2f2f2',
					'required' => array(
						'id'      => 'hero-color',
						'value'   => 1,
						'id_2'    => 'hero-design',
						'value_2' => array( 2, 3, 4, 5, 6, 7 ),
					),
				),
				array(
					'control'  => 'color-a',
					'id'       => 'inputs-color',
					'title'    => esc_html__( 'Input Text Colors', 'zeen-engine' ),
					'default'  => '#111',
					'required' => array(
						'id'      => 'hero-color',
						'value'   => 1,
						'id_2'    => 'hero-design',
						'value_2' => array( 2, 3, 4, 5, 6, 7 ),
					),
				),
				array(
					'control' => 'section',
					'id'      => 'section-layout',
					'choices' =>
						array(
							'count' => 2,
						),
				),
				array(
					'control'     => 'radio-images',
					'id'          => 'tabs',
					'title'       => esc_html__( 'Tabs Design', 'zeen-engine' ),
					'description' => esc_html__( 'Select the design for this product. The "Use Default" option uses the selection set in Theme Options > WooCommerce > Zeen WooCommerce.', 'zeen-engine' ),
					'default'     => 99,
					'choices'     => $product_tabs,
				),
				array(
					'control'     => 'radio-images',
					'id'          => 'description-width',
					'title'       => esc_html__( 'Description Area Width', 'zeen-engine' ),
					'description' => esc_html__( 'Select the design for this product. The "Use Default" option uses the selection set in Theme Options > WooCommerce > Zeen WooCommerce.', 'zeen-engine' ),
					'default'     => 99,
					'choices'     => $product_width,
				),
				array(
					'control' => 'section',
					'id'      => 'section-media',
					'choices' =>
						array(
							'count' => 3,
						),
				),
				array(
					'control' => 'select',
					'id'      => 'source',
					'class'   => 'post-format-video post-format-audio post-format-dependant',
					'title'   => esc_html__( 'Source', 'zeen-engine' ),
					'default' => 2,
					'choices' => array(
						2 => esc_html__( 'HTML5 Self-Hosted', 'zeen-engine' ),
						1 => esc_html__( 'External', 'zeen-engine' ),
					),
				),
				array(
					'control' => 'image',
					'id'      => 'video-file-1',
					'class'   => 'post-format-video post-format-video-self post-format-dependant',
					'title'   => 'MP4 ' . $gutenberg_video,
					'choices' => array(
						'file_type' => 'video',
					),
				),
				array(
					'control' => 'image',
					'id'      => 'video-file-2',
					'class'   => 'post-format-video post-format-video-self post-format-dependant',
					'title'   => 'OGG ' . $gutenberg_video,
					'choices' => array(
						'file_type' => 'video',
					),
				),
				array(
					'control'     => 'textarea',
					'id'          => 'video-code',
					'class'       => 'post-format-video post-format-video-ext post-format-dependant',
					'title'       => esc_html__( 'External Video', 'zeen-engine' ),
					'description' => esc_html__( 'Enter the url or embed code of your video', 'zeen-engine' ),
				),
				array(
					'control' => 'section',
					'id'      => 'section-header',
					'choices' =>
						array(
							'count' => 4,
						),
				),
				array(
					'control' => 'on-off',
					'id'      => 'header-overlap',
					'title'   => esc_html__( 'Overlapping Header', 'zeen-engine' ),
					'default' => 'off',
				),
				array(
					'control'     => 'on-off',
					'id'          => 'header-overlap-inverse-logo',
					'title'       => esc_html__( 'Use Inverse Logo', 'zeen-engine' ),
					'description' => esc_html__( 'Use the inverse header logo you have set in the theme options', 'zeen-engine' ),
					'default'     => 'off',
					'required'    => array(
						'id'    => 'header-overlap',
						'value' => 'on',
					),
				),
				array(
					'control'  => 'select',
					'id'       => 'header-overlap-skin',
					'title'    => esc_html__( 'Style', 'zeen-engine' ),
					'default'  => 1,
					'choices'  => array(
						1 => esc_html__( 'Light', 'zeen-engine' ),
						2 => esc_html__( 'Dark', 'zeen-engine' ),
					),
					'required' => array(
						'id'    => 'header-overlap',
						'value' => 'on',
					),
				),
				array(
					'control' => 'section',
					'id'      => 'section-overrides',
					'choices' =>
						array(
							'count' => 5,
						),
				),
				array(
					'control' => 'select',
					'id'      => 'related-posts',
					'title'   => esc_html__( 'Show Related Posts', 'zeen-engine' ),
					'default' => 99,
					'choices' => array(
						99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
						1  => esc_html__( 'On', 'zeen-engine' ),
						2  => esc_html__( 'Off', 'zeen-engine' ),
					),
				),
				array(
					'control' => 'select',
					'id'      => 'new',
					'title'   => esc_html__( 'Show New Label', 'zeen-engine' ),
					'default' => 99,
					'choices' => array(
						99 => esc_html__( 'Use Customizer Setting', 'zeen-engine' ),
						1  => esc_html__( 'On', 'zeen-engine' ),
						2  => esc_html__( 'Off', 'zeen-engine' ),
					),
				),
			),
			'sections'  => array(
				array(
					'id'    => 'section-design',
					'title' => esc_attr__( 'Hero', 'zeen-engine' ),
				),
				array(
					'id'    => 'section-layout',
					'title' => esc_attr__( 'Layout', 'zeen-engine' ),
				),
				array(
					'id'    => 'section-media',
					'title' => esc_attr__( 'Media', 'zeen-engine' ),
				),
				array(
					'id'    => 'section-header',
					'title' => esc_attr__( 'Header', 'zeen-engine' ),
				),
				array(
					'id'    => 'section-overrides',
					'title' => esc_attr__( 'Overrides', 'zeen-engine' ),
				),
			),
		);
		new Zeen_Engine_Metabox( $zeen_engine__metabox_product );
	}
}

add_action( 'load-post.php', 'zeen_engine__metabox' );
add_action( 'load-post-new.php', 'zeen_engine__metabox' );
