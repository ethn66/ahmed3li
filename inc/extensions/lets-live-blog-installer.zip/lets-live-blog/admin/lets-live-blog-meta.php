<?php
/**
 * Metaboxes
 *
 * @package     Lets_Live_Blog
 * @copyright   Copyright Codetipi
 * @since       1.0.0
 */

/**
 * Metabox Class init
 *
 * @since  1.0.0
 */
function lets_live_blog_meta( $src_uri ) {

	$post_types = get_post_types(
		array(
			'public'   => true,
			'_builtin' => false,
		)
	);

	$post_types[]       = 'post';
	$post_types_formats = $post_types;
	unset( $post_types['product'] );

	return array(
		'src_uri'   => $src_uri,
		'post_type' => $post_types,
		'prefix'    => 'lets_live_blog',
		'id'        => 'lets-live-blog-options',
		'title'     => esc_html__( "Let's Live Blog Options", 'lets-live-blog' ),
		'args'      => array(
			array(
				'control' => 'section',
				'id'      => 'section-event',
				'choices' =>
					array(
						'count' => 1,
					),
			),
			array(
				'control' => 'on-off',
				'id'      => 'enabled',
				'title'   => esc_html__( 'Enable Live Blog', 'lets-live-blog' ),
				'default' => '',
			),
			array(
				'control'  => 'text',
				'id'       => 'event-title',
				'title'    => esc_html__( 'Event Title', 'lets-live-blog' ),
				'default'  => '',
				'required' => array(
					'id'    => 'enabled',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'text',
				'id'       => 'event-location',
				'title'    => esc_html__( 'Event Location', 'lets-live-blog' ),
				'default'  => '',
				'required' => array(
					'id'    => 'enabled',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'text',
				'id'       => 'event-start',
				'class'    => 'lets-live-blog-date-time-field zeen-engine-date-time-field',
				'title'    => esc_html__( 'Event Start Time', 'lets-live-blog' ),
				'default'  => '',
				'required' => array(
					'id'    => 'enabled',
					'value' => 'on',
				),
			),
			array(
				'control'     => 'select',
				'id'          => 'date',
				'title'       => esc_html__( 'Date Format', 'lets-live-blog' ),
				'description' => esc_html__( 'The date format visitors see. Authors doing the live blog will always see date & time.', 'lets-live-blog' ),
				'default'     => 1,
				'choices'     => array(
					1 => esc_html__( 'Date + Time', 'lets-live-blog' ),
					2 => esc_html__( 'Time', 'lets-live-blog' ),
					3 => esc_html__( 'X Minutes Ago', 'lets-live-blog' ),
				),
				'required'    => array(
					'id'    => 'enabled',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'radio-images',
				'id'       => 'design',
				'title'    => esc_html__( 'Entry Design', 'lets-live-blog' ),
				'default'  => 1,
				'choices'  => array(
					1 => array( 'url' => 'design-1.png' ),
					2 => array( 'url' => 'design-2.png' ),
				),
				'required' => array(
					'id'    => 'enabled',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'radio-images',
				'id'       => 'animation',
				'title'    => esc_html__( 'Animation', 'lets-live-blog' ),
				'default'  => 1,
				'choices'  => array(
					1 => array( 'url' => 'animation-1.gif' ),
					2 => array( 'url' => 'animation-2.gif' ),
				),
				'required' => array(
					'id'    => 'enabled',
					'value' => 'on',
				),
			),
			array(
				'control' => 'section',
				'id'      => 'section-schema',
				'choices' =>
					array(
						'count' => 2,
					),
			),
			array(
				'control' => 'image',
				'id'      => 'event-image',
				'title'   => esc_html__( 'Event Image', 'lets-live-blog' ),
				'default' => '',
			),
			array(
				'control'  => 'text',
				'id'       => 'event-end',
				'class'    => 'lets-live-blog-date-time-field zeen-engine-date-time-field',
				'title'    => esc_html__( 'Event End Time', 'lets-live-blog' ),
				'default'  => '',
			),
			array(
				'control' => 'text',
				'id'      => 'event-headline',
				'title'   => esc_html__( 'Event Headline', 'lets-live-blog' ),
				'default' => '',
			),
			array(
				'control' => 'text',
				'id'      => 'event-address',
				'title'   => esc_html__( 'Event Address', 'lets-live-blog' ),
				'default' => '',
			),
			array(
				'control' => 'text',
				'id'      => 'event-organizer',
				'title'   => esc_html__( 'Event Organizer', 'lets-live-blog' ),
				'default' => '',
			),
			array(
				'control' => 'text',
				'id'      => 'event-organizer-url',
				'title'   => esc_html__( 'Event Organizer URL', 'lets-live-blog' ),
				'default' => '',
			),
			array(
				'control' => 'text',
				'id'      => 'event-mode',
				'title'   => esc_html__( 'Online Or Offline Event', 'lets-live-blog' ),
				'default' => 'Offline',
			),

		),
		'sections'  => array(
			array(
				'id'    => 'section-event',
				'title' => esc_attr__( 'Event', 'lets-live-blog' ),
			),
			array(
				'id'    => 'section-schema',
				'title' => esc_attr__( 'Schema', 'lets-live-blog' ),
			),
		),
	);

}


function lets_live_blog_sanitize_wp_kses( $data ) {

	return wp_kses(
		$data,
		array(
			'a'      => array(
				'href'  => array(),
				'title' => array(),
			),
			'span'   => array(
				'class' => array(),
				'id'    => array(),
			),
			'img'    => array(
				'src'    => array(),
				'srcset' => array(),
				'alt'    => array(),
			),
			'i'      => array(
				'class' => array(),
				'id'    => array(),
			),
			'div'    => array(
				'class' => array(),
				'id'    => array(),
			),
			'br'     => array(),
			'em'     => array(),
			'strong' => array(),
			'italic' => array(),
		)
	);

}


function lets_live_blog_sanitize_titles( $data ) {

	return wp_kses(
		$data,
		array(
			'span'   => array(
				'class' => array(),
			),
			'div'    => array(
				'class' => array(),
			),
			'br'     => array(),
			'em'     => array(),
			'strong' => array(),
		)
	);

}

/**
 * Sanitizer Commas
 *
 * @since  1.0.0
 */
function lets_live_blog_sanitize_num_commas( $data ) {

	$data = filter_var( $data, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION | FILTER_FLAG_ALLOW_THOUSAND );
	return $data;

}

/**
 * Sanitizer Array
 *
 * @since  1.0.0
 */
function lets_live_blog_sanitize_array( $array ) {

	if ( ! is_array( $array ) ) {
		return array();
	}

	foreach ( $array as $key => $value ) {

		if ( is_array( $value ) ) {
			$array[ $key ] = lets_live_blog_sanitize_array( $value );
		} else {
			$array[ $key ] = esc_attr( $value );
		}
	}

	return $array;
}

/**
 * Sanitizer Floats
 *
 * @since  1.0.0
 */
function lets_live_blog_sanitizer_float( $data ) {
	return floatval( $data );
}
