<?php
/**
 * Let's Live Blog helpers Class
 *
 * @package 	Lets_Live_Blog
 * @copyright   Copyright Codetipi
 * @since 		1.2.0
 */
namespace letsliveblog;
class Lets_Live_Blog_Helpers {

	public static function lets_live_blog_content_process( $content = '' ) {
		$media = self::lets_live_blog_media_check( $content );
		if ( ! empty( $media ) ) {
			foreach ( $media as $key ) {
				$content = str_replace( $key, self::lets_live_blog_media_process( self::lets_live_blog_media_url( $key ) ), $content );
			}
		}
		$tweets = self::lets_live_blog_tweets_check( $content );
		if ( ! empty( $tweets ) ) {
			foreach ( $tweets as $key ) {
				global $wp_embed;
				$tweet_content = str_replace( $key[0], $wp_embed->run_shortcode( '[embed]' . $key[0] . '[/embed]' ), $content );
			}
			if ( ! empty( $tweet_content ) ) {
				$content = $tweet_content;
			}
		}
		return do_shortcode( $content );
	}
	public static function lets_live_blog_tweets_check( $content = '' ) {
		$regex = '/https?:\/\/twitter\.com\/(?:#!\/)?(\w+)\/status(es)?\/(\d+)/';
		$output = array();
		preg_match_all( $regex, $content, $matches );
		foreach ( $matches as $match => $match_val ) {
			if ( 0 !== (int) $match && 3 !== (int) $match ) {
				continue;
			}
			foreach ( $match_val as $key => $value ) {
				$output[ $key ][] = $value;
			}
		}
		return $output;
	}
	public static function lets_live_blog_media_check( $html ) {
		$regex = '/(http:|https:|)\/\/(player.|www.)?(vimeo\.com|youtu(be\.com|\.be|be\.googleapis\.com))\/(video\/|embed\/|channels\/(?:\w+\/)|watch\?v=|v\/)?([A-Za-z0-9._%-]*)(\&\S+)?/';

		preg_match_all( $regex, $html, $matches );
		$matches = array_unique( $matches[0] );
		usort(
			$matches,
			function( $a, $b ) {
				return strlen( $b ) - strlen( $a );
			}
		);
		return $matches;
	}
	public static function lets_live_blog_media_process( $url = '' ) {
		if ( empty( $url ) ) {
			return;
		}
		return '<div class="llb-frame video-wrap"><iframe width="1280" height="720" scrolling="no" src="' . esc_url( $url ) . '" frameborder="0" seamless="seamless" allowfullscreen="true"></iframe></div>';
	}

	public static function lets_live_blog_media_url( $url = '', $args = array() ) {
		$args['background'] = empty( $args['background'] ) ? '' : $args['background'];
		if ( strpos( $url, 'yout' ) !== false ) {
			$type = 'yt';
		} else {
			if ( substr( $url, 0, 2 ) == '<i' ) {
				preg_match( '/src="([^"]+)"/', $url, $matches );
				if ( ! empty( $matches[1] ) ) {
					return $matches[1];
				} else {
					return '';
				}
			} elseif ( substr( $url, 0, 1 ) == '[' ) {
				$url = do_shortcode( $url );
			}

			if ( strpos( $url, 'vim' ) !== false ) {
				$type = 'vim';
			} elseif ( strpos( $url, 'soundc' ) !== false ) {
				$type = 'sc';
			} else {
				$type = '';
			}
		}

		switch ( $type ) {
			case 'vim':
				$url = substr( wp_parse_url( $url, PHP_URL_PATH ), 1 );
				if ( ! empty( $args['id_only'] ) ) {
					return $url;
				}
				$vid_args = array(
					'autoplay' => 0,
				);
				if ( ! empty( $args['background'] ) ) {
					$vid_args['autoplay']   = 1;
					$vid_args['muted']      = 1;
					$vid_args['loop']       = 1;
					$vid_args['portrait']   = 0;
					$vid_args['byline']     = 0;
					$vid_args['dnt']        = 0;
					$vid_args['background'] = 1;
					$vid_args['title']      = 1;
				}
				return add_query_arg(
					$vid_args,
					'https://player.vimeo.com/video/' . $url
				);
			case 'yt':
				preg_match( '([-\w]{11})', $url, $matches );
				if ( ! empty( $matches ) ) {
					if ( ! empty( $args['id_only'] ) ) {
						return $matches[0];
					}
					$vid_args = array(
						'autoplay'       => 0,
						'rel'            => 0,
						'showinfo'       => 0,
						'modestbranding' => 1,
					);
					if ( ! empty( $args['background'] ) ) {
						$vid_args['controls']       = 0;
						$vid_args['loop']           = 1;
						$vid_args['playsinline']    = 1;
						$vid_args['showinfo']       = 0;
						$vid_args['fs']             = 0;
						$vid_args['iv_load_policy'] = 3;
						$vid_args['playlist']       = $matches[0];
					}
					return add_query_arg( $vid_args, 'https://www.youtube-nocookie.com/embed/' . $matches[0] );
				}
				break;
			default:
				global $wp_embed;
				$url = $wp_embed->run_shortcode( '[embed]' . $url . '[/embed]' );
				preg_match( '/src="([^"]+)"/', $url, $matches );
				return isset( $matches[1] ) ? $matches[1] : $url;
		}
	}

}
