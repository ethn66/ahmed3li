/**
 * Copyright: Codetipi
 * Plugin: Let's Live Blog
 * Version: 1.2.1
 */
(function ($) {
	var letsLiveBlog = {
		init: function () {
			this.cacheDom();
			this.cacheData();
			this.bindEvents();
			this.ajaxCheck('init');
			this.shareCheck();
		},
		cacheDom: function () {
			this.$doc = $(document);
			this.$win = $(window);
			this.$body = $('body');
			this.$entry = $('.lets-live-blog-wrap');
			this.$hls = $('#lets-live-blog-highlights');
			this.$hlsa = this.$hls.find('a');
			this.$entryWrap = this.$entry.find('.lets-live-blog-entry-wrap');
			this.$entryHl = this.$entry.find('.lets-live-blog-entry-hl-wrap');
			this.$pagi = this.$entry.find('.lets-live-blog-pagi');
			this.$broadcasting = this.$entry.data('status');
			this.higlightTitleLdd = false;
			this.hashRun = false;
			this.$entryCount = '';
			this.todoList = '';
			this.hash = window.location.hash;
		},
		cacheData: function () {
			this.$winWidth = this.$win.width();
		},
		bindEvents: function () {
			this.$win.on('resize', this.resize.bind(this));
			this.$hlsa.on('click', this.jumphl);
			this.$body.on( 'click', '.lets-live-blog-pagi', this.pagi );
		},
		shareCheck: function () {
			if ( this.hash.length > 0 && this.hash.includes( 'live-feed' ) ) {
				this.hashRun = $('.lets-live-blog-pagi');
				this.hashRun.click();
			}
		},
		ajaxCheck: function (timing) {
			if (this.$broadcasting != 2) {
				return;
			}
			var vm = this;
			$.ajax({
				method: "GET",
				url: letsLiveBlogJs.root_full + 'history',
				data: 'pid=' + letsLiveBlogJs.data.pid  + '&timestamp=' + ( new Date().getTime() ),
				beforeSend: function (xhr) {
					xhr.setRequestHeader('X-WP-Nonce', letsLiveBlogJs.nonce);
				},
				success: function (response) {
					if (timing === 'init') {
						vm.$entryCount = response.length;
						vm.ajaxUpdate();
					}
					if (response.length !== vm.$entryCount) {
						vm.todoList = response.slice(- (response.length - vm.$entryCount))
						vm.theQueue();
						vm.$entryCount = response.length;
					}
				},
				fail: function (response) {
					console.log('ERROR:', response );
				}
			});
		},
		theQueue: function () {
			var item = this.todoList.shift();
			if (typeof item === 'undefined') {
				return;
			}
			if (item[0] === 'add') {
				this.ajaxAdd({ item: item[1], hl: item[3] });
			} else if (item[0] === 'del') {
				this.ajaxRemove(item[1]);
			} else {
				this.ajaxUpdates(item);
			}
		},
		ajaxAdd: function (args) {
			var vm = this;
			$.ajax({
				method: "GET",
				url: letsLiveBlogJs.root_full + 'entry',
				data: { add: args['item'] },
				beforeSend: function (xhr) {
					xhr.setRequestHeader('X-WP-Nonce', letsLiveBlogJs.nonce);
				},
				success: function (response) {
					if (typeof (args['pos']) === 'undefined') {
						vm.$entryWrap.prepend(response[0].rendered);
						if (args['hl'] !== false) {
							vm.checkHlTitle();
							vm.$entryHl.prepend(response[0].renderedHl);
						}

					} else {
						vm.$entryWrap.children(':eq(' + args['pos'] + ')').attr('id', args['item']).replaceWith(response[0].rendered);
						var oldHl = $('#live-feed-hl-' + args['oldItem']);
						if (args['hl'] !== false) {
							vm.checkHlTitle();
							if (oldHl.length > 0) {
								oldHl.replaceWith(response[0].renderedHl);
							} else {
								vm.$entryHl.prepend(response[0].renderedHl);
							}
						} else {
							if (typeof (args['oldItem']) !== 'undefined') {
								oldHl.remove();
							}
						}
					}
					vm.theQueue();
				},
				fail: function (response) {
					console.log('ERROR:', response );
				}
			});
		},
		jumphl: function (e) {
			e.preventDefault();
			var anchor = $(this).attr('href');
			letsLiveBlog.hash = anchor;
			if ( typeof $(anchor)[0] === 'undefined' ) {
				letsLiveBlog.hashRun = $('.lets-live-blog-pagi');
				letsLiveBlog.$pagi.trigger('click');
			} else {
				$(anchor)[0].scrollIntoView({ block: 'start', behavior: 'smooth' });
			}
		},
		pagi: function (e) {
			e.preventDefault();
			var _this = $(this),
			$data = _this.data(),
			start = new Date( $data.start ).getTime();
			$.ajax({
				method: "GET",
				url: letsLiveBlogJs.root_full + 'pagi',
				data: {
					data: $data,
				},
				beforeSend: function (xhr) {
					xhr.setRequestHeader('X-WP-Nonce', letsLiveBlogJs.nonce);
				},
				success: function (response) {
					var hashFinish = false;
					if( new Date( response[response.length - 1].data.comment_date ).getTime() <= start ) {
						_this.parent().addClass('lets-live-blog-end');
						hashFinish = true;
					}
					$.each(response, function() {
						letsLiveBlog.$entryWrap.append( this.rendered);
					});
					if ( letsLiveBlog.hashRun !== false ) {
						if ( $( letsLiveBlog.hash ).length === 0 ) {
							letsLiveBlog.hashRun.click();
						} else {
							$( letsLiveBlog.hash )[0].scrollIntoView({ block: 'start' });
							letsLiveBlog.hashFinish = true;
						}
					}
					_this.data('date', response[response.length - 1].data.comment_date );
					if ( hashFinish === true ) {
						letsLiveBlog.hashRun = false;
					}
				},
				fail: function (response) {
					console.log('ERROR:', response );
				}
			});
		},
		checkHlTitle: function () {
			if (this.higlightTitleLdd !== true) {

				if (!this.$entryHl.prev().hasClass('box-pre-title')) {
					this.$entryHl.before('<div class="box-pre-title">' + letsLiveBlogJs.data.i18n.jumphl + '</div>');
				}
				this.higlightTitleLdd = true;
			}
		},
		ajaxUpdates: function (item) {
			this.ajaxAdd({ item: item[1], pos: item[2], hl: item[3], oldItem: item[4] });
		},
		ajaxRemove: function (item) {
			$('#live-feed-' + item).remove();
			$('#live-feed-hl-' + item).remove();
			this.theQueue();
		},
		ajaxUpdate: function () {
			var vm = this;
			setInterval(function () {
				vm.ajaxCheck();
			}, letsLiveBlogJs.data.timeInterval);
		},
		resize: function (el, value) {
			this.cacheData();
		},

	};

	letsLiveBlog.init();

})(jQuery);
