<?php
/**
 *
 * Lets Info Up internationalization
 *
 * @since      1.0.0
 *
 * @package    Lets Info Up
 * @subpackage lets-info-up/includes
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}
class Lets_Info_Up_i18n {
	/**
	 * Admin Constructor
	 *
	 * @since 1.0.0
	 *
	*/
	public function __construct( $dir_path ) {

		$this->dir_path = $dir_path;

	}

	/**
	 * Lets Info Up Translation
	 *
	 * @since    1.0.0
	 */
	public function lets_info_up_textdomain() {

		load_plugin_textdomain( 'lets-info-up', false, dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/');

	}

}
