<?php
/**
 *
 * Lets Info Up
 *
 * @since      1.0.0
 *
 * @package    Lets Info Up
 * @subpackage lets-info-up/inc
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

class Lets_Info_Up {

	public static function init() {
		$class = __CLASS__;
		new $class();
	}

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	*/
	public function __construct() {

		$this->version  = '1.4.7';
		$this->slug     = 'lets-info-up';
		$this->url      = plugin_dir_url( dirname( __FILE__ ) );
		$this->dir_path = plugin_dir_path( dirname( __FILE__ ) );
		$this->lets_info_up_loader();
		$this->lets_info_up_locale();
		$this->lets_info_up_frontend();

		if ( is_admin() ) {
			$this->lets_info_up_backend();
			add_action( 'load-post.php', array( $this, 'lets_info_up_metabox_init' ) );
			add_action( 'load-post-new.php', array( $this, 'lets_info_up_metabox_init' ) );
		}

		add_action( 'widgets_init', array( $this, 'lets_info_up_widgets' ) );
	}

	/**
	 * Let's Info Up Widget
	 *
	 * @since 1.0.0
	 */
	public function lets_info_up_widgets() {
		require plugin_dir_path( dirname( __FILE__ ) ) . 'admin/class-lets-info-up-widget.php';
		register_widget( 'Lets_Info_Up_Widget' );
	}

	/**
	 * Lets Info Up Loader
	 *
	 * @since 1.0.0
	 */
	private function lets_info_up_loader() {
		require_once $this->dir_path . 'admin/class-lets-info-up-options.php';
		require_once $this->dir_path . 'admin/class-lets-info-up-admin.php';
		require_once $this->dir_path . 'admin/class-lets-info-up-meta.php';
		require_once $this->dir_path . 'admin/class-lets-info-up-shortcodes.php';
		require_once $this->dir_path . 'admin/class-lets-info-up-block.php';
		require_once $this->dir_path . 'admin/lets-info-up-meta.php';
		require_once $this->dir_path . 'inc/class-lets-info-up-i18n.php';
		require_once $this->dir_path . 'frontend/class-lets-info-up-frontend.php';
	}

	/**
	 * Lets Info Up Initialize
	 *
	 * @since    1.0.0
	 */
	function lets_info_up_metabox_init() {
		$meta = lets_info_up_meta( $this->url . 'admin/images/' );
		if ( class_exists( 'Zeen_Engine' ) ) {
			new Zeen_Engine_Metabox( $meta );
		} else {
			new Lets_Info_Up_Metabox( $meta );
		}
	}

	/**
	 * Lets Info Up Backend Loader
	 *
	 * @since    1.0.0
	 */
	private function lets_info_up_backend() {

		$admin = new Lets_Info_Up_Admin( $this->slug, $this->version, $this->url );
		add_action( 'admin_enqueue_scripts', array( $admin, 'scripts' ) );

	}

	/**
	 * Lets Info Up Frontend Loader
	 *
	 * @since    1.0.0
	 */
	private function lets_info_up_frontend() {

		$frontend = new Lets_Info_Up_Frontend( $this->slug, $this->version, $this->url );
		add_filter( 'the_content', array( $frontend, 'append' ) );
		add_action( 'wp_enqueue_scripts', array( $frontend, 'frontend_scripts' ) );
		$shortcodes = new Lets_Info_Up_Shortcodes( $this->slug, $this->version, $this->url );
		add_shortcode( 'letsinfoup', array( $shortcodes, 'lets_info_up_shortcode' ) );
		$block = new Lets_Info_Up_Block( $this->slug, $this->version, $this->url );
		add_action( 'init', array( $block, 'lets_info_up_editor_assets' ) );
		add_filter( 'block_categories', array( $block, 'lets_info_up_block_category' ), 10, 2 );
	}

	/**
	 * Lets Info Up Translation Loader
	 *
	 * @since 1.0.0
	 */
	public function lets_info_up_locale() {

		$i18n = new Lets_Info_Up_i18n( $this->dir_path );
		add_action( 'init', array( $i18n, 'lets_info_up_textdomain' ) );

	}
}
