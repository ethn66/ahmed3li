<?php
/**
 * Zeen stylish articles
 *
 * @since 1.0.0
 *
 * @see WP_Widget
 */
class Lets_Info_Up_Widget extends WP_Widget {

	/**
	 * Sets up a new widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct() {
		$widget_ops = array(
			'classname' => 'lets_info_up',
			'description' => esc_html__( 'Show product release dates.', 'lets-info-up' ),
			'customize_selective_refresh' => true,
		);

		parent::__construct( 'lets_info_up', esc_html__( "Let's Info Up", 'lets-info-up' ), $widget_ops );
		if ( is_active_widget( false, false, $this->id_base ) || is_customize_preview() ) {
			add_action( 'wp_enqueue_scripts', array( $this, 'scripts' ) );
		}
	}

	/**
	 * Outputs the content for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $args     Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current widget instance.
	 */
	public function widget( $args, $instance ) {

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title      = apply_filters( 'widget_title', empty( $instance['title'] ) ? '' : $instance['title'], $instance, $this->id_base );
		$number     = ! empty( $instance['number'] ) ? absint( $instance['number'] ) : 4;
		$cpts = get_post_types( array( 'public' => true, '_builtin' => false ) );
		$pids = ! empty( $instance['pids'] ) ? $instance['pids'] : '';
		$cpts[] = 'post';
		$cpts[] = 'page';

		$i = 1;
		$qry_args = array(
			'post_type' => $cpts,
			'posts_per_page' => $number,
			'post_status' => 'publish',
			'no_found_rows' => true,
			'ignore_sticky_posts' => true,
		);
		if ( ! empty( $pids ) ) {
			$pids = explode( ',', $pids );
			$qry_args['post__in'] = $pids;
			$qry_args['orderby'] = 'post__in';
		} else {
			$qry_args['meta_key'] = 'lets_info_up_release_date';
			$qry_args['orderby'] = 'meta_value_num';
			$qry_args['meta_query'] = array(
				'relation' => 'AND',
				array(
					'key' => 'lets_info_up_release_date',
					'compare' => '>',
					'value' => 0,
				),
				array(
					'key' => 'lets_info_up_onoff',
					'value' => 'on',
					'compare' => '=',
				),
			);
		}
		$qry = new WP_Query( $qry_args );
		if ( $qry->have_posts() ) :
			echo ( $args['before_widget'] );
			if ( ! empty( $title ) ) {
				echo ( $args['before_title'] . $title . $args['after_title'] );
			}
			echo '<div class="lets-info-up-widget-wrap">';
			while ( $qry->have_posts() ) : $qry->the_post();
				global $post;
				$pid = $post->ID;
				$title = get_post_meta( $pid, 'lets_info_up_title', true );
				if ( empty( $title ) ) {
					$title = get_the_title( $pid );
				}
				$thumb_id = get_post_meta( $pid, '_thumbnail_id', true );
				?><article class="lets-info-up-entry clearfix <?php if ( ! empty( $thumb_id ) ) { echo ' no-fi'; }; ?>">
					<?php if ( ! empty( $thumb_id ) ) { ?>
						<div class="mask">
							<?php echo get_the_post_thumbnail( $pid, array( 370, 247 ) ); ?>
						</div>
					<?php } ?>
					<div class="meta">
						<div class="release-date"><?php echo esc_attr( get_post_meta( $pid, 'lets_info_up_release_date', true ) ); ?></div>
						<h4 class="title"><a href="<?php the_permalink(); ?>"><?php echo esc_attr( $title ) ?></a></h4>
					</div>
					<a href="<?php the_permalink(); ?>" class="lets-info-up-widget-overlay">
					</a>
				</article><?php
			endwhile;
			echo '</div>';
			echo ( $args['after_widget'] );
		endif;
		wp_reset_postdata();
	}

	/**
	 * Handles updating settings for the current widget instance.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 * @return array Settings to save or bool false to cancel saving.
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;
		$instance['title']      = sanitize_text_field( $new_instance['title'] );
		$instance['number']     = intval( $new_instance['number'] );
		$instance['pids']     = esc_attr( $new_instance['pids'] );
		return $instance;
	}

	/**
	 * Outputs the widget settings form.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @param array $instance Current settings.
	 */
	public function form( $instance ) {
		$n = 0;
		$instance = wp_parse_args( (array) $instance, array(
			'title' => '',
			'pids' => '',
			'number' => 4,
		) );
		?>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"><?php esc_html_e( 'Title', 'lets-info-up' ); ?></label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>" type="text" value="<?php echo esc_attr( sanitize_text_field( $instance['title'] ) ); ?>" /></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>"><?php esc_html_e( 'Number of posts to show:', 'lets-info-up' ); ?></label>
		<input class="tiny-text" id="<?php echo esc_attr( $this->get_field_id( 'number' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'number' ) ); ?>" type="number" step="1" min="1" value="<?php echo absint( $instance['number'] ); ?>" size="3" /></p>
		<p><label for="<?php echo esc_attr( $this->get_field_id( 'pids' ) ); ?>">Post/Page IDs</label>
		<input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'pids' ) ); ?>" name="<?php echo esc_attr( $this->get_field_name( 'pids' )); ?>" type="text" value="<?php echo esc_attr( sanitize_text_field( $instance['pids'] ) ); ?>" /><br><small><?php esc_html_e( 'Separate by comma. Order you use will output.', 'lets-info-up' ); ?></small></p>


		<?php
	}

	function scripts() {
		wp_enqueue_style( 'lets-info-up-widget', esc_url( LETS_INFO_UP_DIR_URL . 'frontend/css/style-widget.min.css' ), array(), '1.4.7', 'all' );
	}
}
