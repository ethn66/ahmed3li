<?php
/**
 *
 * Lets Info Up Admin
 *
 * @since      1.0.0
 *
 * @package    Lets Info Up
 * @subpackage lets-info-up/admin
 */

class Lets_Info_Up_Admin {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	*/
	public function __construct( $slug, $version, $url ) {
		$this->slug = $slug;
		$this->version = $version;
		$this->url = $url;
		add_action( 'after_setup_theme', array( $this, 'lets_info_up_thumbnails' ) );
	}

	/**
	 * Scripts
	 *
	 * @since    1.0.0
	 */
	public function scripts( $pagenow ) {

		if ( ( $pagenow == 'post.php' || $pagenow == 'post-new.php' ) && ! class_exists( 'Zeen_Engine' ) ) {
			wp_enqueue_style( 'wp-color-picker' );
			wp_enqueue_script('jquery-ui-core');
			wp_enqueue_script('jquery-ui-slider');
			wp_enqueue_script( 'jquery-ui-datepicker' );
			wp_enqueue_media();

			wp_enqueue_style( $this->slug, esc_url( $this->url  . 'admin/css/admin-style.min.css' ), array(), $this->version, 'all' );
			wp_enqueue_script( $this->slug . '-js', esc_url( $this->url  . 'admin/js/lets-info-up-admin.js' ), array( 'jquery', 'jquery-ui-datepicker', 'jquery-ui-core', 'wp-color-picker' ), $this->version, true );
			wp_localize_script( $this->slug . '-js', 'letsInfoUpJS', array(
				'i18n' => self::i18n(),
			) );
		}

	}

	public static function i18n() {

		$output = array();

		$output['titleButton']       = esc_html__( 'Insert', 'lets-info-up' );
		$output['titleModal']        = esc_html__( 'Select Image', 'lets-info-up' );
		$output['titleGalleryModal'] = esc_html__( 'Select or Upload Images', 'lets-info-up' );

		return $output;
	}

	function lets_info_up_thumbnails() {
		add_image_size( 'lets-info-up-d1', 500, '', false );
	}
}
