<?php
/**
 * Metaboxes
 *
 * @package     Lets_Info_Up
 * @copyright   Copyright Codetipi
 * @since       1.0.0
 */

/**
 * Metabox Class init
 *
 * @since  1.0.0
 */
function lets_info_up_meta( $src_uri ) {

	$post_types = get_post_types(
		array(
			'public'   => true,
			'_builtin' => false,
		)
	);

	$post_types[]       = 'post';
	$post_types[]       = 'page';
	$post_types_formats = $post_types;
	unset( $post_types['product'] );

	return array(
		'src_uri'   => $src_uri,
		'post_type' => $post_types,
		'id'        => 'lets-info-up-options',
		'prefix'    => 'lets_info_up',
		'title'     => esc_html__( "Let's Info Up Options", 'lets-info-up' ),
		'args'      => array(
			array(
				'control' => 'on-off',
				'id'      => 'onoff',
				'title'   => esc_html__( 'Enable info box', 'lets-info-up' ),
				'default' => 'off',
			),
			array(
				'control'  => 'radio-images',
				'id'       => 'design',
				'title'    => esc_html__( 'Info Box Design', 'lets-info-up' ),
				'default'  => 1,
				'choices'  => array(
					1 => array( 'url' => 'lets-info-up-1.png' ),
					2 => array( 'url' => 'lets-info-up-2.png' ),
				),
				'required' => array(
					'id'    => 'onoff',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'text',
				'id'       => 'title',
				'title'    => esc_html__( 'Main Title', 'lets-info-up' ),
				'default'  => '',
				'required' => array(
					'id'    => 'onoff',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'image',
				'id'       => 'fi',
				'title'    => esc_html__( 'Main Image', 'lets-info-up' ),
				'default'  => '',
				'choices'  => array(
					'type' => 'id',
				),
				'required' => array(
					'id'    => 'onoff',
					'value' => 'on',
				),
			),
			array(
				'control'     => 'on-off',
				'id'          => 'location',
				'title'       => esc_html__( 'Info Box Automatic Insert', 'lets-info-up' ),
				'description' => esc_html__( 'To insert the info box somewhere specific, disable this option and use this shortcode: [letsinfoup]', 'lets-info-up' ),
				'default'     => 'on',
				'required'    => array(
					'id'    => 'onoff',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'select',
				'id'       => 'mobile-design',
				'title'    => esc_html__( 'Mobile Design', 'lets-info-up' ),
				'default'  => 1,
				'choices'  => array(
					1 => esc_attr__( 'Same as desktop', 'lets-info-up' ),
					2 => esc_attr__( 'Full Width', 'lets-info-up' ),
				),
				'required' => array(
					'id'    => 'onoff',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'select',
				'id'       => 'skin',
				'title'    => esc_html__( 'Skin', 'lets-info-up' ),
				'default'  => 1,
				'choices'  => array(
					1 => esc_attr__( 'Light', 'lets-info-up' ),
					2 => esc_attr__( 'Dark', 'lets-info-up' ),
					3 => esc_attr__( 'Custom', 'lets-info-up' ),
				),
				'required' => array(
					'id'    => 'onoff',
					'value' => 'on',
				),
			),

			array(
				'control'  => 'color',
				'id'       => 'custom-skin',
				'title'    => esc_html__( 'Custom skin color', 'lets-info-up' ),
				'default'  => '#fff',
				'required' => array(
					'id'    => 'skin',
					'value' => 3,
				),
			),
			array(
				'control'  => 'color',
				'id'       => 'custom-skin-text',
				'title'    => esc_html__( 'Custom text color', 'lets-info-up' ),
				'default'  => '#000',
				'required' => array(
					'id'    => 'skin',
					'value' => 3,
				),
			),
			array(
				'control'        => 'date',
				'id'             => 'release-date',
				'title'          => esc_html__( 'Release Date (If Applicable)', 'lets-info-up' ),
				'default'        => '',
				'global'         => 'empty',
				'global_removal' => 'empty',
				'required'       => array(
					'id'    => 'onoff',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'drag',
				'id'       => 'blocks',
				'title'    => esc_html__( 'Info Blocks', 'lets-info-up' ),
				'default'  => '',
				'choices'  => array(
					1 => array(
						'name'  => 'title',
						'title' => esc_attr__( 'Info Title', 'lets-info-up' ),
						'type'  => 'text',
					),
					2 => array(
						'name'  => 'content',
						'title' => esc_attr__( 'Info Content', 'lets-info-up' ),
						'type'  => 'text',
					),
				),
				'required' => array(
					'id'    => 'onoff',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'text',
				'id'       => 'aff-title',
				'title'    => esc_html__( 'Affiliate Main Title', 'lets-info-up' ),
				'default'  => '',
				'required' => array(
					'id'    => 'onoff',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'drag',
				'id'       => 'aff',
				'title'    => esc_html__( 'Affiliate buttons', 'lets-info-up' ),
				'default'  => '',
				'choices'  => array(
					1 => array(
						'name'  => 'title',
						'title' => esc_attr__( 'Button Title', 'lets-info-up' ),
						'type'  => 'text',
					),
					2 => array(
						'name'  => 'url',
						'title' => esc_attr__( 'Button Link', 'lets-info-up' ),
						'type'  => 'text',
					),
				),
				'required' => array(
					'id'    => 'onoff',
					'value' => 'on',
				),
			),
			array(
				'control'  => 'on-off',
				'id'       => 'newwindow',
				'title'    => esc_html__( 'Open links in new window', 'lets-info-up' ),
				'default'  => 'on',
				'required' => array(
					'id'    => 'onoff',
					'value' => 'on',
				),
			),
		),
	);

}

function lets_info_up_sanitize_wp_kses( $data ) {
	return wp_kses(
		$data,
		array(
			'a'      => array(
				'class'       => array(),
				'rel'         => array(),
				'href'        => array(),
				'style'       => array(),
				'id'          => array(),
				'target'      => array(),
				'data-format' => array(),
				'data-source' => array(),
				'data-type'   => array(),
				'data-src'    => array(),
				'title'       => array(),
			),
			'span'   => array(
				'class' => array(),
				'id'    => array(),
				'style' => array(),
			),
			'p'      => array(
				'class' => array(),
				'id'    => array(),
				'style' => array(),
			),
			'img'    => array(
				'src'    => array(),
				'srcset' => array(),
				'alt'    => array(),
			),
			'div'    => array(
				'class' => array(),
				'id'    => array(),
				'style' => array(),
			),
			'i'      => array(
				'class' => array(),
				'id'    => array(),
				'style' => array(),
			),
			'u'      => array(
				'class' => array(),
				'id'    => array(),
				'style' => array(),
			),
			'br'     => array(),
			'b'      => array(
				'style' => array(),
			),
			'em'     => array(
				'class' => array(),
				'style' => array(),
			),
			'strong' => array(
				'class' => array(),
				'style' => array(),
			),
			'italic' => array(
				'class' => array(),
				'style' => array(),
			),
		)
	);
}
function lets_info_up_sanitize_titles( $data ) {

	return wp_kses(
		$data,
		array(
			'span'   => array(
				'class' => array(),
			),
			'div'    => array(
				'class' => array(),
			),
			'br'     => array(),
			'em'     => array(),
			'strong' => array(),
		)
	);

}

/**
 * Sanitizer Commas
 *
 * @since  1.0.0
 */
function lets_info_up_sanitize_num_commas( $data ) {

	$data = filter_var( $data, FILTER_SANITIZE_NUMBER_FLOAT, FILTER_FLAG_ALLOW_FRACTION | FILTER_FLAG_ALLOW_THOUSAND );
	return $data;

}

/**
 * Sanitizer Array
 *
 * @since  1.0.0
 */
function lets_info_up_sanitize_array( $array ) {

	if ( ! is_array( $array ) ) {
		return array();
	}

	foreach ( $array as $key => $value ) {

		if ( is_array( $value ) ) {
			$array[ $key ] = lets_info_up_sanitize_array( $value );
		} else {
			$array[ $key ] = esc_attr( $value );
		}
	}

	return $array;
}

/**
 * Sanitizer Floats
 *
 * @since  1.0.0
 */
function lets_info_up_sanitizer_float( $data ) {
	return floatval( $data );
}

