<?php
/**
 *
 * Lets Info Up Block
 *
 * @since      1.1.0
 *
 * @package    Lets Info Up
 * @subpackage lets-info-up/admin
 */

class Lets_Info_Up_Block {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	*/
	public function __construct( $slug = '', $version = '', $url = '' ) {
		$this->slug    = $slug;
		$this->version = $version;
		$this->url     = $url;
	}

	/**
	 * Enqueue assets
	 *
	 * @since 1.0.0
	 */
	function lets_info_up_editor_assets() {
		wp_register_script(
			'lets-info-up-block-editor',
			plugins_url( 'block/build/index.js', __FILE__ ),
			array( 'wp-block-editor', 'wp-blocks', 'wp-element', 'wp-i18n', 'wp-polyfill' ),
			$this->version
		);
		wp_set_script_translations( 'lets-info-up-block-editor', 'lets-info-up' );

		wp_register_style(
			'lets-info-up-block-editor',
			plugins_url( 'block/build/index.css', __FILE__ ),
			array(),
			$this->version
		);

		$rtl = is_rtl() ? '-rtl' : '';
		wp_register_style(
			'lets-info-up-block',
			esc_url( $this->url . 'frontend/css/style.min' . $rtl . '.css' ),
			array(),
			$this->version
		);

		register_block_type(
			'lets-info-up/block-info',
			array(
				'editor_script'   => 'lets-info-up-block-editor',
				'editor_style'    => 'lets-info-up-block-editor',
				'style'           => 'lets-info-up-block',
				'render_callback' => array( $this, 'lets_info_up_callback' ),
			)
		);
	}

	function lets_info_up_block_category( $categories, $post ) {
		return array_merge(
			$categories,
			array(
				array(
					'slug'  => 'lets-info-up-blocks',
					'title' => __( "Let's Info Up", 'lets-info-up-blocks' ),
				),
			)
		);
	}

	function lets_info_up_callback( $attr = '' ) {
		$output = new Lets_Info_Up_Frontend();
		return $output->block_output( $attr );
	}

}
