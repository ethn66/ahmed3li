<?php
/**
 * Lets Info Up options
 *
 * @package     Lets_Info_Up
 * @copyright   Copyright Codetipi
 * @since       1.0.0
 */
class Lets_Info_Up_Options {

	/**
	 * Options
	 *
	 * @since    1.0.0
	 */
	static $lets_info_up_options;

	/**
	 * Options getter
	 *
	 * @since    1.0.0
	 */
	static function lets_info_up_get_option( $option = 'lets_info_up_options' ) {

		self::$lets_info_up_options = get_option( $option, array() );

	}

	/**
	 * Options setter
	 *
	 * @since    1.0.0
	 */
	static function lets_info_up_update_option() {

		$options = self::lets_info_up_sanitized();
		update_option( 'lets_info_up_options', $options );
		self::$lets_info_up_options = get_option( 'lets_info_up_options' );

	}

	/**
	 * Options sanitizer
	 *
	 * @since    1.0.0
	 */
	private static function lets_info_up_sanitized( $option = '' ) {

		$option = empty( $option ) ? self::$lets_info_up_options : $option;
		$sanitized_array = array();
		if ( ! is_array( $option ) ) {
			return array();
		}

		foreach ( $option as $key => $value ) {

			if ( ! is_array( $value ) && ! is_object( $value ) ) {
				$sanitized_array[ esc_html( $key ) ] = esc_attr( $value );
			}

			if ( is_array( $value ) && ! empty( $value ) ) {
				$sanitized_array[ esc_html( $key ) ] = self::lets_info_up_sanitized( $value );
			}
		}

		return $sanitized_array;
	}

}

Lets_Info_Up_Options::lets_info_up_get_option();
