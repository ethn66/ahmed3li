/**
 * Copyright: Codetipi
 * Theme: Lets Info Up
 * Version: 1.4.7
 */

(function( $ ) { 'use strict';
	var letsInfoUpAdmin = {
		init: function() {
			this.cacheDom();
			this.bindEvents();
			this.colorPicker();
			this.dragDrop();
			this.required();
			this.slider();
			this.dates();
		},
		cacheDom: function() {
			this.$doc				= $( document );
			this.$body				= $( 'body' );
			this.$colorPicker 		= $( '.lets-info-up-color-pick' );
			this.$slider			= $( '.lets-info-up-slider' );
			this.$sliderReset		= $( '.lets-info-up-slider-wrap .lets-info-up-reset' );
			this.$sectionShower		= $( '.lets-info-up-metabox-wrap .lets-info-up-trig' );
			this.$metaboxControls	= $( '.lets-info-up-metabox-controls' );
			this.$upload			= $( '.lets-info-up-upload' );
			this.$galleryUpload		= $( '.lets-info-up-gallery' );
			this.$required			= $( '.lets-info-up-req' );
			this.$dragDrop			= $( '.lets-info-up-drag-drop' );

			this.modal 				= false;
			this.galleryModal		= false;
			this.debug				= false;
			this.$dates				= $( '.lets-info-up-date-field' ).find( 'input' );
			this.$dateTimes			= $( '.lets-info-up-date-time-field' ).find( 'input' );
		},
		bindEvents: function() {
			this.$sliderReset.on( 'click', this.sliderReset );
			this.$sectionShower.on( 'click', this.sectionShower );
			this.$upload.on( 'click', this.upload );
			this.$galleryUpload.on( 'click', this.galleryUpload );
			this.$body.on( 'click', '.lets-info-up-remove', this.uploadRemove );
			this.$body.on( 'click', '.lets-info-up-remove-gallery', this.parentRemove );
			this.$body.on( 'change', '.lets-info-up-required', this.requiredCheck );
			this.$body.on( 'click', '.lets-info-up-drag-x', this.dragRemove );
			this.$body.on( 'click', '.lets-info-up-drag-add', this.dragAdd );

		},
		// Drag
		dragRemove: function( e ) {
			e.preventDefault();
			$(this).parent().remove();
		},
		dates: function() {
			if ( this.$dates.length > 0 ) {
				this.$dates.datepicker({
					beforeShow: function(input, inst) {
					   $('#ui-datepicker-div').addClass('lets-info-up-date-box-wrap');
					   },
					showOtherMonths: true,
					closeText: letsInfoUpJS.i18n.close,
					currentText: letsInfoUpJS.i18n.now,
					prevText: '<span class="dashicons dashicons-arrow-left-alt2"></span>',
					nextText: '<span class="dashicons dashicons-arrow-right-alt2"></span>'
				  });
			}
			if ( this.$dateTimes.length > 0 ) {
				this.$dateTimes.datetimepicker({
					beforeShow: function(input, inst) {
					   $('#ui-datepicker-div').addClass('lets-info-up-date-box-wrap');
					   },
					showOtherMonths: true,
					closeText: letsInfoUpJS.i18n.close,
					currentText: letsInfoUpJS.i18n.now,
					prevText: '<span class="dashicons dashicons-arrow-left-alt2"></span>',
					nextText: '<span class="dashicons dashicons-arrow-right-alt2"></span>'
				  });
			}
		},
		// Drag
		dragAdd: function( e ) {
			e.preventDefault();
			var $adder = $(this),
				$addParent = $adder.parent(),
				$dragDummy = $addParent.find( '> .lets-info-up-drag-el-dummy' ),
				$dragWarp = $addParent.find( '> .lets-info-up-drag-drop' );

			$dragWarp.data( 'count', $dragWarp.data('count') + 1 );

			var $theClone = $dragDummy.find('> div').clone();

			var $theCloneData = $theClone.find( '.lets-info-up-data' );
			$theCloneData.each( function() {
			    var el = $(this);
			    el.removeClass('lets-info-up-data');
			    var elName = el.data('name') + '[' + $dragWarp.data('count') + ']' + '[' + el.data('choice') + ']';
			    el.attr('name', elName );
			});

			$theClone.appendTo( $dragWarp );
			$theClone.find('input:first').focus();
		},
		// Drag
		dragDrop: function() {
			this.$dragDrop.sortable({
			  	placeholder: "ui-state-highlight",
				classes: {
					"ui-sortable": "lets-info-up-control-only"
				},
				start: function( e, ui ){
			        ui.placeholder.height( ui.item.height() );
			    }
			});
			this.$dragDrop.disableSelection();
		},
		requiredCheck: function ( e, el ) {

			var $reqCheckThis =  typeof el === 'undefined' ? $(this) : $(el);
			$reqCheckThis.each( function() {
				var $reqCheckEachThis = $( this );
				var $reqCheck = $reqCheckEachThis.closest('.lets-info-up-control');
				var $reqCheckControl = $reqCheck.data('control');

				switch( $reqCheckControl ) {
				    case 'on-off':

				    	$reqCheckEachThis.data('dependees').forEach( function(dependee) {
						    if ( ( $reqCheckEachThis.is(":checked") === true ) && ( dependee.val === 'on' ) ) {
								letsInfoUpAdmin.showIt( $('#' + dependee.id ), e );
							} else if ( ( $reqCheckEachThis.is(":checked") === false ) && ( dependee.val === 'on' ) ) {
								letsInfoUpAdmin.hideIt( $('#' + dependee.id ), e );
							}

							if ( ( $reqCheckEachThis.is(":checked") === false ) && ( dependee.val === 'off' ) ) {
								letsInfoUpAdmin.showIt( $('#' + dependee.id ), e );
							} else if ( ( $reqCheckEachThis.is(":checked") === true ) && ( dependee.val === 'off' ) ) {
								letsInfoUpAdmin.hideIt( $('#' + dependee.id ), e );
							}
						});

				        break;
				    case 'radio-images':

				    	$reqCheckEachThis.data('dependees').forEach( function(dependee) {

				    		if ( dependee.val.length > 1 ) {
				    			for( var i = 0, len = dependee.val.length; i < len; i++){
									dependee.val[i] = dependee.val[i].toString();
								}

					    		if ( $reqCheckEachThis.is(':checked') === true && $.inArray(  $reqCheckEachThis.val(), dependee.val ) != -1 ) {
					    			letsInfoUpAdmin.showIt( $('#' + dependee.id ), e );
					    		} else {
					    			if ( typeof el === 'undefined' ) {
					    				letsInfoUpAdmin.hideIt( $('#' + dependee.id ), e );
					    			}
								}

				    		} else {

				    			if ( ( $reqCheckEachThis.is(':checked') === true ) && ( $reqCheckEachThis.val() == dependee.val ) ) {
					    			letsInfoUpAdmin.showIt( $('#' + dependee.id ), e );
					    		} else {
					    			if ( typeof el === 'undefined' ) {
					    				letsInfoUpAdmin.hideIt( $('#' + dependee.id ), e );
					    			}
								}
				    		}
						});

				        break;
				    case 'select':

				    	$reqCheckEachThis.data('dependees').forEach( function(dependee) {

				    		if ( ( $reqCheckEachThis.val() ) == dependee.val ) {
				    			letsInfoUpAdmin.showIt( $('#' + dependee.id ), e );
				    		} else {
				    			if ( typeof el === 'undefined' ) {
				    				letsInfoUpAdmin.hideIt( $('#' + dependee.id ), e );
				    			}
							}

						});

				        break;
				    default:

				}
			});

		},
		showIt: function ( el, e ) {
			if ( typeof e !== 'undefined' ) {
				el.slideDown(100);
				return;
			}
			el.show();
		},
		hideIt: function ( el, e ) {
			if ( typeof e !== 'undefined' ) {
				el.slideUp(100);
				return;
			}
			el.hide();
		},
		required: function ( e ) {
			this.$required.each( function() {
				var $reqThis = $(this);
				var $reqVal = $(this).data('req-val');
				var $reqId = $reqThis.attr('id');
				var $req = $reqThis.data('req');
				var $reqInputVal = $( '#' + $req ).find('.lets-info-up-input-val');

				$reqInputVal.addClass('lets-info-up-required');


				if ( typeof $reqInputVal.data('dependees') === 'undefined' ) {
					$reqInputVal.data('dependees', [ { id: $reqId, val: $reqVal } ] );
				} else {
					var $reqArray = $reqInputVal.data('dependees');
					$reqArray.push( { id: $reqId, val: $reqVal } );
					$reqInputVal.data('dependees', $reqArray );
				}

			});
			letsInfoUpAdmin.requiredCheck(e, '.lets-info-up-required');
		},
		uploadRemove: function( e ) {
			e.preventDefault();

			var uploadThis = $(this);
			uploadThis.closest('.lets-info-up-meta-control').find('.lets-info-up-img-input').val('');
			var letsInfoUpVisSwitch 	= uploadThis.closest('.lets-info-up-meta-control').find('.lets-info-up-vis-switch');
			if ( letsInfoUpVisSwitch.length ) {
				letsInfoUpVisSwitch.addClass('lets-info-up-hide');
			}
			letsInfoUpAdmin.parentRemove(e, uploadThis);
		},
		parentRemove: function( e, el ) {
			e.preventDefault();

			if ( typeof el !== 'undefined' ) {
				el.parent().remove();
			} else {
				$( this ).parent().remove();
			}
		},
		upload: function( e ) {
		 	e.preventDefault();
		 	var letsInfoUpDest 		= $( '#' + $(this).data( 'dest' ) ),
		 		letsInfoUpOutput 	= $(this).data( 'output' ),
		 		letsInfoUpFileType	= $(this).data( 'file-type' ),
		 		letsInfoUpVisSwitch 	= letsInfoUpDest.find('.lets-info-up-vis-switch');

			letsInfoUpAdmin.modal = wp.media({
				title: letsInfoUpJS.i18n.titleModal,
				button: {
					text: letsInfoUpJS.i18n.titleButton,
				},
				multiple: false
			});

		    letsInfoUpAdmin.modal.on( 'select', function() {
	        	var letsInfoUpImg = letsInfoUpAdmin.modal.state().get('selection').first().toJSON();
	        	if ( letsInfoUpFileType === 'img' ) {
					var	letsInfoUpImgUrl = typeof letsInfoUpImg.sizes.thumbnail !== undefined ? letsInfoUpImg.sizes.thumbnail.url : letsInfoUpImg.url;

				}

				var letsInfoUpSrcId = letsInfoUpOutput === 'id' ? letsInfoUpImg.id : letsInfoUpImg.url;

				letsInfoUpDest.find('.lets-info-up-img-input').val( letsInfoUpSrcId );
				letsInfoUpDest.find('.lets-info-up-img').remove();
				if ( letsInfoUpFileType === 'img' ) {
		            letsInfoUpDest.find('.lets-info-up-control-only').append( '<span class="lets-info-up-img"><a href="#" class="lets-info-up-remove dashicons dashicons-no"></a><img src="' + letsInfoUpImgUrl + '" alt=""></span>' );
		        }

	            if ( letsInfoUpVisSwitch.length ) {
					letsInfoUpVisSwitch.removeClass('lets-info-up-hide');
				}

			}).open();
		},
		galleryUpload: function( e ) {
		 	e.preventDefault();
		 	var galleryUploadThis = $( this);

			letsInfoUpAdmin.galleryModal = wp.media({
				title: letsInfoUpJS.i18n.titleGalleryModal,
				button: {
					text: letsInfoUpJS.i18n.titleButton,
				},
				multiple: true
			});

		    letsInfoUpAdmin.galleryModal.on( 'select', function(){

	        	var galleryModalModels = letsInfoUpAdmin.galleryModal.state().get("selection").models;

				for ( var letsInfoUpgalleryCounter = 0; letsInfoUpgalleryCounter < galleryModalModels.length; letsInfoUpgalleryCounter++ ) {

					var letsInfoUpGalleryObj = galleryModalModels[letsInfoUpgalleryCounter].toJSON(),
						letsInfoUpGalleryImgUrl = typeof letsInfoUpGalleryObj.sizes.thumbnail !== undefined ? letsInfoUpGalleryObj.sizes.thumbnail.url : letsInfoUpGalleryObj.url;
		            $( '#' + galleryUploadThis.data( 'dest' ) ).find('.lets-info-up-gallery-wrap').append( '<span data-id="' + letsInfoUpGalleryObj.id + '" class="lets-info-up-img"><a href="#" class="lets-info-up-remove-gallery dashicons dashicons-no"></a><img src="' + letsInfoUpGalleryImgUrl + '" alt=""><input type="hidden" value="' + letsInfoUpGalleryObj.id + '" name="' + galleryUploadThis.data( 'name' ) +'[]"></span>' );
		        }

		        letsInfoUpgalleryCounter = 0;

			}).open();
		},
		sectionShower: function( e ) {
			e.preventDefault();
			var letsInfoUpTrig = $('#' + $(this).data('section') );
			letsInfoUpTrig.siblings().addClass('lets-info-up-hide');
			letsInfoUpTrig.removeClass('lets-info-up-hide');
			$(this).siblings().removeClass('lets-info-up-active');
			$(this).addClass('lets-info-up-active');
		},
		colorPicker: function() {
			this.$colorPicker.wpColorPicker();
		},
		slider: function() {
			this.$slider.each( function() {
				var $this = $(this);
		        $this.slider({
			        min: $this.data('min'),
			        max: $this.data('max'),
			        step: $this.data('step'),
			        range: 'min',
			        value: $this.data('value'),
			        slide: function( event, ui ) {
			        	$this.next().val( ui.value );
			        	$this.next().next().find('.lets-info-up-val').html( ui.value );
			       }
			    });
			});
		},
		sliderReset: function() {
	        var slider = $(this).closest( '.lets-info-up-control' ).find( '.lets-info-up-slider' );
	        var defaultVal = slider.data( 'default' );
	        slider.slider({
	            value: defaultVal,
	        });
	        slider.next().val( defaultVal );
	        slider.next().next().find('.lets-info-up-val').html( defaultVal );
		}
	};

	letsInfoUpAdmin.init();

} )( jQuery );