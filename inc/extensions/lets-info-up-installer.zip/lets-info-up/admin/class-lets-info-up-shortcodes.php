<?php
/**
 * Let's Info Up shortcode Class
 *
 * @package     Lets_Info_Up
 * @copyright   Copyright Codetipi
 * @since       1.0.0
 */

class Lets_Info_Up_Shortcodes {

	/**
	 * Shortcode output
	 *
	 * @since 1.0.0
	 * @return Review output
	 */
	public function lets_info_up_shortcode( $atts, $content = '' ) {

		if ( ! isset( $atts['postid'] ) ) {
			$pid = get_the_ID();
			if ( empty( $pid ) && ! empty( (int) $_GET['pid'] ) ) {
				$pid = (int) $_GET['pid'];
			}
		} else {
			$pid = $atts['postid'];
		}
		$frontend = new Lets_Info_Up_Frontend();
		return $frontend->output(
			array(
				'echo' => false,
				'pid'  => $pid,
			)
		);
	}

}
