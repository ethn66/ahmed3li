<?php
/*!
Plugin Name: Let's Info Up
Plugin URI: https://codetipi.com
Author: Codetipi
Author URI: https://codetipi.com
Description: The ultimate info plugin for WordPress
Version: 1.4.7
Text Domain: lets-info-up
License: http://codecanyon.net/licenses/regular_extended
License URI: http://codecanyon.net/licenses/regular_extended
Requires at least: 4.8
Tested up to: 5.5.0
Domain Path: /languages/
*/

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

require plugin_dir_path( __FILE__ ) . 'inc/class-lets-info-up.php';
$url = plugin_dir_url( __FILE__ );
define( 'LETS_INFO_UP_DIR_URL', $url );
/**
* Let's fire it up
*
* @since 1.0.0
*/
add_action( 'plugins_loaded', array( 'Lets_Info_Up', 'init' ) );
