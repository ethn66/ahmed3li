<?php
/**
 *
 * Frontend Class
 *
 * @since      1.0.0
 *
 * @package    Lets Info Up
 * @subpackage lets-info-up/frontend
 */

class Lets_Info_Up_Frontend {

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 *
	*/
	public function __construct( $slug = '', $version = '', $url = '' ) {
		$this->slug    = $slug;
		$this->version = $version;
		$this->url     = $url;
	}

	/**
	 * Load scripts frontend
	 *
	 * @since    1.0.0
	 */
	public function frontend_scripts() {
		if ( post_password_required() ) {
			return;
		}
		if ( is_singular() ) {
			$pid = get_the_ID();
			$ipl = 2 === (int) get_post_meta( $pid, 'zeen_next_post_auto_load', true ) ? '' : get_theme_mod( 'ipl' );
			if ( ! empty( $ipl ) || $this->enabled() || ( function_exists( 'has_block' ) && has_block( 'lets-info-up/block-info' ) ) ) {
				wp_enqueue_style( 'lets-info-up', esc_url( $this->url . 'frontend/css/style.min.css' ), array(), $this->version, 'all' );
				wp_add_inline_style( 'lets-info-up', $this->extra_style() );
			}
		}
	}

	/**
	 * Frontend
	 *
	 * @since    1.0.0
	 */
	public function append( $content ) {
		if ( post_password_required() ) {
			return $content;
		}
		$pid = get_the_ID();
		if ( $this->enabled() == true && $this->location( $pid ) == 'on' && ( is_single( $pid ) || is_page( $pid ) || ! empty( $_GET['ipl'] ) ) ) {
			$output = $this->output(
				array(
					'echo' => '',
					'pid'  => $pid,
				)
			);
			return $output . $content;
		}

		return $content;

	}

	public function extra_style() {
		$output = '';
		$pid    = get_the_ID();
		if ( get_post_meta( $pid, 'lets_info_up_skin', true ) == 3 ) {
			$skin    = get_post_meta( $pid, 'lets_info_up_custom_skin', true );
			$output .= '.lets-info-up-wrap-' . $pid . ' { background: ' . $skin . '; --liu-color:' . $skin . '; } ';
			$output .= '.lets-info-up-wrap-' . $pid . ', .lets-info-up-wrap-' . $pid . ' a { color: ' . get_post_meta( $pid, 'lets_info_up_custom_skin_text', true ) . '!important; } ';
		}

		return $output;
	}

	function output( $args = array() ) {

		if ( empty( $args['echo'] ) ) {
			ob_start();
		}
		$pid    = empty( $args['pid'] ) ? get_the_ID() : $args['pid'];
		$design = get_post_meta( $pid, 'lets_info_up_design', true );
		$design = empty( $design ) ? 'left' : $design;
		$skin   = get_post_meta( $pid, 'lets_info_up_skin', true );
		$skin   = empty( $skin ) ? 1 : $skin;
		if ( 1 == $design ) {
			$design = 'left';
		} elseif ( 2 == $design ) {
			$design = 'center';
		} elseif ( 3 == $design ) {
			$design = 'right';
		}
		if ( 'right' == $design || 'left' == $design ) {
			$design .= ' lets-info-up--side';
		}
		$mobile_design = get_post_meta( $pid, 'lets_info_up_mobile_design', true );
		$mobile_design = empty( $mobile_design ) ? 1 : $mobile_design;
		$design       .= ' lets-info-up--m-' . $mobile_design;
		?>
		<div class="lets-info-up-wrap lets-info-up-wrap-<?php echo (int) $pid; ?> lets-info-up--<?php echo esc_attr( $design ); ?> lets-info-up-skin-<?php echo (int) $skin; ?>">
			<div class="lets-info-up">
			<?php
			$this->fi(
				array(
					'pid' => $pid,
				)
			);
			?>
			<div class="lets-info-up-block-wrap">
				<?php
				$title = get_post_meta( $pid, 'lets_info_up_title', true );
				$img   = get_post_meta( $pid, 'lets_info_up_fi', true );
				if ( ! empty( $title ) && empty( $img ) ) {
					echo '<div class="lets-info-up-block lets-info-up-main-title">' . esc_attr( $title ) . '</div>';
				}

				$this->blocks(
					array(
						'pid' => $pid,
					)
				);
				$this->aff_blocks(
					array(
						'pid' => $pid,
					)
				);
				?>
			</div>
			</div>
		</div>
		<?php

		if ( empty( $args['echo'] ) ) {
			return ob_get_clean();
		}
	}

	function location( $pid = '' ) {
		$location = get_post_meta( $pid, 'lets_info_up_location', true );
		return empty( $location ) ? 'on' : $location;
	}

	public function enabled( $pid = '' ) {

		if ( empty( $pid ) ) {
			$pid = get_the_ID();
		}

		if ( get_post_meta( $pid, 'lets_info_up_onoff', true ) == 'on' ) {
			return true;
		}

		return false;

	}

	function blocks( $args = array() ) {
		$pid         = empty( $args['pid'] ) ? '' : $args['pid'];
		$blocks      = empty( $args['blocks'] ) ? get_post_meta( $pid, 'lets_info_up_blocks', true ) : $args['blocks'];
		$blocks      = empty( $blocks ) ? array() : $blocks;
		$skin_titles = empty( $args['skin_titles'] ) ? '' : $args['skin_titles'];

		if ( ! empty( $pid ) ) {
			if ( class_exists( 'Lets_Review_API' ) && get_post_meta( $pid, '_lets_review_onoff', true ) == 1 && get_post_meta( $pid, '_lets_review_type', true ) == 1 && apply_filters( 'lets_info_up_show_lets_review', true ) ) {
				$api      = new Lets_Review_API();
				$blocks[] = array(
					'title'   => esc_attr__( 'Our Score', 'lets-info-up' ),
					'content' => $api->lets_review_get_final_score( $pid ),
				);
			}
			$date = get_post_meta( $pid, 'lets_info_up_release_date', true );
			if ( ! empty( $date ) ) {
				array_unshift(
					$blocks,
					array(
						'title'   => esc_attr__( 'Release Date', 'lets-info-up' ),
						'content' => $date,
					)
				);
			}
		}
		if ( ! empty( $blocks ) ) {
			foreach ( $blocks as $key => $value ) {
				echo '<div class="lets-info-up-block lets-info-up-meta-block">';
				if ( ! empty( $value['title'] ) ) {
					echo '<div class="lets-info-up-meta-title lets-info-up-pretitle font-h"';
					if ( ! empty( $skin_titles ) ) {
						echo ' style="color: ' . esc_attr( $skin_titles ) . ';"';
					}
					echo '>' . lets_info_up_sanitize_wp_kses( $value['title'] ) . '</div>';
				}
				if ( ! empty( $value['content'] ) ) {
					echo '<div class="lets-info-up-meta-content lets-info-up-title font-b">' . lets_info_up_sanitize_wp_kses( $value['content'] ) . '</div>';
				}
				echo '</div>';
			}
		}
	}


	function aff_blocks( $args = array() ) {
		$pid         = empty( $args['pid'] ) ? '' : $args['pid'];
		$blocks      = empty( $args['blocks'] ) ? get_post_meta( $pid, 'lets_info_up_aff', true ) : $args['blocks'];
		$blocks      = empty( $blocks ) ? array() : $blocks;
		$skin_text   = empty( $args['skin_text'] ) ? '' : $args['skin_text'];
		$skin_titles = empty( $args['skin_titles'] ) ? '' : $args['skin_titles'];
		if ( ! empty( $pid ) && ! empty( $blocks ) ) {
			$i     = 0;
			$close = '';
			foreach ( $blocks as $key => $value ) {
				if ( empty( $value['title'] ) || empty( $value['url'] ) ) {
					break;
				}
				if ( 0 == $i ) {
					echo '<div class="lets-info-up-block lets-info-up-aff-block">';
					if ( get_post_meta( $pid, 'lets_info_up_aff_title', true ) != '' ) {
						echo '<div class="lets-info-up-aff-title font-h lets-info-up-pretitle"';
						if ( ! empty( $skin_titles ) ) {
							echo ' style="color: ' . esc_attr( $skin_titles ) . ';"';
						}
						echo '>' . esc_attr( get_post_meta( $pid, 'lets_info_up_aff_title', true ) ) . '</div>';
					}
				}

				echo '<div class="lets-info-up-aff-content font-b"><a href="' . esc_url( $value['url'] ) . '" class="font-b button-arrow-r button-arrow lets-info-up-title" rel="nofollow"';
				$new_tab = get_post_meta( $pid, 'lets_info_up_newwindow', true );
				echo empty( $new_tab ) || 'on' == $new_tab ? ' target="_blank"' : '';
				echo '><span class="button-title">' . esc_attr( $value['title'] ) . '</span><i class="tipi-i-arrow-right"></i></a></div>';
				$close = true;
				$i++;
			}
			if ( ! empty( $close ) ) {
				echo '</div>';
			}
		}
		if ( empty( $pid ) && ! empty( $args['blocks'] ) ) {
			$new_tab = empty( $args['new_tab'] ) ? '' : ' target="_blank"';
			echo '<div class="lets-info-up-block lets-info-up-aff-block">';
			if ( ! empty( $args['aff_title'] ) ) {
				echo '<div class="lets-info-up-aff-title font-h lets-info-up-pretitle"';
				if ( ! empty( $skin_titles ) ) {
					echo ' style="color: ' . esc_attr( $skin_titles ) . ';"';
				}
				echo '>' . lets_info_up_sanitize_wp_kses( $args['aff_title'] ) . '</div>';
			}
			foreach ( $blocks as $key => $value ) {
				if ( ! empty( $value['content'] ) ) {
					$content = $value['content'];
					$content = str_replace( '">', '" class="font-b button-arrow-r button-arrow lets-info-up-title" rel="nofollow"' . $new_tab . '><span class="button-title">', $content );
					$content = str_replace( '</a', '</span><i class="tipi-i-arrow-right"></i></a', $content );

					echo '<div class="lets-info-up-aff-content font-b">' . lets_info_up_sanitize_wp_kses( $content ) . '</div>';
				}
			}
			echo '</div>';
		}

	}

	function fi( $args = array() ) {
		$pid = empty( $args['pid'] ) ? '' : $args['pid'];
		$fi  = empty( $args['fi'] ) ? '' : $args['fi'];
		$fi  = empty( $args['fi'] ) && ! empty( $pid ) ? get_post_meta( $pid, 'lets_info_up_fi', true ) : $fi;
		if ( ! empty( $fi ) ) {
			echo '<div class="lets-info-up-fi">' . wp_get_attachment_image( $fi, 'lets-info-up-d1' ) . '</div>';
		}
	}

	/**
	 * Generic Output
	 *
	 * @since 1.1.0
	 *
	*/
	function block_output( $args = array() ) {
		if ( empty( $args['echo'] ) ) {
			ob_start();
		}
		$class       = '';
		$pid         = empty( $args['pid'] ) ? '' : $args['pid'];
		$fi          = empty( $args['fiID'] ) ? '' : $args['fiID'];
		$date_title  = empty( $args['dateTitle'] ) ? esc_attr__( 'Release Date', 'lets-info-up' ) : $args['dateTitle'];
		$date_onoff  = empty( $args['dateOnOff'] ) ? '' : $args['dateOnOff'];
		$new_tab     = empty( $args['linksNewTab'] ) ? '' : $args['linksNewTab'];
		$date        = empty( $args['date'] ) ? '' : $args['date'];
		$skin_text   = '';
		$skin_titles = '';
		$skin_bg     = empty( $args['skinBG'] ) ? '#111' : $args['skinBG'];
		$blocks      = empty( $args['blocks'] ) ? array() : $args['blocks'];
		$aff_title   = empty( $args['affTitle'] ) ? array() : $args['affTitle'];

		$aff_blocks    = empty( $args['affBlocks'] ) ? array() : $args['affBlocks'];
		$class        .= empty( $pid ) ? '' : 'lets-info-up-wrap-' . (int) $pid;
		$design        = empty( $args['design'] ) ? 'left' : $args['design'];
		$mobile_design = empty( $args['mobileAlign'] ) ? 1 : $args['mobileAlign'];
		$class        .= ' lets-info-up--' . $design;
		$class        .= ' lets-info-up--m-' . $mobile_design;
		$skin          = empty( $args['skin'] ) ? 2 : $args['skin'];
		$class        .= ' lets-info-up-skin-' . $skin;
		if ( 'right' == $design || 'left' == $design ) {
			$class .= ' lets-info-up--side';
		}

		if ( 3 == $skin ) {
			$uid         = mt_rand( 10000, 99999 );
			$class      .= ' lets-info-up-' . (int) $uid;
			$skin_text   = empty( $args['skinText'] ) ? '#fff' : $args['skinText'];
			$skin_titles = empty( $args['skinTitles'] ) ? '#ead125' : $args['skinTitles'];
		}

		if ( ! empty( $date_onoff ) ) {
			if ( ! empty( $date ) ) {
				$old_date_timestamp = strtotime( $date );
				$date               = date( get_option( 'date_format' ), $old_date_timestamp );
				array_unshift(
					$blocks,
					array(
						'title'   => $date_title,
						'content' => $date,
					)
				);
			}
		}

		echo '<div class="lets-info-up-wrap ' . esc_attr( $class ) . '"';
		if ( 3 == $skin ) {
			echo ' style="background:' . esc_attr( $skin_bg ) . '; color: ' . esc_attr( $skin_text ) . '"';
		}
		echo '>';
		?>
			<div class="lets-info-up">
			<?php
			$this->fi(
				array(
					'fi' => $fi,
				)
			);
			?>
			<div class="lets-info-up-block-wrap">
				<?php
				$title = get_post_meta( $pid, 'lets_info_up_title', true );
				$img   = get_post_meta( $pid, 'lets_info_up_fi', true );
				if ( ! empty( $title ) && empty( $img ) ) {
					echo '<div class="lets-info-up-block lets-info-up-main-title">' . esc_attr( $title ) . '</div>';
				}

				$this->blocks(
					array(
						'blocks'      => $blocks,
						'skin_titles' => $skin_titles,
						'skin_text'   => $skin_text,
					)
				);
				$this->aff_blocks(
					array(
						'blocks'      => $aff_blocks,
						'aff_title'   => $aff_title,
						'new_tab'     => $new_tab,
						'skin_titles' => $skin_titles,
						'skin_text'   => $skin_text,
					)
				);
				?>
			</div>
			</div>
		</div>
		<?php
		if ( empty( $args['echo'] ) ) {
			return ob_get_clean();
		}
	}

}
